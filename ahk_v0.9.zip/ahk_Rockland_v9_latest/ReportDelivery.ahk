#Requires AutoHotkey v2.0
#SingleInstance Force
#Include ahk_unattended.ahk

SetTitleMatchMode 2
CoordMode "Mouse", "Screen"
SendMode "Input"

logPath := A_ScriptDir "\ReportDelivery.log"
handoffPath := A_ScriptDir "\WeeklySalesRun1_handoff.txt"
reportsUrl := "http://192.168.1.138:42001/reports"
outlookUrl := "https://outlook.office.com"
fmtClickX := 1060
fmtClickY := 300
sharedReportsDir := "T:\RussShared\FormattedReports"
downloadWaitMs := 7000
pageLoadWaitMs := 5000
desktopSettleMs := 3000
outlookWaitMs := 10000

browserProcesses := [
    "msedge.exe",
    "chrome.exe",
    "firefox.exe",
    "brave.exe",
    "opera.exe",
    "iexplore.exe",
]

Log("START ReportDelivery (part 3)")
handoff := ReadWeeklySalesHandoff()
weekEnding := handoff.weekEnding
runStarted := handoff.runStarted

CloseBrowserProcesses()
CloseProcessImage("notepad.exe", "Notepad")
CloseProcessImage("BAKER32.EXE", "Bakers13")
MinimizeAllWindows()
Sleep desktopSettleMs

if !OpenEdgeAndNavigate(reportsUrl) {
    Log("FAIL could not launch Microsoft Edge for reports page.")
    ExitApp 1
}

Sleep pageLoadWaitMs
downloadsDir := ResolveDownloadsDir()
Log("Downloads folder: " downloadsDir)
beforeDownloads := SnapshotDownloadsFolder(downloadsDir)
Log("Downloads snapshot before Fmt click: " beforeDownloads.Count " file(s)")

ClickFmtDownloadButton(fmtClickX, fmtClickY)
Log("Waiting " downloadWaitMs " ms for formatted Excel download.")
Sleep downloadWaitMs

afterDownloads := SnapshotDownloadsFolder(downloadsDir)
newDownloadPath := FindNewestNewDownload(beforeDownloads, afterDownloads)
if !newDownloadPath {
    Log("FAIL no new file detected in Downloads after Fmt click.")
    PrintSynopsis(weekEnding, runStarted, "", "", false)
    ExitApp 1
}

Log("New download detected: " newDownloadPath)
sharedPath := CopyToSharedReports(newDownloadPath, sharedReportsDir)
if !sharedPath {
    Log("FAIL could not copy formatted report to shared drive.")
    PrintSynopsis(weekEnding, runStarted, newDownloadPath, "", false)
    ExitApp 1
}

PrintSynopsis(weekEnding, runStarted, newDownloadPath, sharedPath, true)
Log("Opening Outlook Web: " outlookUrl)
if !OpenEdgeAndNavigate(outlookUrl) {
    Log("WARN could not launch Microsoft Edge for Outlook; continuing.")
}

Sleep outlookWaitMs
Log("COMPLETE ReportDelivery finished successfully.")
ExitApp 0

ReadWeeklySalesHandoff() {
    global handoffPath

    result := {
        weekEnding: NextSaturdayDisplay(),
        runStarted: FormatTime(, "yyyy-MM-dd HH:mm:ss"),
    }

    if !FileExist(handoffPath) {
        Log("WARN handoff file not found; using computed defaults: " handoffPath)
        return result
    }

    try {
        for rawLine in StrSplit(FileRead(handoffPath), "`n", "`r") {
            line := Trim(rawLine)
            if line = "" || !InStr(line, "=") {
                continue
            }

            parts := StrSplit(line, "=", , 2)
            key := Trim(parts[1])
            value := Trim(parts[2])
            if key = "week_ending" && value != "" {
                result.weekEnding := value
            } else if key = "run_started" && value != "" {
                result.runStarted := value
            }
        }
    } catch as err {
        Log("WARN could not read handoff file: " err.Message)
    }

    Log("Handoff week_ending=" result.weekEnding " run_started=" result.runStarted)
    return result
}

NextSaturdayDisplay() {
    daysToAdd := Mod(7 - A_WDay, 7)
    target := DateAdd(A_Now, daysToAdd, "Days")
    return FormatTime(target, "MM/dd/yyyy")
}

CloseBrowserProcesses() {
    global browserProcesses

    for processName in browserProcesses {
        CloseProcessImage(processName, processName)
    }
}

CloseProcessImage(processImage, label) {
    if !ProcessExist(processImage) {
        Log("No " label " process running (" processImage ").")
        return
    }

    Log("Closing " label " (" processImage ").")
    try {
        Run 'taskkill /IM ' processImage ' /T /F', , "Hide"
    } catch as err {
        Log("WARN taskkill failed for " processImage ": " err.Message)
    }

    Sleep 750
}

MinimizeAllWindows() {
    Log("Minimizing all windows to desktop.")
    Send "#m"
    Sleep 500
}

ResolveDownloadsDir() {
    profile := EnvGet("USERPROFILE")
    if profile {
        downloads := profile "\Downloads"
        if DirExist(downloads) {
            return downloads
        }
    }

    fallback := A_MyDocuments "\..\Downloads"
    DirCreate fallback
    return fallback
}

OpenEdgeAndNavigate(url) {
    edgeExe := FindEdgeExecutable()
    if !edgeExe {
        Log("FAIL Microsoft Edge executable not found.")
        return false
    }

    command := Format('"{1}" "{2}"', edgeExe, url)
    Log("Launching Edge: " command)
    try {
        Run command
    } catch as err {
        Log("FAIL Edge launch failed: " err.Message)
        return false
    }

    Sleep 1500
    return true
}

FindEdgeExecutable() {
    for candidate in [
        A_ProgramFiles "\Microsoft\Edge\Application\msedge.exe",
        EnvGet("ProgramFiles(x86)") "\Microsoft\Edge\Application\msedge.exe",
        A_AppDataLocal "\Microsoft\Edge\Application\msedge.exe",
    ] {
        if candidate && FileExist(candidate) {
            return candidate
        }
    }

    return ""
}

SnapshotDownloadsFolder(folder) {
    snapshot := Map()

    if !DirExist(folder) {
        return snapshot
    }

    Loop Files folder "\*.*", "F" {
        snapshot[A_LoopFileFullPath] := A_LoopFileTimeModified
    }

    return snapshot
}

FindNewestNewDownload(before, after) {
    newestPath := ""
    newestModified := ""

    for path, modified in after {
        if before.Has(path) {
            continue
        }

        if newestPath = "" || modified > newestModified {
            newestPath := path
            newestModified := modified
        }
    }

    return newestPath
}

ClickFmtDownloadButton(x, y) {
    Log("Clicking Fmt download at " x "," y ".")
    MouseMove x, y, 8
    Sleep 400
    Click "Left"
    Sleep 300
}

CopyToSharedReports(sourcePath, destDir) {
    if !FileExist(sourcePath) {
        Log("FAIL source download missing: " sourcePath)
        return ""
    }

    try {
        DirCreate destDir
    } catch as err {
        Log("WARN could not create shared folder " destDir ": " err.Message)
    }

    SplitPath sourcePath, &fileName
    destPath := destDir "\" fileName

    try {
        if FileExist(destPath) {
            Log("Replacing existing shared copy: " destPath)
            FileDelete destPath
        }

        FileCopy sourcePath, destPath, true
    } catch as err {
        Log("FAIL copy to shared drive failed: " err.Message)
        return ""
    }

    if !FileExist(destPath) {
        Log("FAIL shared copy not found after FileCopy: " destPath)
        return ""
    }

    Log("Copied formatted report to: " destPath)
    return destPath
}

PrintSynopsis(weekEnding, runStarted, downloadPath, sharedPath, success) {
    logHeaderTime := FormatTime(, "dd/MM - HH:mm")
    synopsis := "Rockland Bakery Bakers13 - WeeklySalesReport for Week ending in: " weekEnding "`n`n`n"
    synopsis .= "=== Log " logHeaderTime " WeeklySalesRun Autohotkey ===`n"

    if success {
        synopsis .= "Report Generation started " runStarted "`n"
        synopsis .= "Report Generation Finished successfully. New report file located: " downloadPath " & " sharedPath "`n"
    } else {
        synopsis .= "Report Generation started " runStarted "`n"
        synopsis .= "Report Generation finished with errors during formatted report delivery.`n"
        if downloadPath {
            synopsis .= "Download path: " downloadPath "`n"
        }
    }

    Log("Synopsis:`n" synopsis)
    try {
        FileAppend synopsis, "*", "UTF-8"
    } catch as err {
        Log("WARN could not write synopsis to stdout: " err.Message)
    }
}

Log(message) {
    global logPath

    line := FormatTime(, "yyyy-MM-dd HH:mm:ss") " | " message "`n"
    try {
        FileAppend line, logPath, "UTF-8"
    }

    try {
        FileAppend line, "*", "UTF-8"
    }

    OutputDebug RTrim(line, "`n")
}
