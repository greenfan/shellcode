#!/usr/bin/env python3
"""
developerrecorder.py

Record a visible Windows 10 development session and generate:
  1. a JSON event log,
  2. an AutoHotkey v2 replay script,
  3. a prompt for a future LLM to refine the replay automation.

This tool is intended for recording your own UI automation steps. It can capture
sensitive keystrokes, so review or delete the generated files before sharing.

Windows is the primary target. Linux/X11 capture is available only when you pass
--x11, mainly for development/testing outside the target Windows machine.
"""

from __future__ import annotations

import argparse
import json
import math
import platform
import sys
import textwrap
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from threading import Event, Lock
from typing import Any


STOP_HOTKEY_TEXT = "Ctrl+Shift+F12"
STOP_HOTKEY = "<ctrl>+<shift>+<f12>"
DEFAULT_OUTPUT_DIR = Path.cwd() / "developerrecordings"
keyboard: Any = None
mouse: Any = None


@dataclass
class RecorderState:
    started_at: float
    started_iso: str
    record_moves: bool
    move_interval: float
    move_min_distance: float
    events: list[dict[str, Any]] = field(default_factory=list)
    lock: Lock = field(default_factory=Lock)
    stop_event: Event = field(default_factory=Event)
    last_move_at: float = 0.0
    last_move_pos: tuple[int, int] | None = None
    pressed_modifiers: set[str] = field(default_factory=set)

    def elapsed_ms(self) -> int:
        return round((time.monotonic() - self.started_at) * 1000)

    def append(self, event: dict[str, Any]) -> None:
        event["t_ms"] = self.elapsed_ms()
        with self.lock:
            self.events.append(event)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Record local mouse/keyboard input and generate AHK v2 automation."
    )
    parser.add_argument(
        "-o",
        "--output-dir",
        default=str(DEFAULT_OUTPUT_DIR),
        help=f"Directory for generated files. Default: {DEFAULT_OUTPUT_DIR}",
    )
    parser.add_argument(
        "--name",
        default="recording",
        help="Base name prefix for generated files. A timestamp is always appended.",
    )
    parser.add_argument(
        "--record-moves",
        action="store_true",
        help="Record mouse movement. By default only clicks, scrolls, and keyboard are recorded.",
    )
    parser.add_argument(
        "--move-interval",
        type=float,
        default=0.05,
        help="Minimum seconds between recorded mouse moves when --record-moves is enabled.",
    )
    parser.add_argument(
        "--move-min-distance",
        type=float,
        default=8.0,
        help="Minimum pixel distance between recorded mouse moves.",
    )
    parser.add_argument(
        "-x11",
        "--x11",
        action="store_true",
        help="Enable Linux/X11 capture. Windows capture does not need this flag.",
    )
    args = parser.parse_args()

    validate_capture_platform(args.x11)
    load_pynput(args.x11)

    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    state = RecorderState(
        started_at=time.monotonic(),
        started_iso=datetime.now().isoformat(timespec="seconds"),
        record_moves=args.record_moves,
        move_interval=args.move_interval,
        move_min_distance=args.move_min_distance,
    )

    print_banner(output_dir)

    mouse_listener = mouse.Listener(
        on_move=lambda x, y: on_mouse_move(state, x, y),
        on_click=lambda x, y, button, pressed: on_mouse_click(state, x, y, button, pressed),
        on_scroll=lambda x, y, dx, dy: on_mouse_scroll(state, x, y, dx, dy),
    )
    keyboard_listener = keyboard.Listener(
        on_press=lambda key: on_key(state, key, pressed=True),
        on_release=lambda key: on_key(state, key, pressed=False),
    )
    hotkey_listener = keyboard.GlobalHotKeys({STOP_HOTKEY: state.stop_event.set})

    try:
        mouse_listener.start()
        keyboard_listener.start()
        hotkey_listener.start()

        print("Recording now. Perform the task you want to automate.")
        print(f"Stop recording with {STOP_HOTKEY_TEXT}, or return here and press Ctrl+C.\n")

        while not state.stop_event.wait(0.2):
            pass
    except KeyboardInterrupt:
        print("\nCtrl+C received. Stopping recorder...")
    finally:
        mouse_listener.stop()
        keyboard_listener.stop()
        hotkey_listener.stop()

    paths = write_outputs(state, output_dir, args.name)
    print_summary(state, paths)
    return 0


def validate_capture_platform(enable_x11: bool) -> None:
    system = platform.system().lower()

    if system == "windows":
        return

    if system == "linux" and enable_x11:
        return

    if system == "linux":
        print(
            "developerrecorder.py is Windows-first for generating AutoHotkey v2 scripts.\n\n"
            "Linux capture is disabled by default. If you are deliberately recording from an X11 session, run:\n"
            "  python developerrecorder.py --x11\n\n"
            "Wayland sessions may block global input capture.",
            file=sys.stderr,
        )
        raise SystemExit(2)

    print(
        f"Unsupported capture platform: {platform.system()}.\n"
        "Run this on Windows 10, or use --x11 from a Linux X11 session for development/testing.",
        file=sys.stderr,
    )
    raise SystemExit(2)


def load_pynput(enable_x11: bool) -> None:
    global keyboard, mouse

    try:
        from pynput import keyboard as pynput_keyboard
        from pynput import mouse as pynput_mouse
    except ImportError:
        extra = ""
        if enable_x11:
            extra = "\nOn Linux, use an X11 session. Wayland may block global capture."

        print(
            "Missing dependency: pynput\n\n"
            "Install it with:\n"
            "  python -m pip install pynput"
            f"{extra}",
            file=sys.stderr,
        )
        raise SystemExit(2)

    keyboard = pynput_keyboard
    mouse = pynput_mouse


def print_banner(output_dir: Path) -> None:
    print("\nDeveloper Recorder")
    print("==================")
    print("Windows 10 is the primary recording target for AutoHotkey v2 generation.")
    print("This terminal-visible recorder captures local input events for your own automation.")
    print("It may record passwords or private text. Review generated files before sharing.")
    print(f"Output directory: {output_dir}\n")


def on_mouse_move(state: RecorderState, x: int, y: int) -> None:
    if not state.record_moves:
        return

    now = time.monotonic()
    if now - state.last_move_at < state.move_interval:
        return

    if state.last_move_pos is not None:
        last_x, last_y = state.last_move_pos
        if math.hypot(x - last_x, y - last_y) < state.move_min_distance:
            return

    state.last_move_at = now
    state.last_move_pos = (x, y)
    state.append({"type": "mouse_move", "x": x, "y": y})


def on_mouse_click(state: RecorderState, x: int, y: int, button: mouse.Button, pressed: bool) -> None:
    state.append(
        {
            "type": "mouse_click",
            "x": x,
            "y": y,
            "button": normalize_mouse_button(button),
            "pressed": pressed,
        }
    )


def on_mouse_scroll(state: RecorderState, x: int, y: int, dx: int, dy: int) -> None:
    state.append({"type": "mouse_scroll", "x": x, "y": y, "dx": dx, "dy": dy})


def on_key(state: RecorderState, key: keyboard.Key | keyboard.KeyCode, pressed: bool) -> None:
    normalized = normalize_key(key)

    if normalized["ahk"]:
        if pressed and normalized["is_modifier"]:
            state.pressed_modifiers.add(normalized["ahk"])
        elif not pressed and normalized["is_modifier"]:
            state.pressed_modifiers.discard(normalized["ahk"])

    state.append(
        {
            "type": "key",
            "pressed": pressed,
            "key": normalized["name"],
            "char": normalized["char"],
            "ahk": normalized["ahk"],
            "is_modifier": normalized["is_modifier"],
            "modifiers": sorted(state.pressed_modifiers),
        }
    )


def normalize_mouse_button(button: mouse.Button) -> str:
    name = getattr(button, "name", str(button).replace("Button.", ""))
    return {"left": "Left", "right": "Right", "middle": "Middle"}.get(name, name.title())


def normalize_key(key: keyboard.Key | keyboard.KeyCode) -> dict[str, Any]:
    if isinstance(key, keyboard.KeyCode):
        char = key.char
        name = char if char is not None else f"vk_{key.vk}"
        return {
            "name": name,
            "char": char,
            "ahk": char_to_ahk_key(char),
            "is_modifier": False,
        }

    raw_name = key.name or str(key).replace("Key.", "")
    ahk = SPECIAL_KEY_MAP.get(raw_name, raw_name.title())
    return {
        "name": raw_name,
        "char": None,
        "ahk": ahk,
        "is_modifier": ahk in MODIFIER_KEYS,
    }


SPECIAL_KEY_MAP = {
    "alt": "Alt",
    "alt_l": "LAlt",
    "alt_r": "RAlt",
    "backspace": "Backspace",
    "caps_lock": "CapsLock",
    "cmd": "LWin",
    "cmd_l": "LWin",
    "cmd_r": "RWin",
    "ctrl": "Ctrl",
    "ctrl_l": "LCtrl",
    "ctrl_r": "RCtrl",
    "delete": "Delete",
    "down": "Down",
    "end": "End",
    "enter": "Enter",
    "esc": "Esc",
    "f1": "F1",
    "f2": "F2",
    "f3": "F3",
    "f4": "F4",
    "f5": "F5",
    "f6": "F6",
    "f7": "F7",
    "f8": "F8",
    "f9": "F9",
    "f10": "F10",
    "f11": "F11",
    "f12": "F12",
    "home": "Home",
    "insert": "Insert",
    "left": "Left",
    "media_next": "Media_Next",
    "media_play_pause": "Media_Play_Pause",
    "media_previous": "Media_Prev",
    "media_volume_down": "Volume_Down",
    "media_volume_mute": "Volume_Mute",
    "media_volume_up": "Volume_Up",
    "menu": "AppsKey",
    "num_lock": "NumLock",
    "page_down": "PgDn",
    "page_up": "PgUp",
    "pause": "Pause",
    "print_screen": "PrintScreen",
    "right": "Right",
    "scroll_lock": "ScrollLock",
    "shift": "Shift",
    "shift_l": "LShift",
    "shift_r": "RShift",
    "space": "Space",
    "tab": "Tab",
    "up": "Up",
}

MODIFIER_KEYS = {"Alt", "LAlt", "RAlt", "Ctrl", "LCtrl", "RCtrl", "Shift", "LShift", "RShift", "LWin", "RWin"}


def char_to_ahk_key(char: str | None) -> str | None:
    if char is None:
        return None
    if char == " ":
        return "Space"
    if len(char) == 1 and char.isalpha():
        return char.lower()
    if len(char) == 1 and char.isdigit():
        return char
    return None


def write_outputs(state: RecorderState, output_dir: Path, base_name: str) -> dict[str, Path]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_base = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in base_name).strip("_")
    prefix = f"{safe_base}_{stamp}"

    metadata = {
        "started_at": state.started_iso,
        "ended_at": datetime.now().isoformat(timespec="seconds"),
        "duration_ms": state.elapsed_ms(),
        "platform": platform.platform(),
        "target_os": "Windows 10 / AutoHotkey v2",
        "python": sys.version.split()[0],
        "record_moves": state.record_moves,
        "stop_hotkey": STOP_HOTKEY_TEXT,
    }

    json_path = output_dir / f"{prefix}.json"
    ahk_path = output_dir / f"{prefix}_replay.ahk"
    prompt_path = output_dir / f"{prefix}_llm_prompt.md"

    payload = {"metadata": metadata, "events": state.events}
    json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    ahk_path.write_text(generate_ahk_script(metadata, state.events), encoding="utf-8")
    prompt_path.write_text(generate_llm_prompt(metadata, state.events), encoding="utf-8")

    return {"json": json_path, "ahk": ahk_path, "prompt": prompt_path}


def generate_ahk_script(metadata: dict[str, Any], events: list[dict[str, Any]]) -> str:
    lines = [
        "#Requires AutoHotkey v2.0",
        "#SingleInstance Force",
        "",
        "; Generated by developerrecorder.py",
        f"; Recorded: {metadata['started_at']}",
        "; Review before running. Coordinates are screen absolute.",
        "",
        'CoordMode "Mouse", "Screen"',
        'SendMode "Input"',
        "",
        'MsgBox "Replay will begin in 3 seconds. Move focus to the target app.", "Developer Recorder Replay", "T3"',
        "Sleep 3000",
        "",
    ]

    previous_t = 0
    for event in events:
        delay = max(0, int(event["t_ms"]) - previous_t)
        previous_t = int(event["t_ms"])
        if delay:
            lines.append(f"Sleep {delay}")

        rendered = render_ahk_event(event)
        if rendered:
            lines.extend(rendered)

    lines.extend(["", 'MsgBox "Replay complete.", "Developer Recorder Replay", "T2"', "ExitApp", ""])
    return "\n".join(lines)


def render_ahk_event(event: dict[str, Any]) -> list[str]:
    event_type = event.get("type")

    if event_type == "mouse_move":
        return [f"MouseMove {event['x']}, {event['y']}, 0"]

    if event_type == "mouse_click":
        direction = "D" if event["pressed"] else "U"
        return [
            f"MouseMove {event['x']}, {event['y']}, 0",
            f'MouseClick "{event["button"]}", {event["x"]}, {event["y"]}, 1, 0, "{direction}"',
        ]

    if event_type == "mouse_scroll":
        dy = int(event.get("dy", 0))
        dx = int(event.get("dx", 0))
        lines: list[str] = []
        if dy:
            wheel = "WheelUp" if dy > 0 else "WheelDown"
            lines.append(f'Send "{{{wheel} {abs(dy)}}}"')
        if dx:
            wheel = "WheelLeft" if dx > 0 else "WheelRight"
            lines.append(f'Send "{{{wheel} {abs(dx)}}}"')
        return lines

    if event_type == "key":
        return render_ahk_key_event(event)

    return [f"; Unknown event skipped: {json.dumps(event, ensure_ascii=False)}"]


def render_ahk_key_event(event: dict[str, Any]) -> list[str]:
    pressed = bool(event["pressed"])
    char = event.get("char")
    ahk = event.get("ahk")
    modifiers = set(event.get("modifiers", []))

    if not pressed and not event.get("is_modifier"):
        return []

    if event.get("is_modifier") and ahk:
        direction = "down" if pressed else "up"
        return [f'Send "{{{ahk} {direction}}}"']

    if pressed and char:
        if modifiers - {ahk}:
            return [f'Send "{{Blind}}{escape_ahk_send(char)}"']
        return [f'SendText "{escape_ahk_string(char)}"']

    if pressed and ahk:
        return [f'Send "{{{ahk}}}"']

    return []


def escape_ahk_string(value: str) -> str:
    return value.replace("`", "``").replace('"', '`"').replace("\n", "`n").replace("\r", "`r")


def escape_ahk_send(value: str) -> str:
    replacements = {
        "`": "``",
        "{": "{{}",
        "}": "{}}",
        "^": "{^}",
        "!": "{!}",
        "+": "{+}",
        "#": "{#}",
    }
    return "".join(replacements.get(ch, ch) for ch in value)


def generate_llm_prompt(metadata: dict[str, Any], events: list[dict[str, Any]]) -> str:
    transcript = build_readable_transcript(events)
    json_excerpt = json.dumps({"metadata": metadata, "events": events[:250]}, indent=2)
    omitted = max(0, len(events) - 250)

    return textwrap.dedent(
        f"""\
        # Prompt For Future LLM

        You are helping convert a recorded local UI interaction into a clean AutoHotkey v2 automation script.

        Requirements:
        - Use AutoHotkey v2 syntax only.
        - Prefer stable window activation, `WinWait`, `ControlClick`, image recognition, or app-specific selectors when available.
        - Use raw screen coordinates only where no better target exists.
        - Preserve the intent and order of the user's actions.
        - Remove accidental mouse jitter, redundant sleeps, and duplicate key events.
        - Do not include sensitive values directly unless the user explicitly asks. Use variables/placeholders for passwords, tokens, and private account data.
        - Add short comments for non-obvious waits or clicks.

        Recording metadata:
        ```json
        {json.dumps(metadata, indent=2)}
        ```

        Human-readable transcript:
        ```text
        {transcript}
        ```

        Raw event JSON excerpt:
        ```json
        {json_excerpt}
        ```

        {"Note: " + str(omitted) + " additional raw events were omitted from this prompt for size. Ask for the full JSON if needed." if omitted else ""}

        Please produce:
        1. A polished AutoHotkey v2 script.
        2. A short explanation of any assumptions.
        3. A list of coordinates or waits that should be verified manually.
        """
    )


def build_readable_transcript(events: list[dict[str, Any]]) -> str:
    lines: list[str] = []
    typed_buffer: list[str] = []
    buffer_start: int | None = None

    def flush_buffer() -> None:
        nonlocal buffer_start
        if typed_buffer:
            text = "".join(typed_buffer)
            lines.append(f"{buffer_start:>7} ms  TYPE_TEXT {text!r}")
            typed_buffer.clear()
            buffer_start = None

    for event in events:
        t_ms = int(event["t_ms"])
        if event["type"] == "key" and event.get("pressed") and event.get("char"):
            if buffer_start is None:
                buffer_start = t_ms
            typed_buffer.append(event["char"])
            continue

        flush_buffer()

        if event["type"] == "mouse_click":
            state = "DOWN" if event["pressed"] else "UP"
            lines.append(f"{t_ms:>7} ms  MOUSE_{state} {event['button']} at ({event['x']}, {event['y']})")
        elif event["type"] == "mouse_move":
            lines.append(f"{t_ms:>7} ms  MOUSE_MOVE to ({event['x']}, {event['y']})")
        elif event["type"] == "mouse_scroll":
            lines.append(f"{t_ms:>7} ms  SCROLL dx={event['dx']} dy={event['dy']} at ({event['x']}, {event['y']})")
        elif event["type"] == "key":
            state = "DOWN" if event["pressed"] else "UP"
            key = event.get("ahk") or event.get("key")
            lines.append(f"{t_ms:>7} ms  KEY_{state} {key}")

    flush_buffer()
    return "\n".join(lines) if lines else "(no events recorded)"


def print_summary(state: RecorderState, paths: dict[str, Path]) -> None:
    print("\nRecording stopped.")
    print(f"Captured events: {len(state.events)}")
    print(f"JSON log:       {paths['json']}")
    print(f"AHK replay:     {paths['ahk']}")
    print(f"LLM prompt:     {paths['prompt']}")
    print("\nRun the generated AHK only after reviewing it.")


if __name__ == "__main__":
    raise SystemExit(main())
