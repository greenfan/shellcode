#Requires AutoHotkey v2.0
#SingleInstance Force
#WinActivateForce
#Include ahk_unattended.ahk

SetTitleMatchMode 2
CoordMode "Mouse", "Screen"
SendMode "Input"
SetWinDelay 100
SetControlDelay 100

programName := "Bakers13"
processName := "BAKER32.EXE"
loginUsername := "bakers13"
loginPassword := "94dem"
fallbackExePath := "C:\Users\rdwyer\AppData\Local\Programs\Rockland Bakers Dozen\BAKER32.EXE"
fallbackWorkingDir := "\\rb-rossbd\Baker\Bakers13"
taskbarX := 624
taskbarY := 780
desktopIconX := 40
desktopIconY := 351
logPath := A_ScriptDir "\WeeklySalesRun1.log"
bakersInitScript := A_ScriptDir "\bakers_init.ahk"

; Core timing. Keep step delays >= 250 ms unless a setting explicitly says otherwise.
minStepDelayMs := 250
loginLoadWaitMs := 20000
reportConfigWaitMs := 4000
initHandoffSettleMs := 17000
reportGenerationWaitMs := 900000 ; 15 minutes after Tab x13 before checking for output
reportGenerationTimeoutMs := 120000 ; max wait for new Notepad window after generation wait (2 minutes)
reportFreshnessMs := 1200000 ; 20 minutes
trandataFolder := "\\Rb-rossbd\baker\Bakers13\trandata"











; Menu navigation after Alt+F.
reportMenu_sendEscapeBeforeAltF := true
reportMenu_pauseAfterEscapeMs := 300
reportMenu_altF_sleepMs := 900
reportMenu_sendEscapeAfterAltF := true
reportMenu_pauseAfterAltFEscapeMs := 400
reportNav_preludeRightCount := 3
reportNav_preludeDownCount := 1
reportNav_preludeKeyPauseMs := 250
reportNav_preludeSleepAfterMs := 1000
reportNav_steps := [
    { Dir: "Down", Count: 5, PauseMs: 300 },
    { Dir: "Right", Count: 1, PauseMs: 250 },
    { Dir: "Down", Count: 2, PauseMs: 250 },
    { Dir: "Right", Count: 1, PauseMs: 250 },
    { Dir: "Down", Count: 7, PauseMs: 250 },
]








runStartedAt := FormatTime(, "yyyy-MM-dd HH:mm:ss")
todayDigits := FormatTime(, "MMddyyyy")
todayFileDate := FormatTime(, "MM-dd-yyyy")
nextSaturday := NextSaturdayFormats()
reportConfigDigits := nextSaturday.Digits
reportFolder := A_Desktop "\ahk_Rockland-b13-Reports"
reportPath := reportFolder "\WeeklySalesHeader-" todayFileDate ".csv"

Log("START WeeklySalesRun1")
LogCoordinateProfile()
Log("Screen detected: " A_ScreenWidth "x" A_ScreenHeight)
Log("Today: digits=" todayDigits " fileDate=" todayFileDate)
Log("Report config date (next Saturday): digits=" reportConfigDigits " daysFromToday=" nextSaturday.DaysFromToday)

if !FileExist(bakersInitScript) {
    Log("FAIL bakers_init.ahk not found: " bakersInitScript)
    ExitApp 1
}

Log("Delegating launch and login to bakers_init.ahk via RunWait.")
if ShouldRunBakersInit() {
    initExitCode := RunBakersInit()
    if initExitCode != 0 {
        Log("FAIL bakers_init.ahk exited with code " initExitCode ". Aborting weekly workflow.")
        ExitApp initExitCode
    }
    Log("bakers_init.ahk completed successfully (exit 0).")
    Log("Waiting " initHandoffSettleMs " ms after bakers_init before weekly workflow handoff.")
    Sleep initHandoffSettleMs
} else {
    Log("Skipping bakers_init; " processName " is already running past the login screen.")
}

hwnd := ActivateBakersWindowRobust(processName)
if !hwnd {
    Log("WARN could not activate Bakers window after bakers_init; continuing with current active window and blind keyboard/mouse workflow.")
}

if hwnd {
    if LooksLikeLoginWindow(hwnd) {
        Log("WARN Bakers may still be at the login screen after bakers_init; continuing anyway (window targeting is often unreliable on remote sessions).")
    } else if !LoginDetectionReliable(hwnd) {
        Log("WARN could not reliably verify login state after bakers_init; continuing with weekly workflow.")
    } else {
        Log("Login verified: Bakers window is past the login screen.")
    }
}

winTitle := hwnd ? "ahk_id " hwnd : ""
FocusBakersClientArea(winTitle)
Sleep 500

report_via_keyboard_menu(winTitle)

Log("Waiting " reportConfigWaitMs " ms for in-app report config panel.")
Sleep reportConfigWaitMs

PrepareInAppReportConfigPanel(winTitle)
SendReportConfigScreenshotToOpenWebUI(winTitle, reportConfigDigits)

existingNotepadWindows := SnapshotNotepadWindows()
ConfigureWeeklySalesReport(reportConfigDigits, winTitle)

; --- Report generation wait (15 min) then verify output ---
Log("Waiting " reportGenerationWaitMs " ms (15 minutes) for report generation to finish.")
Sleep reportGenerationWaitMs

Log("Waiting up to " reportGenerationTimeoutMs " ms for a new Notepad report window.")
notepadWin := WaitForNewNotepadWindow(existingNotepadWindows, reportGenerationTimeoutMs)
if !notepadWin {
    Log("WARN no new Notepad window appeared before timeout. Checking shared trandata folder anyway.")
}

Log("Checking shared trandata folder for a fresh CSV.")
if !WaitForFreshTrandataReport(trandataFolder, reportFreshnessMs, 30000) {
    Log("FAIL no fresh file found in shared trandata folder after report generation.")
    ExitApp 1
}

Log("COMPLETE WeeklySalesRun1 finished successfully. Fresh trandata report detected.")
deliveryExitCode := LaunchReportDelivery(nextSaturday, runStartedAt)
ExitApp deliveryExitCode

RunBakersInit() {
    global bakersInitScript
    initLogPath := A_ScriptDir "\bakers_init.log"
    command := Format('"{1}" /ErrorStdOut "{2}"', A_AhkPath, bakersInitScript)
    Log("RunWait command: " command)
    exitCode := RunWait(command, A_ScriptDir)
    AppendExternalLogTail(initLogPath, "bakers_init.log")
    return exitCode
}

WriteWeeklySalesHandoff(nextSaturday, runStartedAt) {
    handoffPath := A_ScriptDir "\WeeklySalesRun1_handoff.txt"
    weekEnding := nextSaturday.DisplayDate
    content := "week_ending=" weekEnding "`nrun_started=" runStartedAt "`n"
    try {
        FileDelete handoffPath
        FileAppend content, handoffPath, "UTF-8"
        Log("Wrote WeeklySalesRun1 handoff: week_ending=" weekEnding " run_started=" runStartedAt)
    } catch as err {
        Log("WARN could not write handoff file: " err.Message)
    }
}

LaunchReportDelivery(nextSaturday, runStartedAt) {
    deliveryScript := A_ScriptDir "\ReportDelivery.ahk"
    if !FileExist(deliveryScript) {
        Log("WARN ReportDelivery.ahk not found; falling back to local graceful close.")
        GracefulCloseHelperApps()
        return 0
    }

    WriteWeeklySalesHandoff(nextSaturday, runStartedAt)
    command := Format('"{1}" /ErrorStdOut "{2}"', A_AhkPath, deliveryScript)
    Log("Starting ReportDelivery.ahk (part 3): " command)
    exitCode := RunWait(command, A_ScriptDir)
    Log("ReportDelivery.ahk finished with exit code " exitCode)
    return exitCode
}

AppendExternalLogTail(externalLogPath, label, maxLines := 40) {
    if !FileExist(externalLogPath) {
        Log("WARN " label " not found at " externalLogPath)
        return
    }

    try {
        content := FileRead(externalLogPath)
        lines := StrSplit(RTrim(content, "`r`n"), "`n")
        start := Max(1, lines.Length - maxLines + 1)
        Log("--- tail of " label " (" (lines.Length - start + 1) " lines) ---")
        Loop lines.Length - start + 1 {
            Log(lines[start + A_Index - 1])
        }
        Log("--- end " label " tail ---")
    } catch as err {
        Log("WARN could not read " label ": " err.Message)
    }
}

ShouldRunBakersInit() {
    global processName
    if !ProcessExist(processName) {
        return true
    }

    hwnd := WaitForProcessWindowRobust(processName, 5000)
    if !hwnd {
        return true
    }

    if LooksLikeLoginWindow(hwnd) {
        Log("Bakers is running but still at login; bakers_init is required.")
        return true
    }

    if !LoginDetectionReliable(hwnd) {
        Log("WARN cannot reliably detect Bakers login state; running bakers_init to be safe.")
        return true
    }

    return false
}

LaunchDesktopShortcut(x, y, processName) {
    Log("Double-clicking desktop shortcut coordinate " x "," y ".")
    MouseMove x, y, 10
    Sleep 250
    Click "Left"
    Sleep 45
    Click "Left"

    pid := WaitForProcess(processName, 10000)
    if pid {
        Log("SUCCESS " processName " started from desktop shortcut. PID=" pid)
    }

    return pid
}

LaunchFallbackExe(exePath, workingDir, processName) {
    if !FileExist(exePath) {
        Log("Fallback EXE not found: " exePath)
        return 0
    }

    if DirExist(workingDir) {
        Log("Running fallback EXE with shortcut Start In: " workingDir)
        Run exePath, workingDir
    } else {
        Log("WARN fallback working dir not found: " workingDir ". Running EXE without Start In.")
        Run exePath
    }

    pid := WaitForProcess(processName, 15000)
    if pid {
        Log("SUCCESS " processName " started from fallback EXE. PID=" pid)
    }

    return pid
}

KillBakersProcesses(processName) {
    Log("Closing all existing " processName " processes.")

    Loop 10 {
        pid := ProcessExist(processName)
        if !pid {
            Log("No remaining " processName " processes detected.")
            Sleep 1000
            return true
        }

        Log("Closing stale " processName " PID=" pid ".")
        try {
            ProcessClose pid
        } catch as err {
            Log("WARN ProcessClose failed for PID=" pid ": " err.Message)
        }

        Sleep 1000
    }

    if ProcessExist(processName) {
        Log("WARN " processName " still appears to be running after close attempts.")
        return false
    }

    return true
}

ActivateBakersWindowLogin(processName) {
    Log("Activating " processName " window for login.")

    hwnd := WaitForLoginOrProcessWindow(processName, 25000)
    if !hwnd {
        Log("WARN no visible window found for " processName " during login activation.")
        return 0
    }

    winTitle := "ahk_id " hwnd
    SafeWinRestore(winTitle, "login restore")
    SafeWinActivate(winTitle, 8, "login activation")
    Sleep 1000
    LogWindowDiagnostics(hwnd, "login activation")
    return hwnd
}

WaitForLoginOrProcessWindow(processName, timeoutMs := 25000) {
    deadline := A_TickCount + timeoutMs
    fallbackHwnd := 0

    while A_TickCount < deadline {
        for hwnd in WinGetList("ahk_exe " processName) {
            if !WinExist("ahk_id " hwnd) {
                continue
            }

            try {
                WinGetPos &x, &y, &w, &h, "ahk_id " hwnd
                if w < 1 || h < 1 {
                    continue
                }
            } catch {
                continue
            }

            if !fallbackHwnd {
                fallbackHwnd := hwnd
            }

            edits := GetEditControls("ahk_id " hwnd)
            if edits.Length >= 2 {
                Log("Login window candidate selected: hwnd=" hwnd " editControls=" edits.Length ".")
                return hwnd
            }
        }

        if fallbackHwnd {
            Sleep 500
        } else {
            Sleep 500
        }
    }

    if fallbackHwnd {
        Log("No explicit login-control window found; falling back to visible " processName " hwnd=" fallbackHwnd ".")
    }
    return fallbackHwnd
}

ActivateBakersWindowRobust(processName) {
    Log("Locating and activating " processName ".")

    hwnd := WaitForProcessWindowRobust(processName, 15000)
    if !hwnd {
        return 0
    }

    winTitle := "ahk_id " hwnd
    Log("Found window hwnd=" hwnd ". Restoring and attempting activation.")

    SafeWinRestore(winTitle, "Bakers main restore")
    if !SafeWinActivate(winTitle, 5, "Bakers main activation") {
        Log("WARN Bakers main WinWaitActive timed out; continuing with visible hwnd (common in remote RDP/web launches).")
        Sleep 1000
    }

    if !WinExist(winTitle) {
        Log("WARN Bakers window disappeared after activation attempt.")
        return 0
    }

    if SafeWinGetPos(winTitle, &x, &y, &w, &h, "Bakers main bounds") {
        Log("Bakers window bounds: x=" x " y=" y " w=" w " h=" h)
        return hwnd
    }

    Log("WARN could not read Bakers window bounds; continuing with hwnd anyway.")
    return hwnd
}

FocusBakersClientArea(winTitle) {
    Log("Focusing main window client area so menus receive keystrokes.")
    if !winTitle {
        Log("WARN no Bakers window title available; skipping client-area focus click.")
        return
    }

    if !SafeWinGetPos(winTitle, &x, &y, &w, &h, "focus client area bounds") {
        Log("WARN could not read window size; skipping focus click.")
        return
    }

    if w < 1 || h < 1 {
        Log("WARN could not read window size; skipping focus click.")
        return
    }

    cx := x + (w // 2)
    cy := y + (h // 2)
    Log("Solid-clicking Bakers client area center at " cx "," cy ".")
    PerformSolidClick(cx, cy)
    Sleep 400
}

PrepareInAppReportConfigPanel(winTitle := "") {
    Log("Preparing in-app report config panel; this is not a separate Windows window.")

    if winTitle {
        if !SafeWinActivate(winTitle, 3, "Bakers parent activation before in-app report config") {
            Log("WARN Bakers parent activation did not confirm; continuing with coordinate-only report config flow.")
        }
        Sleep 500
    } else {
        Log("WARN no Bakers parent window title available; continuing with coordinate-only report config flow.")
    }

    MaximizeReportConfigByClick()
    Sleep 500
}

MaximizeReportConfigByClick(parentWinTitle := "") {
    Log("Maximizing internal report config panel via coordinate-only clicks.")

    try {
        ClickAt(969, 74, "Report config internal maximize button primary", parentWinTitle)
        Sleep 500
        ClickAt(964, 71, "Report config internal maximize button fallback", parentWinTitle)
    } catch as err {
        Log("WARN internal report config maximize click failed but script will continue: " err.Message)
    }
}

SendReportConfigScreenshotToOpenWebUI(winTitle := "", dateStamp := "") {
    helperScript := A_ScriptDir "\openwebui_report_screenshot.py"
    if !FileExist(helperScript) {
        Log("WARN openwebui_report_screenshot.py not found; skipping Open WebUI screenshot step.")
        return
    }

    pythonExe := ResolvePythonExe()
    if !pythonExe {
        Log("WARN Python not found; skipping Open WebUI screenshot step.")
        return
    }

    if !dateStamp {
        dateStamp := FormatTime(, "MMddyyyy")
    }

    captureHwnd := 0
    if winTitle && WinExist(winTitle) {
        captureHwnd := WinExist(winTitle)
    }

    command := Format(
        '"{1}" "{2}" --date-stamp {3}',
        pythonExe,
        helperScript,
        dateStamp
    )
    Sleep 750

    if captureHwnd {
        command .= " --hwnd " captureHwnd
        Log("Open WebUI screenshot: capturing Bakers parent window hwnd=" captureHwnd " (in-app report config panel).")
    } else {
        command .= " --full-screen"
        Log("WARN Open WebUI screenshot: no Bakers hwnd; capturing full screen.")
    }

    Log("Open WebUI screenshot helper command: " command)
    exitCode := RunWait(command, A_ScriptDir, "Hide")
    if exitCode = 0 {
        Log("Open WebUI screenshot step finished (exit 0). See WeeklySalesRun1.log for helper details.")
    } else {
        Log("WARN Open WebUI screenshot helper exited with code " exitCode "; weekly workflow continues.")
    }
}

ResolvePythonExe() {
    envPython := EnvGet("PYTHON_EXE")
    if envPython && FileExist(envPython) {
        return envPython
    }

    for candidate in [
        "C:\Python312\python.exe",
        "C:\Python311\python.exe",
        "C:\Program Files\Python312\python.exe",
        "C:\Program Files\Python311\python.exe",
        A_AppData "\..\Local\Programs\Python\Python312\python.exe",
        A_AppData "\..\Local\Programs\Python\Python311\python.exe",
    ] {
        if FileExist(candidate) {
            return candidate
        }
    }

    return "python"
}

SafeWinRestore(winTitle, context := "window restore") {
    try {
        if !WinExist(winTitle) {
            Log("WARN " context ": target window does not exist: " winTitle)
            return false
        }

        WinRestore winTitle
        return true
    } catch as err {
        Log("WARN " context " failed: " err.Message)
        return false
    }
}

SafeWinActivate(winTitle, timeoutSeconds := 5, context := "window activation") {
    try {
        if !WinExist(winTitle) {
            Log("WARN " context ": target window does not exist: " winTitle)
            return false
        }

        WinActivate winTitle
        if timeoutSeconds > 0 && !WinWaitActive(winTitle, , timeoutSeconds) {
            Log("WARN " context ": WinWaitActive timed out for " winTitle)
            return false
        }

        return true
    } catch as err {
        Log("WARN " context " failed: " err.Message)
        return false
    }
}

SafeWinGetPos(winTitle, &x, &y, &w, &h, context := "window bounds") {
    x := 0
    y := 0
    w := 0
    h := 0

    try {
        if !WinExist(winTitle) {
            Log("WARN " context ": target window does not exist: " winTitle)
            return false
        }

        WinGetPos &x, &y, &w, &h, winTitle
        return true
    } catch as err {
        Log("WARN " context " failed: " err.Message)
        return false
    }
}

LooksLikeLoginWindow(hwnd) {
    if !hwnd {
        return false
    }

    edits := GetEditControls("ahk_id " hwnd, &enumerationOk)
    if !enumerationOk {
        Log("WARN login detection unreliable for hwnd=" hwnd "; control enumeration failed.")
        return false
    }

    if edits.Length >= 2 {
        Log("Login detection: hwnd=" hwnd " has " edits.Length " Edit controls; treating as login screen.")
        return true
    }

    return false
}

LoginDetectionReliable(hwnd) {
    if !hwnd {
        return false
    }

    GetEditControls("ahk_id " hwnd, &enumerationOk)
    return enumerationOk
}

GetEditControls(winTitle, &enumerationOk := true) {
    edits := []
    enumerationOk := true
    try {
        controls := WinGetControls(winTitle)
        for controlName in controls {
            if RegExMatch(controlName, "^Edit\d+$") {
                edits.Push(controlName)
            }
        }
    } catch as err {
        enumerationOk := false
        Log("WARN could not enumerate controls for " winTitle ": " err.Message)
    }
    return edits
}

LogWindowDiagnostics(hwnd, context) {
    winTitle := "ahk_id " hwnd
    try {
        title := WinGetTitle(winTitle)
        cls := WinGetClass(winTitle)
        Log(context ": hwnd=" hwnd " title='" title "' class='" cls "'")
    } catch as err {
        Log("WARN " context ": title/class diagnostics failed: " err.Message)
    }

    if SafeWinGetPos(winTitle, &x, &y, &w, &h, context " bounds") {
        Log(context ": bounds x=" x " y=" y " w=" w " h=" h)
    }

    try {
        controls := WinGetControls(winTitle)
        controlList := ""
        for controlName in controls {
            controlList .= (controlList = "" ? "" : ", ") controlName
        }
        Log(context ": controls=" (controlList = "" ? "(none)" : controlList))
    } catch as err {
        Log("WARN " context ": control diagnostics failed: " err.Message)
    }
}

PerformLogin(processName) {
    global loginUsername, loginPassword

    Log("Starting resilient login sequence.")

    Loop 3 {
        attempt := A_Index
        hwnd := ActivateBakersWindowLogin(processName)
        if !hwnd {
            Log("WARN login attempt " attempt ": no Bakers window available.")
            Sleep 1500
            continue
        }

        winTitle := "ahk_id " hwnd
        ; Bakers is picky about login input. Use controls only to locate/focus the field,
        ; then send real keystrokes with the same clearing behavior as the original script.
        if TryLoginWithKeyboard(winTitle, attempt, loginUsername, loginPassword) {
            return true
        }

        Log("WARN login attempt " attempt " did not send credentials successfully; retrying.")
        Sleep 1500
    }

    return false
}

TryLoginWithControls(winTitle, attempt, username, password) {
    edits := GetEditControls(winTitle)
    if edits.Length < 2 {
        Log("Login attempt " attempt ": control path unavailable; found " edits.Length " Edit controls.")
        return false
    }

    pairs := []
    if edits.Length >= 3 {
        pairs.Push([edits[2], edits[3]])
    }
    pairs.Push([edits[1], edits[2]])

    for _, pair in pairs {
        usernameControl := pair[1]
        passwordControl := pair[2]

        try {
            Log("Login attempt " attempt ": trying control path usernameControl=" usernameControl " passwordControl=" passwordControl ".")
            ControlFocus usernameControl, winTitle
            Sleep 250
            ControlSetText "", usernameControl, winTitle
            Sleep 150
            ControlSetText username, usernameControl, winTitle
            Sleep 250
            readBack := ControlGetText(usernameControl, winTitle)
            if readBack != username {
                Log("WARN login attempt " attempt ": username control readback mismatch for " usernameControl ". readBack='" readBack "'.")
                continue
            }

            ControlFocus passwordControl, winTitle
            Sleep 250
            ControlSetText "", passwordControl, winTitle
            Sleep 150
            ControlSetText password, passwordControl, winTitle
            Sleep 250

            Log("Login attempt " attempt ": submitting via password control Enter.")
            ControlSend "{Enter}", passwordControl, winTitle
            Sleep 1200
            if WaitForLoginWindowToClear(winTitle, 8000) {
                Log("Login attempt " attempt ": login controls cleared after control submit.")
                return true
            }
            Log("WARN login attempt " attempt ": login controls still present after control submit with " usernameControl "/" passwordControl ".")
        } catch as err {
            Log("WARN login attempt " attempt ": control path failed for " usernameControl "/" passwordControl ": " err.Message)
        }
    }

    return false
}

TryLoginWithKeyboard(winTitle, attempt, username, password) {
    activationOk := SafeWinActivate(winTitle, 8, "login keyboard attempt " attempt " activation")
    if !activationOk {
        Log("WARN login attempt " attempt ": keyboard activation timed out; forcing username-area click instead of aborting.")
    }

    FocusLoginUsernameArea(winTitle, attempt, !activationOk)

    Log("Login attempt " attempt ": clearing username field with Delete x20 at 200ms.")
    RepeatKey("{Delete}", 20, 200)

    Log("Login attempt " attempt ": clearing username field with Backspace x20 at 200ms.")
    RepeatKey("{Backspace}", 20, 200)

    Log("Login attempt " attempt ": entering username one key at a time with 200ms delay.")
    TypeTextSlow(username, 200)
    Sleep 300

    Log("Moving to password field.")
    Send "{Tab}"
    Sleep 300

    Log("Login attempt " attempt ": entering password one key at a time with 200ms delay.")
    TypeTextSlow(password, 200)
    Sleep 300

    Log("Submitting login.")
    Send "{Enter}"
    Sleep 1200
    if WaitForLoginWindowToClear(winTitle, 8000) {
        Log("Login attempt " attempt ": login controls cleared after keyboard submit.")
        return true
    }
    Log("WARN login attempt " attempt ": login controls still present after keyboard submit.")
    return false
}

TypeTextSlow(value, pauseMs := 200) {
    for _, ch in StrSplit(value) {
        SendText ch
        Sleep pauseMs
    }
}

WaitForLoginWindowToClear(winTitle, timeoutMs := 8000) {
    deadline := A_TickCount + timeoutMs

    while A_TickCount < deadline {
        if !WinExist(winTitle) {
            return true
        }

        edits := GetEditControls(winTitle)
        if edits.Length < 2 {
            return true
        }

        Sleep 500
    }

    return false
}

FocusLoginUsernameArea(winTitle, attempt, forceClick := false) {
    if !SafeWinGetPos(winTitle, &x, &y, &w, &h, "login attempt " attempt " focus bounds") {
        return
    }

    edits := GetEditControls(winTitle)
    if edits.Length >= 1 {
        usernameControl := edits.Length >= 3 ? edits[2] : edits[1]
        try {
            ControlFocus usernameControl, winTitle
            Sleep 250
            if forceClick {
                Log("Login attempt " attempt ": forced focus/click on username candidate " usernameControl ".")
                ControlClick usernameControl, winTitle
                Sleep 400
            } else {
                Log("Login attempt " attempt ": focused username candidate " usernameControl ".")
            }
            return
        } catch as err {
            Log("WARN login attempt " attempt ": focus/click " usernameControl " failed: " err.Message)
        }
    }

    ; If Bakers exposes no usable controls, use a conservative coordinate inside the login dialog.
    cx := x + Round(w * 0.42)
    cy := y + Round(h * 0.42)
    Log("Login attempt " attempt ": clicking estimated username area at " cx "," cy ".")
    MouseMove cx, cy, 5
    Sleep 250
    Click "Left"
    Sleep 400
}

report_via_keyboard_menu(winTitle) {
    global reportMenu_sendEscapeBeforeAltF, reportMenu_pauseAfterEscapeMs
    global reportMenu_altF_sleepMs, reportMenu_sendEscapeAfterAltF, reportMenu_pauseAfterAltFEscapeMs
    global reportNav_preludeRightCount, reportNav_preludeDownCount
    global reportNav_preludeKeyPauseMs, reportNav_preludeSleepAfterMs, reportNav_steps

    Log("Report sequence: File menu via Alt+F + weekly sales navigation.")

    if reportMenu_sendEscapeBeforeAltF {
        Send "{Escape}"
        Sleep reportMenu_pauseAfterEscapeMs
    }

    if winTitle && !WinActive(winTitle) {
        Log("WARN window lost focus before menu; re-activating.")
        SafeWinActivate(winTitle, 3, "pre-menu reactivation")
        Sleep 400
    }

    Log("Opening File menu with Alt+F.")
    Send "!f"
    Sleep reportMenu_altF_sleepMs

    if reportMenu_sendEscapeAfterAltF {
        Log("Escape after File menu open (per workflow).")
        Send "{Escape}"
        Sleep reportMenu_pauseAfterAltFEscapeMs
    }

    if winTitle && !WinActive(winTitle) {
        SafeWinActivate(winTitle, 3, "post-menu reactivation")
        Sleep 300
    }

    RepeatKey("{Right}", reportNav_preludeRightCount, reportNav_preludeKeyPauseMs)
    RepeatKey("{Down}", reportNav_preludeDownCount, reportNav_preludeKeyPauseMs)
    Sleep reportNav_preludeSleepAfterMs
    ExecuteReportNavigationSteps(reportNav_steps)

    Log("Selecting report with Enter.")
    Send "{Enter}"
    Sleep 400
}

ConfigureWeeklySalesReport(reportDateDigits, bakersWinTitle) {
    Log("Configuring weekly sales report in-app panel.")

    if bakersWinTitle {
        try {
            if !WinActive(bakersWinTitle) {
                Log("Bakers parent lost focus before date input; attempting re-activation.")
                SafeWinActivate(bakersWinTitle, 5, "Bakers reactivation before in-app report date input")
                Sleep 500
            }
        } catch as err {
            Log("WARN Bakers parent focus check/reactivation failed; continuing with current focus: " err.Message)
        }
    }

    Log("Clearing/repositioning date field.")
    RepeatKey("{Delete}", 2, 250)
    RepeatKey("{Right}", 2, 250)
    RepeatKey("{Delete}", 2, 250)
    RepeatKey("{Right}", 2, 250)
    RepeatKey("{Delete}", 4, 250)
    RepeatKey("{Left}", 8, 250)

    Log("Entering report config date (next Saturday) as digits: " reportDateDigits)
    TypeDigits(reportDateDigits, 250)

    Log("Re-confirming internal report config panel is maximized by coordinate-only click.")
    MaximizeReportConfigByClick(bakersWinTitle)
    Sleep 750

    Log("Activating report category list and forcing selection to the top with Up x40 at 50ms.")
    ClickAt(351, 135, "Activate report category list", bakersWinTitle)
    Sleep 250
    Loop 40 {
        Send "{Up}"
        Sleep 50
    }
    Loop 3 {
        Send "{Down}"
        Sleep 100
    }
    Log("Holding LShift firmly, pressing Down x40, then Up once.")
    Send "{LShift down}"
    Sleep 500
    Loop 40 {
        Send "{Down}"
        Sleep 100
    }
    Send "{Up}"
    Sleep 100
    Log("Releasing Shift only; no Tab or other keys until report generation click.")
    Send "{LShift up}"
    Sleep 200

    Log("Category selection complete; clicking 234,717 to start report generation.")
    ClickAt(234, 717, "start report generation at 234,717", bakersWinTitle)
    Sleep 500
}

SaveNotepadReport(reportPath, notepadWin := "") {
    Log("Saving completed Notepad report to: " reportPath)

    DirCreate DirName(reportPath)

    if FileExist(reportPath) {
        Log("Existing report file found; deleting before Save As.")
        FileDelete reportPath
    }
    if !notepadWin {
        notepadWin := WaitForNotepadWindow(60000)
    }

    if !notepadWin {
        Log("FAIL Notepad window was not found.")
        ExitApp 1
    }

    if !SafeWinActivate(notepadWin, 10, "Notepad activation before save") {
        Log("FAIL Notepad window could not be activated.")
        ExitApp 1
    }

    Sleep 1000
    Log("Opening Notepad Save As with Alt+F, A.")
    Send "!fa"
    Sleep 1500

    Log("Typing target save path.")
    SendText reportPath
    Sleep 500
    Send "{Enter}"
    Sleep 2500

    if WinExist("Confirm Save As") || WinExist("ahk_class #32770") {
        Log("Save dialog/confirm dialog still visible; sending Enter once.")
        Send "{Enter}"
        Sleep 1000
    }
}

SnapshotNotepadWindows() {
    windows := Map()

    for hwnd in WinGetList("ahk_exe notepad.exe") {
        windows[hwnd] := true
        Log("Existing Notepad window before generation: hwnd=" hwnd)
    }

    Log("Notepad baseline count before generation: " windows.Count)
    return windows
}

WaitForNewNotepadWindow(existingWindows, timeoutMs := 660000) {
    deadline := A_TickCount + timeoutMs

    while A_TickCount < deadline {
        for hwnd in WinGetList("ahk_exe notepad.exe") {
            if !existingWindows.Has(hwnd) && WinExist("ahk_id " hwnd) {
                Log("New Notepad report window detected: hwnd=" hwnd)
                return "ahk_id " hwnd
            }
        }

        Sleep 5000
    }

    return ""
}

WaitForFreshTrandataReport(folder, freshnessMs := 1200000, timeoutMs := 30000) {
    Log("Checking shared trandata folder for fresh generated report: " folder)
    deadline := A_TickCount + timeoutMs

    while A_TickCount < deadline {
        latest := FindNewestFile(folder)
        if latest.Path {
            ageSeconds := DateDiff(A_Now, latest.Modified, "Seconds")
            Log("Newest trandata file: " latest.Path " modified=" latest.Modified " ageSeconds=" ageSeconds)

            if ageSeconds >= 0 && ageSeconds <= (freshnessMs // 1000) {
                Log("Fresh trandata file detected within freshness window.")
                return true
            }
        } else {
            Log("No files found or folder unavailable: " folder)
        }

        Sleep 5000
    }

    return false
}

FindNewestFile(folder) {
    newest := { Path: "", Modified: "" }

    if !DirExist(folder) {
        return newest
    }

    Loop Files folder "\*.*", "F" {
        if newest.Modified = "" || A_LoopFileTimeModified > newest.Modified {
            newest.Path := A_LoopFileFullPath
            newest.Modified := A_LoopFileTimeModified
        }
    }

    return newest
}

WaitForNotepadWindow(timeoutMs := 60000) {
    deadline := A_TickCount + timeoutMs

    while A_TickCount < deadline {
        for hwnd in WinGetList("ahk_exe notepad.exe") {
            if WinExist("ahk_id " hwnd) {
                return "ahk_id " hwnd
            }
        }

        Sleep 1000
    }

    return ""
}

DirName(path) {
    SplitPath path, , &dir
    return dir
}

; A_WDay: 1=Sunday ... 7=Saturday. Returns the upcoming Saturday (today if already Saturday).
NextSaturdayFormats() {
    daysToAdd := Mod(7 - A_WDay, 7)
    target := DateAdd(A_Now, daysToAdd, "Days")
    return {
        Digits: FormatTime(target, "MMddyyyy"),
        FileDate: FormatTime(target, "MM-dd-yyyy"),
        DisplayDate: FormatTime(target, "MM/dd/yyyy"),
        DaysFromToday: daysToAdd
    }
}

ShowClickCrosshair(x, y) {
    arm := 32
    thick := 5
    overlays := []

    ; +E0x20 = click-through so the debug overlay cannot steal the mouse click.
    crossH := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20")
    crossH.BackColor := "FF0000"
    crossH.Show(Format("x{} y{} w{} h{} NoActivate", x - arm, y - (thick // 2), arm * 2, thick))
    overlays.Push(crossH)

    crossV := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20")
    crossV.BackColor := "FF0000"
    crossV.Show(Format("x{} y{} w{} h{} NoActivate", x - (thick // 2), y - arm, thick, arm * 2))
    overlays.Push(crossV)

    center := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20")
    center.BackColor := "FFFF00"
    dotSize := 14
    center.Show(Format("x{} y{} w{} h{} NoActivate", x - (dotSize // 2), y - (dotSize // 2), dotSize, dotSize))
    overlays.Push(center)

    for overlay in overlays {
        try {
            WinSetTransparent(210, overlay)
        }
    }

    return overlays
}

HideClickCrosshair(overlays) {
    for overlay in overlays {
        try {
            overlay.Destroy()
        }
    }
}

PerformSolidClick(x, y) {
    MouseMove x, y, 0
    Sleep 120

    priorSendMode := A_SendMode
    try {
        SendMode "Event"
        Send "{LButton down}"
        Sleep 90
        Send "{LButton up}"
    } finally {
        try {
            SendMode priorSendMode
        }
    }

    Log("Solid left click delivered at " x "," y " (LButton down/up, Event send mode).")
}

ClickAt(designX, designY, description, winTitle := "") {
    point := ResolveAutomationPoint(designX, designY)
    x := point[1]
    y := point[2]
    if designX = x && designY = y {
        Log(description " - left click at " x "," y ".")
    } else {
        Log(description " - left click at " x "," y " (" point[3] " from design " designX "," designY ").")
    }
    if winTitle {
        SafeWinActivate(winTitle, 5, "pre-click window activation for " description)
        Sleep 300
    }

    coordText := x "," y "`n" description
    ToolTip coordText, x + 18, y + 18, 1
    overlays := ShowClickCrosshair(x, y)
    MouseMove x, y, 4
    Sleep 400
    HideClickCrosshair(overlays)
    ToolTip(, , , 1)
    Sleep 100
    PerformSolidClick(x, y)
    Sleep 300
}

LogCoordinateProfile() {
    if A_ScreenWidth = 1280 && A_ScreenHeight = 800 {
        Log("Coordinate profile: native 1280x800; using original tuned click points.")
    } else if A_ScreenWidth = 1597 && A_ScreenHeight = 812 {
        Log("Coordinate profile: calibrated 1597x812 tscon console profile; using fixed translated click points.")
    } else {
        scaleX := Round(A_ScreenWidth / 1280, 3)
        scaleY := Round(A_ScreenHeight / 800, 3)
        Log("WARN coordinate profile: uncalibrated screen " A_ScreenWidth "x" A_ScreenHeight
            "; scaling from 1280x800 with scaleX=" scaleX " scaleY=" scaleY ".")
    }
}

ResolveAutomationPoint(designX, designY) {
    if A_ScreenWidth = 1280 && A_ScreenHeight = 800 {
        return [designX, designY, "native"]
    }

    if A_ScreenWidth = 1597 && A_ScreenHeight = 812 {
        if designX = 969 && designY = 74 {
            return [1209, 75, "1597x812 calibrated"]
        }
        if designX = 964 && designY = 71 {
            return [1203, 72, "1597x812 calibrated"]
        }
        if designX = 351 && designY = 135 {
            return [438, 137, "1597x812 calibrated"]
        }
        if designX = 234 && designY = 717 {
            return [292, 728, "1597x812 calibrated"]
        }
    }

    return [
        Max(0, Round(designX * A_ScreenWidth / 1280)),
        Max(0, Round(designY * A_ScreenHeight / 800)),
        "proportional fallback"
    ]
}

ReleaseAllModifiers(context := "modifier reset") {
    Log(context ": releasing Shift/Ctrl/Alt/Win modifiers.")
    Loop 3 {
        Send "{LShift up}{RShift up}{Shift up}{LCtrl up}{RCtrl up}{Ctrl up}{LAlt up}{RAlt up}{Alt up}{LWin up}{RWin up}"
        Sleep 100
    }
}

GracefulCloseHelperApps() {
    Log("Gracefully closing Notepad windows.")
    try {
        Run 'taskkill /IM notepad.exe /T', , "Hide"
    } catch as err {
        Log("WARN taskkill notepad failed: " err.Message)
    }

    Sleep 1000

    Log("Gracefully closing Bakers (BAKER32.EXE).")
    try {
        Run 'taskkill /IM BAKER32.EXE /T', , "Hide"
    } catch as err {
        Log("WARN taskkill BAKER32 failed: " err.Message)
    }

    Sleep 1000
}

RepeatKey(keySym, repeats, pauseMs := 250) {
    pauseMs := Max(pauseMs, 200)

    if repeats < 1 {
        return
    }

    Loop repeats {
        Send keySym
        Sleep pauseMs
    }
}

TypeDigits(value, pauseMs := 250) {
    pauseMs := Max(pauseMs, 250)

    for _, ch in StrSplit(value) {
        if ch ~= "^\d$" {
            Send ch
            Sleep pauseMs
        }
    }
}

ExecuteReportNavigationSteps(steps) {
    if Type(steps) != "Array" || steps.Length < 1 {
        Log("WARN reportNav_steps empty or not an array; skipping.")
        return
    }

    for _, step in steps {
        try {
            dir := Trim(StrLower(step.Dir))
            loopCount := Round(Number(step.Count))
            pauseAfter := Max(Round(Number(step.PauseMs)), 250)
        } catch {
            Log("WARN skipping malformed navigation row (need Dir, Count, PauseMs).")
            continue
        }

        keySym := ""
        switch dir {
            default:
                Log("WARN unknown Dir '" dir "' - use Down, Right, Left, Up.")
                continue
            case "down":
                keySym := "{Down}"
            case "right":
                keySym := "{Right}"
            case "left":
                keySym := "{Left}"
            case "up":
                keySym := "{Up}"
        }

        Log("Step: " dir " x" loopCount ", pause " pauseAfter " ms between.")
        RepeatKey(keySym, loopCount, pauseAfter)
    }
}

WaitForProcess(processName, timeoutMs := 15000) {
    deadline := A_TickCount + timeoutMs

    while A_TickCount < deadline {
        pid := ProcessExist(processName)
        if pid {
            return pid
        }

        Sleep 500
    }

    return 0
}

WaitForProcessWindow(processName, timeoutMs := 15000) {
    deadline := A_TickCount + timeoutMs

    while A_TickCount < deadline {
        for hwnd in WinGetList("ahk_exe " processName) {
            if WinGetMinMax("ahk_id " hwnd) != -1 {
                return hwnd
            }
        }

        Sleep 500
    }

    return 0
}

WaitForProcessWindowRobust(processName, timeoutMs := 15000) {
    deadline := A_TickCount + timeoutMs

    while A_TickCount < deadline {
        bestHwnd := 0
        bestArea := 0

        for hwnd in WinGetList("ahk_exe " processName) {
            if !WinExist("ahk_id " hwnd) {
                continue
            }

            try {
                WinGetPos &x, &y, &w, &h, "ahk_id " hwnd
                if w > 0 && h > 0 {
                    area := w * h
                    if area > bestArea {
                        bestArea := area
                        bestHwnd := hwnd
                    }
                }
            }
        }

        if bestHwnd {
            Log("Selected largest visible " processName " window hwnd=" bestHwnd " area=" bestArea ".")
            return bestHwnd
        }

        Sleep 500
    }

    return 0
}

Log(message) {
    global logPath

    line := FormatTime(, "yyyy-MM-dd HH:mm:ss") " | " message "`n"
    try {
        FileAppend line, logPath, "UTF-8"
    }

    try {
        FileAppend line, "*", "UTF-8"
    }

    OutputDebug RTrim(line, "`n")
}
