#!/usr/bin/env python3
"""Build a formal PDF from a formatted (.fmt.xlsx) weekly sales report."""

from __future__ import annotations

import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

from openpyxl import load_workbook
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from format_report_xlsx import (
    NEW_SALES_CUTOFF,
    find_column_index_optional,
    find_rep_column,
    start_date_sort_key,
)

HEADER_HEIGHT_PT = 90
HEADER_BG = colors.HexColor("#1f4f7a")
HEADER_TEXT = colors.white
TABLE_HEADER_BG = colors.HexColor("#eef3f8")
TABLE_HEADER_TEXT = colors.HexColor("#1f4f7a")
TABLE_ZEBRA = colors.HexColor("#fafbfc")
TABLE_SUMMARY_BG = colors.HexColor("#e8eef5")
TABLE_GRID = colors.HexColor("#d4dde6")
BODY_TEXT = colors.HexColor("#1a1a1a")


def parse_week_ending(value: str) -> datetime | None:
    text = value.strip()
    for fmt in ("%m/%d/%Y", "%m-%d-%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return None


def week_ending_saturday(reference: datetime) -> datetime:
    days_until = (5 - reference.weekday()) % 7
    return (reference + timedelta(days=days_until)).replace(hour=0, minute=0, second=0, microsecond=0)


def report_date_range(week_ending: datetime) -> tuple[str, str]:
    end = week_ending.replace(hour=0, minute=0, second=0, microsecond=0)
    start = end - timedelta(days=14)
    return start.strftime("%m/%d/%Y"), end.strftime("%m/%d/%Y")


def read_handoff_week_ending(app_root: Path) -> datetime | None:
    handoff = app_root / "WeeklySalesRun1_handoff.txt"
    if not handoff.exists():
        return None
    for raw_line in handoff.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw_line.strip()
        if line.startswith("week_ending="):
            return parse_week_ending(line.split("=", 1)[1])
    return None


def resolve_week_ending(fmt_path: Path, explicit: str | None = None) -> datetime:
    if explicit:
        parsed = parse_week_ending(explicit)
        if parsed:
            return week_ending_saturday(parsed)

    handoff = read_handoff_week_ending(fmt_path.resolve().parent)
    if handoff:
        return week_ending_saturday(handoff)

    reference = datetime.fromtimestamp(fmt_path.stat().st_mtime)
    return week_ending_saturday(reference)


def load_sheet_rows(path: Path) -> tuple[list, list[list]]:
    workbook = load_workbook(path, data_only=True)
    sheet = workbook.active
    max_row = sheet.max_row or 1
    max_col = sheet.max_column or 1
    headers = [sheet.cell(1, col).value for col in range(1, max_col + 1)]
    rows: list[list] = []
    for row_idx in range(2, max_row + 1):
        row = [sheet.cell(row_idx, col).value for col in range(1, max_col + 1)]
        rows.append(row)
    return headers, rows


def is_blank_row(row: list) -> bool:
    return not any(cell is not None and str(cell).strip() != "" for cell in row)


def row_label(row: list) -> str:
    if not row or row[0] is None:
        return ""
    return str(row[0]).strip()


def format_cell_value(value, *, money: bool = False) -> str:
    if value is None:
        return ""
    if money and isinstance(value, (int, float)):
        return f"${value:,.2f}"
    if isinstance(value, datetime):
        return value.strftime("%m/%d/%Y")
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def coerce_amount(value) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not text:
        return None
    try:
        return float(text.replace("$", "").replace(",", ""))
    except ValueError:
        return None


def sum_column(rows: list[list], col_index: int, start: int, end: int) -> float:
    total = 0.0
    found = False
    for row_idx in range(start, end + 1):
        if row_idx < 0 or row_idx >= len(rows):
            continue
        amount = coerce_amount(rows[row_idx][col_index] if col_index < len(rows[row_idx]) else None)
        if amount is not None:
            total += amount
            found = True
    return total if found else 0.0


def new_sales_total(rows: list[list], start: int, end: int, sales_col: int, date_col: int) -> float:
    total = 0.0
    found = False
    for row_idx in range(start, end + 1):
        row = rows[row_idx]
        row_date = start_date_sort_key(row, date_col + 1)
        if row_date == datetime.max or row_date <= NEW_SALES_CUTOFF:
            continue
        amount = coerce_amount(row[sales_col] if sales_col < len(row) else None)
        if amount is not None:
            total += amount
            found = True
    return total if found else 0.0


def build_display_rows(headers: list, rows: list[list]) -> tuple[list[str], list[tuple[list[str], str]]]:
    rep_col = find_rep_column(headers) - 1
    name_col = find_column_index_optional(headers, "NAME")
    if name_col is not None:
        name_col -= 1
    else:
        name_col = rep_col
    amount_col = name_col + 1
    date_col = (find_column_index_optional(headers, "START DATE") or 3) - 1

    header_labels = ["" if h is None else str(h).strip() for h in headers]
    display: list[tuple[list[str], str]] = []
    idx = 0
    group_start = 0

    while idx < len(rows):
        row = rows[idx]
        label = row_label(row)

        if label == "Yoy":
            rendered = [label]
            for col in range(1, len(header_labels)):
                if col == 1:
                    diff = sum_column(rows, amount_col, group_start, idx - 1) - sum_column(
                        rows, amount_col + 2, group_start, idx - 1
                    )
                    rendered.append(format_cell_value(diff, money=True))
                elif col in (amount_col, amount_col + 1, amount_col + 2):
                    rendered.append(
                        format_cell_value(
                            sum_column(rows, col, group_start, idx - 1),
                            money=True,
                        )
                    )
                else:
                    rendered.append("")
            display.append((rendered, "summary"))
            idx += 1
            continue

        if label == "New":
            rendered = [label]
            for col in range(1, len(header_labels)):
                if col == 1:
                    rendered.append(
                        format_cell_value(
                            new_sales_total(rows, group_start, idx - 1, amount_col, date_col),
                            money=True,
                        )
                    )
                else:
                    rendered.append("")
            display.append((rendered, "summary"))
            idx += 1
            while idx < len(rows) and is_blank_row(rows[idx]):
                idx += 1
            group_start = idx
            continue

        if is_blank_row(row):
            idx += 1
            continue

        rendered = []
        for col, value in enumerate(row):
            money = col >= amount_col and label not in ("Yoy", "New")
            rendered.append(format_cell_value(value, money=money))
        display.append((rendered, "data"))
        idx += 1

    return header_labels, display


def make_header_drawer(title: str):
    def draw_header(canvas, doc) -> None:
        canvas.saveState()
        width, height = doc.pagesize
        canvas.setFillColor(HEADER_BG)
        canvas.rect(0, height - HEADER_HEIGHT_PT, width, HEADER_HEIGHT_PT, fill=1, stroke=0)
        canvas.setFillColor(HEADER_TEXT)
        canvas.setFont("Helvetica-Bold", 18)
        canvas.drawCentredString(width / 2, height - 42, "WeeklySalesReport")
        canvas.setFont("Helvetica", 11)
        canvas.drawCentredString(width / 2, height - 62, title)
        canvas.restoreState()

    def draw_later_header(canvas, doc) -> None:
        canvas.saveState()
        width, height = doc.pagesize
        canvas.setFillColor(HEADER_BG)
        canvas.rect(0, height - 36, width, 36, fill=1, stroke=0)
        canvas.setFillColor(HEADER_TEXT)
        canvas.setFont("Helvetica-Bold", 10)
        canvas.drawCentredString(width / 2, height - 22, f"WeeklySalesReport — {title}")
        canvas.restoreState()

    return draw_header, draw_later_header


def column_widths(col_count: int, usable_width: float) -> list[float]:
    if col_count <= 0:
        return []
    if col_count == 1:
        return [usable_width]
    weights = []
    for idx in range(col_count):
        if idx == 0:
            weights.append(1.0)
        elif idx == 1:
            weights.append(1.8)
        elif idx == 2:
            weights.append(1.0)
        else:
            weights.append(1.1)
    total = sum(weights)
    return [usable_width * (weight / total) for weight in weights]


def build_pdf(fmt_path: Path, pdf_path: Path, week_ending: datetime) -> None:
    headers, rows = load_sheet_rows(fmt_path)
    header_labels, display_rows = build_display_rows(headers, rows)
    start_text, end_text = report_date_range(week_ending)
    title = f"{start_text} – {end_text}"

    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    page_size = landscape(letter)
    doc = SimpleDocTemplate(
        str(pdf_path),
        pagesize=page_size,
        leftMargin=0.45 * inch,
        rightMargin=0.45 * inch,
        topMargin=HEADER_HEIGHT_PT + 16,
        bottomMargin=0.45 * inch,
        title=f"WeeklySalesReport {title}",
        author="Rockland Bakery Bakers13",
    )

    styles = getSampleStyleSheet()
    body_left = ParagraphStyle(
        "BodyLeft",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=8.5,
        leading=10,
        textColor=BODY_TEXT,
        alignment=TA_LEFT,
    )
    body_right = ParagraphStyle(
        "BodyRight",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=8.5,
        leading=10,
        textColor=BODY_TEXT,
        alignment=TA_RIGHT,
    )
    body_center = ParagraphStyle(
        "BodyCenter",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=8.5,
        leading=10,
        textColor=BODY_TEXT,
        alignment=TA_CENTER,
    )
    summary_style = ParagraphStyle(
        "SummaryLeft",
        parent=body_left,
        fontName="Helvetica-Bold",
        textColor=TABLE_HEADER_TEXT,
    )

    table_data: list[list] = []
    header_row = [Paragraph(f"<b>{label}</b>", body_left if idx <= 2 else body_center) for idx, label in enumerate(header_labels)]
    table_data.append(header_row)

    row_styles: list[tuple[int, str]] = []
    for row_idx, (cells, kind) in enumerate(display_rows, start=1):
        rendered = []
        for col_idx, text in enumerate(cells):
            if kind == "summary" and col_idx == 0:
                rendered.append(Paragraph(text, summary_style))
            elif text.startswith("$") or re.fullmatch(r"-?\$[\d,]+\.\d{2}", text):
                rendered.append(Paragraph(text, body_right))
            elif col_idx <= 2:
                rendered.append(Paragraph(text.replace("&", "&amp;"), body_left))
            else:
                rendered.append(Paragraph(text.replace("&", "&amp;"), body_center))
        table_data.append(rendered)
        row_styles.append((row_idx, kind))

    usable_width = page_size[0] - doc.leftMargin - doc.rightMargin
    table = Table(table_data, colWidths=column_widths(len(header_labels), usable_width), repeatRows=1)
    style_commands = [
        ("BACKGROUND", (0, 0), (-1, 0), TABLE_HEADER_BG),
        ("TEXTCOLOR", (0, 0), (-1, 0), TABLE_HEADER_TEXT),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("GRID", (0, 0), (-1, -1), 0.25, TABLE_GRID),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
    ]

    data_row_index = 0
    for row_idx, kind in row_styles:
        if kind == "summary":
            style_commands.append(("BACKGROUND", (0, row_idx), (-1, row_idx), TABLE_SUMMARY_BG))
        elif kind == "data":
            if data_row_index % 2 == 1:
                style_commands.append(("BACKGROUND", (0, row_idx), (-1, row_idx), TABLE_ZEBRA))
            data_row_index += 1

    table.setStyle(TableStyle(style_commands))

    draw_header, draw_later_header = make_header_drawer(title)
    story = [Spacer(1, 6), table]
    doc.build(story, onFirstPage=draw_header, onLaterPages=draw_later_header)


def generate_pdf(fmt_path: Path, pdf_path: Path, *, week_ending: str | None = None) -> None:
    ending = resolve_week_ending(fmt_path, week_ending)
    tmp_path = pdf_path.with_suffix(pdf_path.suffix + ".tmp")
    build_pdf(fmt_path, tmp_path, ending)
    tmp_path.replace(pdf_path)


def main(argv: list[str]) -> int:
    if len(argv) not in (3, 4):
        print(
            f"usage: {Path(argv[0]).name} <input.fmt.xlsx> <output.pdf> [week_ending MM/DD/YYYY]",
            file=sys.stderr,
        )
        return 2

    fmt_path = Path(argv[1])
    pdf_path = Path(argv[2])
    week_ending = argv[3] if len(argv) == 4 else None
    generate_pdf(fmt_path, pdf_path, week_ending=week_ending)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
