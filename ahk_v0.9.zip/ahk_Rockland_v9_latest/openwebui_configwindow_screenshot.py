#!/usr/bin/env python3
"""
Capture the Bakers13 in-app report config window, resize to 240x240, and send to Open WebUI.

Configure in .env (same folder as this script):
  OPENWEBUI_BASE_URL=https://ai.nosox.xyz
  OPENWEBUI_API_TOKEN=<optional JWT or sk- API key from Settings > Account>
  OPENWEBUI_EMAIL=<optional; used to sign in when OPENWEBUI_API_TOKEN is unset>
  OPENWEBUI_PASSWORD=<optional; paired with OPENWEBUI_EMAIL>
  OPENWEBUI_MODEL=rocklanduihelper
  OPENWEBUI_CONFIGWINDOW_SCREENSHOT_WIDTH=240
  OPENWEBUI_CONFIGWINDOW_SCREENSHOT_HEIGHT=240
  OPENWEBUI_ENABLED=1

Resize fallback (when Pillow is missing) copies the full-size capture and logs the
ImageMagick-style command you would run manually:
  convert configwindow_screenshotMMDDYYYY.jpeg -resize 240x240 ConfigWindow_screenshotMMDDYYYY.jpeg

Optional: upload an existing image instead of capturing:
  python openwebui_configwindow_screenshot.py -ii path/to/image.png
"""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path

import openwebui_report_screenshot as ows

APP_ROOT = Path(__file__).resolve().parent
LOG_PATH = APP_ROOT / "OpenWebUIConfigWindow.log"
DEFAULT_WIDTH = 240
DEFAULT_HEIGHT = 240


def configwindow_prompt(config: dict[str, str]) -> str:
    return config.get(
        "OPENWEBUI_CONFIGWINDOW_SCREENSHOT_PROMPT",
        config.get(
            "OPENWEBUI_SCREENSHOT_PROMPT",
            "Bakers13 in-app report configuration window screenshot. Confirm the report "
            "configuration UI is visible and note anything that looks wrong.",
        ),
    ).strip()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Capture and send report config window screenshot (240x240) to Open WebUI"
    )
    parser.add_argument("--hwnd", type=int, default=0, help="Capture this window handle (Bakers parent window)")
    parser.add_argument("--full-screen", action="store_true", help="Capture full screen instead of a window")
    parser.add_argument("--date-stamp", default="", help="MMDDYYYY stamp for filenames (default: today)")
    parser.add_argument(
        "--test-yes-no",
        action="store_true",
        help="Test mode: full-screen capture, send to Open WebUI, exit 0=YES, 1=NO, 2=error",
    )
    parser.add_argument(
        "-ii",
        "--ii",
        dest="input_image",
        default="",
        metavar="IMAGE",
        help="Use an existing image file instead of capturing a new screenshot",
    )
    args = parser.parse_args()

    config = ows.load_config()
    input_image_path = ows.resolve_input_image(args.input_image) if args.input_image.strip() else None
    if args.input_image.strip() and not input_image_path:
        return 1

    if args.test_yes_no:
        ows.LOG_PATH = APP_ROOT / "TestOpenWebUIConfigWindow.log"
        if not input_image_path:
            args.full_screen = True
    else:
        ows.LOG_PATH = LOG_PATH
        if not input_image_path and not ows.parse_bool(config.get("OPENWEBUI_ENABLED", "1"), default=True):
            ows.log("Open WebUI config window screenshot step disabled (OPENWEBUI_ENABLED=0)")
            return 0

    date_stamp = args.date_stamp.strip() or datetime.now().strftime("%m%d%Y")
    width = int(
        config.get("OPENWEBUI_CONFIGWINDOW_SCREENSHOT_WIDTH", str(DEFAULT_WIDTH)) or str(DEFAULT_WIDTH)
    )
    height = int(
        config.get("OPENWEBUI_CONFIGWINDOW_SCREENSHOT_HEIGHT", str(DEFAULT_HEIGHT)) or str(DEFAULT_HEIGHT)
    )

    if args.test_yes_no:
        raw_name = f"test_configwindow_screenshot{date_stamp}.jpeg"
        resized_name = f"TestConfigWindow_screenshot{date_stamp}.jpeg"
        start_label = "START TestOpenWebUIConfigWindow (yes/no test)"
        complete_ok = "COMPLETE TestOpenWebUIConfigWindow: YES — Found open window"
        complete_warn = "COMPLETE TestOpenWebUIConfigWindow: finished with warnings"
    else:
        raw_name = f"configwindow_screenshot{date_stamp}.jpeg"
        resized_name = f"ConfigWindow_screenshot{date_stamp}.jpeg"
        start_label = "START openwebui_configwindow_screenshot"
        complete_ok = "COMPLETE openwebui_configwindow_screenshot: image sent to Open WebUI"
        complete_warn = (
            "COMPLETE openwebui_configwindow_screenshot with warnings: screenshot files saved locally; "
            "Open WebUI API upload did not succeed"
        )

    raw_path = APP_ROOT / raw_name
    resized_path = APP_ROOT / resized_name
    prompt = configwindow_prompt(config)

    ows.log(start_label)
    if input_image_path:
        ows.log(f"Using existing input image (-ii): {input_image_path}")
        upload_path = input_image_path
    else:
        if not ows.capture_screenshot(raw_path, hwnd=args.hwnd, full_screen=args.full_screen):
            ows.log("FAIL screenshot capture did not complete")
            return 1

        ows.resize_screenshot(raw_path, resized_path, width, height)
        upload_path = resized_path

    if args.test_yes_no:
        return ows.run_test_yes_no_flow(upload_path, config)

    content = ows.send_to_openwebui(upload_path, config, prompt_override=prompt)
    if content is not None:
        ows.log(complete_ok)
        return 0

    ows.log(complete_warn)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
