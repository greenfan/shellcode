#!/usr/bin/env python3
"""
web_control.py

web UI dashboard for starting and controlling reports from Bakers13.


"""

from __future__ import annotations

import argparse
import csv
import logging
import os
import sys
import re
import shutil
import smtplib
import socket
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
from dataclasses import dataclass
from datetime import datetime
from email.message import EmailMessage
from io import BytesIO
from pathlib import Path
from typing import Any, Callable

from flask import Flask, abort, jsonify, redirect, render_template, request, send_file, url_for
from openpyxl import Workbook


APP_ROOT = Path(__file__).resolve().parent
RUN_LOG_DIR = APP_ROOT / "web_ahk_runs"
REPORT_CACHE_DIR = APP_ROOT / "web_report_cache"
AHK_EXE_NAMES = ("AutoHotkey64.exe", "AutoHotkey.exe", "AutoHotkey32.exe")

AUTO_REFRESH_SECONDS = 12
TRANDATA_DIR = Path(os.environ.get("REPORT_TRANDATA_DIR", r"\\Rb-rossbd\baker\Bakers13\trandata"))
RECENT_REPORT_LIMIT = int(os.environ.get("RECENT_REPORT_LIMIT", "4"))
REPORTS_PAGE_LIMIT = int(os.environ.get("REPORTS_PAGE_LIMIT", "0"))
REPORT_CACHE_AUTO_REFRESH_SECONDS = int(os.environ.get("REPORT_CACHE_AUTO_REFRESH_SECONDS", "120"))
REPORT_CACHE_SCAN_SAMPLE_LIMIT = int(os.environ.get("REPORT_CACHE_SCAN_SAMPLE_LIMIT", "12"))
REPORT_FRESHNESS_SECONDS = int(os.environ.get("REPORT_FRESHNESS_SECONDS", "2200"))
EMAIL_SMTP_TIMEOUT_SECONDS = int(os.environ.get("EMAIL_SMTP_TIMEOUT_SECONDS", "10"))
EMAIL_REPORT_LOOKUP_TIMEOUT_SECONDS = int(os.environ.get("EMAIL_REPORT_LOOKUP_TIMEOUT_SECONDS", "90"))
EMAIL_XLSX_BUILD_TIMEOUT_SECONDS = int(os.environ.get("EMAIL_XLSX_BUILD_TIMEOUT_SECONDS", "180"))
EMAIL_FORMAT_XLSX_TIMEOUT_SECONDS = int(
    os.environ.get("EMAIL_FORMAT_XLSX_TIMEOUT_SECONDS", "300")
)
AHK_POST_RUN_CLOSE_NOTEPAD = os.environ.get("AHK_POST_RUN_CLOSE_NOTEPAD", "1").strip().lower() not in (
    "0",
    "false",
    "no",
)
AHK_POST_RUN_BAKERS_IMAGE = os.environ.get("AHK_POST_RUN_BAKERS_IMAGE", "BAKER32.EXE").strip() or "BAKER32.EXE"
AHK_POST_RUN_CLEANUP_ON_SUCCESS = os.environ.get("AHK_POST_RUN_CLEANUP_ON_SUCCESS", "1").strip().lower() not in (
    "0",
    "false",
    "no",
)
AHK_POST_RUN_CLEANUP_ON_FAILURE = os.environ.get("AHK_POST_RUN_CLEANUP_ON_FAILURE", "0").strip().lower() in (
    "1",
    "true",
    "yes",
)

# AHK logs this line (DailySales_run.ahk / WeeklySalesRun1.ahk WaitForFreshTrandataReport).
AHK_LOG_NEWEST_TRANDATA_PREFIX = "Newest trandata file:"

# Internal/helper scripts: runnable by other AHK workflows but hidden from web_control buttons.
WEB_UI_HIDDEN_AHK_SCRIPTS = frozenset(
    {
        "ReportDelivery.ahk",
        "TestOpenWebUIScreenshot.ahk",
    }
)
REPORT_CACHE_FILENAME_RE = re.compile(r".*[0-9]\.csv$", re.IGNORECASE)
# Timestamped (primary): matches FileAppend / stdout lines from Log().
NEWEST_TRANDATA_LINE_RE = re.compile(
    r"(?P<ts>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s*\|\s*Newest\s+trandata\s+file\s*[:：]\s*(?P<path>.+?)\s+modified\s*=",
    re.IGNORECASE,
)
# Fallback when the timestamp prefix is missing or mangled.
NEWEST_TRANDATA_FALLBACK_RE = re.compile(
    r"(?i)Newest\s+trandata\s+file\s*[:：]\s*(?P<path>.+?)\s+modified\s*=",
)
TRANSDATA_READINESS_RETRIES = int(os.environ.get("TRANSDATA_READINESS_RETRIES", "16"))
TRANSDATA_READINESS_DELAY_MS = int(os.environ.get("TRANSDATA_READINESS_DELAY_MS", "250"))
EMAIL_FALLBACK_TRANDATA_FOLDER_SCAN = os.environ.get("EMAIL_FALLBACK_TRANDATA_FOLDER_SCAN", "").strip().lower() in (
    "1",
    "true",
    "yes",
)

REPORT_CACHE_LOCK = threading.Lock()
REPORT_CACHE_REFRESHING = False
REPORT_CACHE_LAST_REFRESH: datetime | None = None
REPORT_CACHE_LAST_ERROR = "report cache has not refreshed yet"


# =============================================================================

EMAIL_CONFIG_OVERRIDES = {
    # You may hardcode values here if you really want zero external files.
    # Leave blank to use environment variables, .env, or text2.md.
    "FASTMAIL_SMTP_USERNAME": "rdwyer@fastmail.com",
    "FASTMAIL_SMTP_APP_PASSWORD": "367t3e6f399b997t",
    "REPORT_EMAIL_FROM": "rdwyer@fastmail.com",
    "REPORT_EMAIL_TO": "rdwyer@fastmail.com,andrew@broadbandtelatom.com",
    "REPORT_TEST_EMAIL_TO": "rdwyer@fastmail.com",
    "FASTMAIL_SMTP_HOST": "smtp.fastmail.com",
    "FASTMAIL_SMTP_PORT": "465",
}


class QuietStatic304ReassuranceFilter(logging.Filter):
    """Drop noisy Werkzeug lines for unchanged static files; throttle a short nominal note."""

    def __init__(self, throttle_seconds: float = float(AUTO_REFRESH_SECONDS)) -> None:
        super().__init__()
        self.throttle_seconds = throttle_seconds
        self._last_reassurance_s = 0.0

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        if "GET /static/" not in msg or "304" not in msg:
            return True
        now = time.monotonic()
        if now - self._last_reassurance_s >= self.throttle_seconds:
            print(
                "[ahk_webcontrol_app] running nominally: HTTP 304 on /static/ means the browser reused cached CSS; healthy.",
                flush=True,
            )
            self._last_reassurance_s = now
        return False


@dataclass
class WebRun:
    run_id: int
    script_name: str
    process: subprocess.Popen[str]
    log_path: Path
    started_at: datetime
    finished_at: datetime | None = None
    exit_code: int | None = None

    @property
    def status(self) -> str:
        return "running" if self.process.poll() is None else f"exited {self.process.returncode}"

    @property
    def is_running(self) -> bool:
        return self.process.poll() is None


# =============================================================================
# EMAIL NOTIFICATION IMPLEMENTATION
# =============================================================================
# The code below is intentionally kept together and heavily labeled so future
# edits are easy. WeeklySalesRun1 queues email automatically on success; any
# finished run can still be emailed manually from the web UI.
# =============================================================================

AUTO_EMAIL_SCRIPT_NAMES = frozenset({"WeeklySalesRun1.ahk"})


@dataclass(frozen=True)
class EmailSettings:
    enabled: bool
    smtp_host: str
    smtp_port: int
    username: str
    app_password: str
    sender: str
    recipients: list[str]
    test_recipient: str

    @classmethod
    def from_env(cls) -> "EmailSettings":
        config = load_email_config()
        username = (
            config.get("FASTMAIL_SMTP_USERNAME", "")
            or config.get("FASTMAIL_USERNAME", "")
            or config.get("FASTMAIL_EMAIL", "")
        ).strip()
        app_password = (
            config.get("FASTMAIL_SMTP_APP_PASSWORD", "")
            or config.get("FASTMAIL_APP_PASSWORD", "")
            or config.get("FASTMAIL_PASSWORD", "")
        ).strip()
        sender = config.get("REPORT_EMAIL_FROM", username).strip()
        test_recipient = config.get("REPORT_TEST_EMAIL_TO", username).strip()
        raw_recipients = config.get("REPORT_EMAIL_TO", test_recipient or username)
        recipients = [
            item.strip()
            for item in raw_recipients.split(",")
            if item.strip()
        ]
        enabled = bool(username and app_password and sender and recipients)

        return cls(
            enabled=enabled,
            smtp_host=config.get("FASTMAIL_SMTP_HOST", "smtp.fastmail.com").strip(),
            smtp_port=int(config.get("FASTMAIL_SMTP_PORT", "465")),
            username=username,
            app_password=app_password,
            sender=sender,
            recipients=recipients,
            test_recipient=test_recipient,
        )

    def diagnostic_summary(self) -> str:
        missing: list[str] = []
        if not self.username:
            missing.append("FASTMAIL_SMTP_USERNAME")
        if not self.app_password:
            missing.append("FASTMAIL_SMTP_APP_PASSWORD")
        if not self.sender:
            missing.append("REPORT_EMAIL_FROM")
        if not self.recipients:
            missing.append("REPORT_EMAIL_TO")

        if missing:
            return "email disabled; missing " + ", ".join(missing)
        return (
            f"email enabled via {self.smtp_host}:{self.smtp_port}; "
            f"from={self.sender}; to={', '.join(self.recipients)}"
        )


@dataclass(frozen=True)
class EmailAttachment:
    data: bytes
    filename: str
    maintype: str
    subtype: str


@dataclass(frozen=True)
class ScriptInfo:
    name: str
    path: Path
    modified_at: str
    size_bytes: int


@dataclass(frozen=True)
class RecentReport:
    source_path: Path
    source_name: str
    cached_csv_name: str
    cached_xlsx_name: str | None
    cached_fmt_xlsx_name: str | None
    modified_at: datetime
    size_bytes: int
    status: str


FORMAT_XLSX_SCRIPT = APP_ROOT / "format_report_xlsx.py"
GENERATE_PDF_SCRIPT = APP_ROOT / "generate_report_pdf.py"


def load_email_config() -> dict[str, str]:
    config: dict[str, str] = {}

    for path in (APP_ROOT / ".env", APP_ROOT / "text2.md"):
        config.update(read_key_value_file(path))

    for key in EMAIL_CONFIG_OVERRIDES:
        env_value = os.environ.get(key, "").strip()
        if env_value:
            config[key] = env_value

    for key, value in EMAIL_CONFIG_OVERRIDES.items():
        value = value.strip()
        if value:
            config[key] = value

    return config


def read_key_value_file(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}

    values: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue

        # Accept markdown bullets such as "- KEY=value" or "* KEY: value".
        if line[:2] in ("- ", "* "):
            line = line[2:].strip()

        if "=" in line:
            key, value = line.split("=", 1)
        elif ":" in line:
            key, value = line.split(":", 1)
        else:
            continue

        key = key.strip().strip("`").strip()
        value = value.strip().strip("`").strip().strip('"').strip("'")
        if key:
            values[key] = value

    return values


def local_ipv4_addresses() -> list[str]:
    """Best-effort LAN IPv4 list for printing remote dashboard URLs."""
    addresses: list[str] = []
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(("8.8.8.8", 80))
            route_ip = sock.getsockname()[0]
            if route_ip and not route_ip.startswith("127."):
                addresses.append(route_ip)
    except OSError:
        pass

    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET, socket.SOCK_STREAM):
            ip = info[4][0]
            if ip.startswith("127.") or ip in addresses:
                continue
            addresses.append(ip)
    except OSError:
        pass

    return addresses


def lan_bind_urls(port: int, token: str | None = None) -> list[str]:
    """Build http://<ipv4>:port URLs for remote machines on the LAN."""
    urls: list[str] = []
    query = f"?token={token}" if token else ""
    suffix = f"/{query}" if query else "/"
    for ip in local_ipv4_addresses():
        url = f"http://{ip}:{port}{suffix}"
        if url not in urls:
            urls.append(url)

    if not urls:
        urls.append(f"http://127.0.0.1:{port}{suffix}")
    return urls


def parse_bind_ports(raw: str) -> list[int]:
    ports: list[int] = []
    for part in raw.split(","):
        part = part.strip()
        if part:
            ports.append(int(part))
    if not ports:
        raise ValueError("At least one port is required.")
    return sorted(set(ports))


def primary_bind_port(ports: list[int]) -> int:
    return 42001 if 42001 in ports else ports[0]


def serve_werkzeug(app: Flask, host: str, port: int) -> None:
    from werkzeug.serving import make_server

    server = make_server(host, port, app, threaded=True)
    print(f"[ahk_webcontrol_app] listening on http://{host}:{port}/", flush=True)
    server.serve_forever()


def run_on_bind_ports(app: Flask, host: str, ports: list[int]) -> None:
    if len(ports) == 1:
        serve_werkzeug(app, host, ports[0])
        return

    for port in ports[:-1]:
        thread = threading.Thread(
            target=serve_werkzeug,
            args=(app, host, port),
            name=f"web_control_{port}",
            daemon=True,
        )
        thread.start()

    serve_werkzeug(app, host, ports[-1])


def interactive_session_warning() -> str | None:
    """Warn when Flask/AHK likely runs outside an interactive RDP/console session."""
    if os.name != "nt":
        return None

    session_name = os.environ.get("SESSIONNAME", "").strip()
    if not session_name:
        return (
            "SESSIONNAME is unset. web_control.py is probably not running inside the logged-in "
            "RDP desktop. GUI scripts will fail to focus windows."
        )

    upper = session_name.upper()
    if upper == "CONSOLE" or upper.startswith("RDP-TCP"):
        return None

    return (
        f"Windows session is {session_name!r}, not Console/RDP-Tcp. "
        "Start web_control.py from a command prompt opened inside the active RDP session."
    )


def rdp_session_keepalive_hint() -> str:
    """Reminder for keeping the automation desktop interactive after disconnect."""
    return (
        "After RDP connect, start web_control.py from cmd inside that session. "
        "To disconnect without locking the desktop: query session → tscon <id> /dest:console "
        "(elevated cmd on the server). Scripts are calibrated for 1280x800 and the observed "
        "1597x812 tscon console resolution. "
        "Do not Sign out or close RDP with X if you need unattended GUI automation."
    )


def request_access_token(access_token: str | None) -> str | None:
    if not access_token:
        return None
    token = (
        request.args.get("token")
        or request.headers.get("X-Control-Token")
        or request.cookies.get("ahk_web_token")
        or request.form.get("token")
    )
    if token:
        return token.strip()
    return None


def windows_session_summary() -> str:
    fields = {
        "os": os.name,
        "computer": os.environ.get("COMPUTERNAME", ""),
        "user": os.environ.get("USERNAME", "") or os.environ.get("USER", ""),
        "domain": os.environ.get("USERDOMAIN", ""),
        "session": os.environ.get("SESSIONNAME", ""),
        "client": os.environ.get("CLIENTNAME", ""),
    }
    return "; ".join(f"{key}={value or '(unset)'}" for key, value in fields.items())


def append_timestamped_run_log(log_path: Path, message: str) -> None:
    line = f"{datetime.now().isoformat(timespec='seconds')} {message}\n"
    with log_path.open("a", encoding="utf-8") as log_file:
        log_file.write(line)


def run_callable_with_timeout(fn: Callable[[], Any], timeout_seconds: float) -> tuple[Any | None, bool]:
    """
    Run fn in a worker thread; return (result, timed_out).
    On timeout the worker may keep running in the background until fn completes.
    """
    if timeout_seconds <= 0:
        return fn(), False
    with ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(fn)
        try:
            return future.result(timeout=timeout_seconds), False
        except FuturesTimeoutError:
            return None, True


def graceful_close_windows_process_image(image_name: str, log_append: Callable[[str], None]) -> None:
    """
    Ask Windows to close matching processes without /F (GUI apps get WM_CLOSE-style shutdown).
    """
    if os.name != "nt":
        log_append(f"Skip closing {image_name}: not Windows.\n")
        return
    cmd = ["taskkill", "/IM", image_name, "/T"]
    log_append(f"Post-run: invoking {' '.join(cmd)} (graceful, no /F)\n")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=45)
        detail = f"exit={proc.returncode}"
        if proc.stdout.strip():
            detail += f"; stdout={proc.stdout.strip()}"
        if proc.stderr.strip():
            detail += f"; stderr={proc.stderr.strip()}"
        log_append(f"Post-run: taskkill result for {image_name}: {detail}\n")
    except subprocess.TimeoutExpired:
        log_append(f"Post-run: taskkill timed out after 45s for {image_name}\n")
    except OSError as err:
        log_append(f"Post-run: taskkill failed for {image_name}: {err}\n")


def post_run_graceful_cleanup_windows(
    log_append: Callable[[str], None],
    exit_code: int | None,
    script_name: str | None = None,
) -> None:
    """Close Notepad report windows and the Bakers desktop client after the AHK runner exits."""
    if os.name != "nt":
        return

    should_cleanup = (
        AHK_POST_RUN_CLEANUP_ON_SUCCESS
        if exit_code == 0
        else AHK_POST_RUN_CLEANUP_ON_FAILURE
    )
    if not should_cleanup:
        log_append(
            "Post-run cleanup skipped: "
            f"exit_code={exit_code}; preserving Bakers/Notepad windows for diagnosis. "
            "Set AHK_POST_RUN_CLEANUP_ON_FAILURE=1 to close them after failures.\n"
        )
        return

    log_append(
        "Post-run cleanup: AutoHotkey process has exited; closing helper apps "
        "(this does not gate email — email runs separately).\n"
    )
    if AHK_POST_RUN_CLOSE_NOTEPAD:
        graceful_close_windows_process_image("notepad.exe", log_append)
    else:
        log_append("Post-run: skipping Notepad close (AHK_POST_RUN_CLOSE_NOTEPAD disabled).\n")

    keep_bakers_for_init = (
        script_name is not None
        and script_name.lower() == "bakers_init.ahk"
        and exit_code == 0
    )
    if keep_bakers_for_init:
        log_append(
            "Post-run: keeping Bakers open after successful bakers_init.ahk "
            "(so a follow-up WeeklySalesRun1 can continue without relaunching).\n"
        )
        return

    graceful_close_windows_process_image(AHK_POST_RUN_BAKERS_IMAGE, log_append)


class AhkWebController:
    def __init__(self, ahk_exe: Path, cwd: Path) -> None:
        self.ahk_exe = ahk_exe
        self.cwd = cwd
        self.email_settings = EmailSettings.from_env()
        self.runs: dict[int, WebRun] = {}
        self.next_run_id = 1
        self.lock = threading.Lock()
        RUN_LOG_DIR.mkdir(exist_ok=True)

    def scripts(self) -> list[Path]:
        return sorted(
            path
            for path in self.cwd.glob("*.ahk")
            if path.is_file() and path.name not in WEB_UI_HIDDEN_AHK_SCRIPTS
        )

    def scripts_info(self) -> list[ScriptInfo]:
        items: list[ScriptInfo] = []
        for path in self.scripts():
            try:
                stat = path.stat()
                modified_at = datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds")
                size_bytes = stat.st_size
            except OSError:
                modified_at = "unknown"
                size_bytes = 0
            items.append(
                ScriptInfo(
                    name=path.name,
                    path=path,
                    modified_at=modified_at,
                    size_bytes=size_bytes,
                )
            )
        return items

    def script_by_name(self, script_name: str) -> Path | None:
        normalized = Path(script_name).name.strip()
        if not normalized:
            return None
        for path in self.scripts():
            if path.name == normalized:
                return path
        return None

    def start(self, script_name: str) -> WebRun:
        script = self.script_by_name(script_name)
        if script is None:
            raise ValueError(f"Unknown script: {script_name}")

        with self.lock:
            run_id = self.next_run_id
            self.next_run_id += 1

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = RUN_LOG_DIR / f"{script.stem}_{stamp}_run{run_id}.log"
        command = [str(self.ahk_exe), "/ErrorStdOut", str(script)]
        session_summary = windows_session_summary()
        log_path.write_text(
            f"Command: {command}\n"
            f"Started: {datetime.now().isoformat(timespec='seconds')}\n"
            f"Launcher session: {session_summary}\n\n",
            encoding="utf-8",
        )

        stdout_file = log_path.open("a", encoding="utf-8")
        process = subprocess.Popen(
            command,
            cwd=str(self.cwd),
            stdout=stdout_file,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )

        run = WebRun(
            run_id=run_id,
            script_name=script.name,
            process=process,
            log_path=log_path,
            started_at=datetime.now(),
        )

        with self.lock:
            self.runs[run_id] = run

        stdout_file.write(f"Email settings at launch: {self.email_settings.diagnostic_summary()}\n")
        stdout_file.flush()

        threading.Thread(
            target=self._monitor_run_when_done,
            args=(run, stdout_file),
            name=f"ahk_monitor_run_{run.run_id}",
            daemon=True,
        ).start()
        return run

    def stop(self, run_id: int) -> bool:
        run = self.runs.get(run_id)
        if run is None or not run.is_running:
            return False

        run.process.terminate()
        try:
            run.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            run.process.kill()
        return True

    def snapshot(self) -> list[dict[str, object]]:
        with self.lock:
            runs = sorted(self.runs.values(), key=lambda item: item.run_id, reverse=True)

        return [
            {
                "run_id": run.run_id,
                "script_name": run.script_name,
                "status": run.status,
                "running": run.is_running,
                "started_at": run.started_at.isoformat(timespec="seconds"),
                "log_name": run.log_path.name,
                "can_email": not run.is_running,
            }
            for run in runs
        ]

    def _monitor_run_when_done(self, run: WebRun, stdout_file) -> None:
        run.process.wait()
        finished_at = datetime.now()
        exit_code = run.process.returncode
        run.finished_at = finished_at
        run.exit_code = exit_code
        stdout_file.write(f"\nExited: {finished_at.isoformat(timespec='seconds')}\n")
        stdout_file.write(f"Exit code: {exit_code}\n")
        stdout_file.flush()

        def append_log(msg: str) -> None:
            stdout_file.write(msg)
            stdout_file.flush()

        post_run_graceful_cleanup_windows(log_append=append_log, exit_code=exit_code, script_name=run.script_name)

        auto_email = (
            exit_code == 0
            and Path(run.script_name).name in AUTO_EMAIL_SCRIPT_NAMES
            and self.email_settings.enabled
        )
        if auto_email:
            append_log("Email notification: queued automatically after WeeklySalesRun1.\n")
            threading.Thread(
                target=self._send_email_for_completed_run,
                args=(run, finished_at, exit_code),
                name=f"ahk_email_run_{run.run_id}",
                daemon=True,
            ).start()
            print(
                f"[ahk_webcontrol_app] run {run.run_id} finished with exit {exit_code}; "
                "email notification queued (formatted xlsx attachment)",
                flush=True,
            )
        else:
            append_log(
                "Email notification: skipped automatically; use the web UI email button to send manually.\n"
            )
            print(
                f"[ahk_webcontrol_app] run {run.run_id} finished with exit {exit_code}; "
                "email notification not queued",
                flush=True,
            )
        stdout_file.close()

        if exit_code == 0:
            maybe_start_report_cache_refresh(force=True)
    
    def send_email_for_run(self, run_id: int) -> bool:
        run = self.runs.get(run_id)
        if run is None or run.is_running:
            return False
        finished_at = run.finished_at or datetime.now()
        exit_code = run.exit_code if run.exit_code is not None else run.process.returncode
        append_timestamped_run_log(run.log_path, "Email notification: manually queued from web UI.")
        threading.Thread(
            target=self._send_email_for_completed_run,
            args=(run, finished_at, exit_code),
            name=f"ahk_email_run_{run.run_id}",
            daemon=True,
        ).start()
        return True

    def _send_email_for_completed_run(
        self,
        run: WebRun,
        finished_at: datetime,
        exit_code: int | None,
    ) -> None:
        append_timestamped_run_log(
            run.log_path,
            "Email notification: background sender thread entered (independent of Bakers13/notepad processes).",
        )

        try:
            send_report_email(self.email_settings, run, finished_at, exit_code)
        except Exception as err:
            append_timestamped_run_log(run.log_path, f"Email notification failed: {err}")
            print(f"[ahk_webcontrol_app] email notification failed for run {run.run_id}: {err}", flush=True)

def build_csv_attachment_bytes(report_file: Path) -> EmailAttachment | None:
    try:
        return EmailAttachment(
            data=report_file.read_bytes(),
            filename=report_file.name,
            maintype="text",
            subtype="csv",
        )
    except OSError as read_err:
        print(f"[ahk_webcontrol_app] could not read CSV for fallback attach: {read_err}", flush=True)
        return None


def clean_trandata_path_str(raw: str) -> str:
    return raw.strip().strip('"').strip("'")


def email_resolution_log_paths(run: WebRun) -> list[Path]:
    """
    Prefer script-local disk logs first (same lines FileAppend writes), then the web capture log last.

    DailySales_run.ahk writes WeeklySalesRun1.log, so include that file when running DailySales_run.
    """
    script_stem = Path(run.script_name).stem
    disk_log = APP_ROOT / f"{script_stem}.log"
    weekly = APP_ROOT / "WeeklySalesRun1.log"

    ordered: list[Path] = []
    ordered.append(disk_log)
    if script_stem.lower() == "dailysales_run":
        ordered.append(weekly)
    elif disk_log.resolve() != weekly.resolve():
        ordered.append(weekly)
    ordered.append(run.log_path)

    seen: set[Path] = set()
    uniq: list[Path] = []
    for path_item in ordered:
        try:
            resolved_item = path_item.resolve()
        except OSError:
            resolved_item = path_item
        if resolved_item not in seen:
            seen.add(resolved_item)
            uniq.append(path_item)
    return uniq


def scan_logs_for_trandata_csv_path(log_paths: list[Path]) -> tuple[str | None, str]:
    best_ts: datetime | None = None
    best_path: str | None = None
    fallback_last: str | None = None
    notes: list[str] = []

    for log_file in log_paths:
        label = log_file.name
        if not log_file.exists():
            notes.append(f"{label}: absent")
            continue
        try:
            raw_text = log_file.read_text(encoding="utf-8", errors="replace")
        except OSError as err:
            notes.append(f"{label}: read failed ({err})")
            continue

        text = (
            raw_text.replace("\x00", "")
            .replace("\r\n", "\n")
            .replace("\r", "\n")
            .lstrip("\ufeff")
        )

        for match in NEWEST_TRANDATA_LINE_RE.finditer(text):
            ts_raw = match.group("ts").strip()
            path_raw = clean_trandata_path_str(match.group("path"))
            try:
                ts = datetime.strptime(ts_raw, "%Y-%m-%d %H:%M:%S")
            except ValueError:
                continue
            if best_ts is None or ts >= best_ts:
                best_ts = ts
                best_path = path_raw

        for match in NEWEST_TRANDATA_FALLBACK_RE.finditer(text):
            fallback_last = clean_trandata_path_str(match.group("path"))

        notes.append(f"{label}: scanned")

    chosen = best_path if best_path is not None else fallback_last
    return chosen, ", ".join(notes) if notes else "no log inputs"


def wait_for_trandata_readable(path: Path) -> tuple[Path | None, str]:
    """Return (resolved_path, '') once bytes can be read, else (None, last_error_message)."""
    last_err = ""
    delay_s = max(0.05, TRANSDATA_READINESS_DELAY_MS / 1000.0)
    for attempt in range(1, TRANSDATA_READINESS_RETRIES + 1):
        try:
            path.stat()
            with path.open("rb") as handle:
                handle.read(1)
            return path.resolve(), ""
        except OSError as err:
            last_err = str(err)
            if attempt < TRANSDATA_READINESS_RETRIES:
                time.sleep(delay_s)
    return None, last_err


def resolve_trandata_csv_for_email(run: WebRun, log_sources: list[Path] | None = None) -> tuple[Path | None, str]:
    """Locate CSV path from AHK logs and verify readability (UNC-safe retries)."""
    sources = log_sources if log_sources is not None else email_resolution_log_paths(run)
    raw_path, scan_note = scan_logs_for_trandata_csv_path(sources)
    if not raw_path:
        return None, f"no matching '{AHK_LOG_NEWEST_TRANDATA_PREFIX}' line ({scan_note})"

    candidate = Path(clean_trandata_path_str(raw_path))
    ready, err = wait_for_trandata_readable(candidate)
    if ready is not None:
        return ready, f"verified readable ({scan_note})"

    return None, f"parsed '{candidate}' from logs but file unreadable after retries: {err} ({scan_note})"


def send_report_email(
    settings: EmailSettings,
    run: WebRun,
    finished_at: datetime,
    exit_code: int | None,
) -> None:
    def progress(message: str) -> None:
        append_timestamped_run_log(run.log_path, f"Email notification: {message}")
        print(f"[ahk_webcontrol_app] run {run.run_id} email: {message}", flush=True)

    progress(
        "Background send started. "
        "Only begins after the AutoHotkey runner process exits; "
        "it does not wait on Bakers13 or Notepad unless a step below blocks on disk/network."
    )

    if not settings.enabled:
        progress(f"skipped ({settings.diagnostic_summary()})")
        return

    log_sources = email_resolution_log_paths(run)
    progress(
        f"step 1/4: resolving CSV from AHK logs ({AHK_LOG_NEWEST_TRANDATA_PREFIX} …); "
        f"sources={', '.join(p.name for p in log_sources)}"
    )
    t_lookup = time.monotonic()
    report_file, step1_diag = resolve_trandata_csv_for_email(run, log_sources)
    lookup_elapsed = time.monotonic() - t_lookup

    if report_file is not None:
        progress(f"step 1/4: done in {lookup_elapsed*1000:.0f}ms; using {report_file} ({step1_diag})")
    elif EMAIL_FALLBACK_TRANDATA_FOLDER_SCAN:
        progress(
            f"step 1/4: log parse/read failed ({step1_diag}); fallback folder scan "
            f"(timeout {EMAIL_REPORT_LOOKUP_TIMEOUT_SECONDS}s): {TRANDATA_DIR}"
        )
        report_file, lookup_timed_out = run_callable_with_timeout(
            lambda: find_freshest_report_file(TRANDATA_DIR, REPORT_FRESHNESS_SECONDS),
            float(EMAIL_REPORT_LOOKUP_TIMEOUT_SECONDS),
        )
        lookup_elapsed = time.monotonic() - t_lookup
        if lookup_timed_out:
            progress(
                f"step 1/4: fallback scan timed out after {EMAIL_REPORT_LOOKUP_TIMEOUT_SECONDS}s "
                f"(waited {lookup_elapsed:.1f}s) — continuing without attachment"
            )
            report_file = None
        elif report_file is not None:
            progress(f"step 1/4: fallback scan found fresh file: {report_file}")
        else:
            progress(
                f"step 1/4: fallback scan found no file newer than {REPORT_FRESHNESS_SECONDS}s"
            )
    else:
        progress(
            f"step 1/4: done in {lookup_elapsed*1000:.0f}ms; could not open CSV from logs ({step1_diag}). "
            f"Set EMAIL_FALLBACK_TRANDATA_FOLDER_SCAN=1 to scan {TRANDATA_DIR}."
        )

    report_attachment: EmailAttachment | None = None
    if report_file is not None:
        progress(
            f"step 2/4: building formatted .fmt.xlsx (format_report_xlsx.py; timeout "
            f"{EMAIL_FORMAT_XLSX_TIMEOUT_SECONDS}s)"
        )
        t_attach = time.monotonic()
        report_attachment, attach_timed_out = run_callable_with_timeout(
            lambda: build_report_attachment(report_file),
            float(EMAIL_FORMAT_XLSX_TIMEOUT_SECONDS),
        )
        attach_elapsed = time.monotonic() - t_attach
        if attach_timed_out:
            progress(
                f"step 2/4: formatted xlsx timed out after {EMAIL_FORMAT_XLSX_TIMEOUT_SECONDS}s "
                f"({attach_elapsed:.1f}s elapsed); no attachment sent (Fmt required for email)"
            )
            report_attachment = None
        elif report_attachment:
            if not report_attachment.filename.endswith(".fmt.xlsx"):
                progress(
                    f"step 2/4: refusing non-formatted attachment {report_attachment.filename}; "
                    "expected .fmt.xlsx"
                )
                report_attachment = None
            else:
                progress(
                    f"step 2/4: formatted attachment ready in {attach_elapsed:.1f}s "
                    f"({report_attachment.filename})"
                )
        else:
            progress(f"step 2/4: finished in {attach_elapsed:.1f}s with no formatted attachment")

    today = finished_at.strftime("%m/%d/%Y")
    outcome = f"exit {exit_code}"
    if report_attachment:
        if report_attachment.subtype == "vnd.openxmlformats-officedocument.spreadsheetml.sheet":
            attachment_note = (
                "Full data is attached as the formatted Excel workbook (.fmt.xlsx). "
                f"Attachment name: {report_attachment.filename}"
            )
        else:
            attachment_note = (
                "Full data is attached as the original CSV (Excel conversion failed). "
                f"Attachment name: {report_attachment.filename}"
            )
    elif report_file is not None:
        attachment_note = (
            "A fresh report file was found on disk but could not be attached "
            "(XLSX build or file read failed; check server logs)."
        )
    else:
        attachment_note = (
            "No attachment (missing or unreadable 'Newest trandata file:' path from the AHK run log, "
            "or optional folder fallback found nothing)."
        )

    report_section = build_report_email_section(report_file, attachment_note)
    body = (
        "Rockland Bakers13 Automated Report\n"
        "===================================\n\n"
        f"the report has completed. {today}\n\n"
        "Run Summary\n"
        "-----------\n"
        f"Script:   {run.script_name}\n"
        f"Run ID:   {run.run_id}\n"
        f"Status:   {outcome}\n"
        f"Finished: {finished_at.isoformat(timespec='seconds')}\n\n"
        f"{report_section}"
    )

    progress(
        f"step 3/4: composed message body; recipients={', '.join(settings.recipients)}; "
        f"{settings.diagnostic_summary()}"
    )

    progress(
        f"step 4/4: SMTP SSL to {settings.smtp_host}:{settings.smtp_port} "
        f"(socket timeout {EMAIL_SMTP_TIMEOUT_SECONDS}s)"
    )
    t_smtp = time.monotonic()
    send_fastmail_message(
        settings=settings,
        recipients=settings.recipients,
        subject="auto_report",
        body=body,
        attachment=report_attachment,
    )
    smtp_elapsed = time.monotonic() - t_smtp
    progress(f"step 4/4: SMTP finished OK in {smtp_elapsed:.1f}s")


def find_freshest_report_file(folder: Path, freshness_seconds: int) -> Path | None:
    try:
        files = [path for path in folder.iterdir() if path.is_file()]
    except OSError as err:
        print(f"[ahk_webcontrol_app] could not inspect report folder {folder}: {err}", flush=True)
        return None

    if not files:
        return None

    newest = max(files, key=lambda path: path.stat().st_mtime)
    age_seconds = time.time() - newest.stat().st_mtime
    if age_seconds <= freshness_seconds:
        return newest.resolve()

    print(
        f"[ahk_webcontrol_app] newest report file is too old for email include: {newest} age={age_seconds:.0f}s",
        flush=True,
    )
    return None


def csv_file_to_xlsx_bytes(csv_path: Path) -> bytes:
    last_decode_error: UnicodeDecodeError | None = None
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        wb = Workbook()
        ws = wb.active
        try:
            with csv_path.open("r", encoding=encoding, newline="") as handle:
                for row in csv.reader(handle):
                    ws.append(row)
            buffer = BytesIO()
            wb.save(buffer)
            return buffer.getvalue()
        except UnicodeDecodeError as exc:
            last_decode_error = exc
            continue
    if last_decode_error:
        raise last_decode_error
    raise OSError(f"unable to decode CSV report: {csv_path}")


def build_report_attachment(report_file: Path | None) -> EmailAttachment | None:
    """Email always uses Fmt output (.fmt.xlsx), same as the reports page Fmt button."""
    if report_file is None:
        return None

    try:
        cached_csv = cache_report_csv(report_file)
        fmt_path = ensure_formatted_xlsx(cached_csv, force=True)
        if not fmt_path.is_file():
            raise RuntimeError(f"formatted workbook missing after Fmt: {fmt_path}")
        print(
            f"[ahk_webcontrol_app] email attachment: formatted {fmt_path.name} "
            f"({fmt_path.stat().st_size} bytes)",
            flush=True,
        )
        return EmailAttachment(
            data=fmt_path.read_bytes(),
            filename=fmt_path.name,
            maintype="application",
            subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    except Exception as err:
        print(f"[ahk_webcontrol_app] formatted email attachment failed: {err}", flush=True)
        return None


def safe_cache_filename(filename: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", Path(filename).name).strip("._")
    return safe or "report.csv"


def list_matching_csv_report_files(folder: Path, limit: int | None = None) -> list[Path]:
    csv_files: list[tuple[float, Path]] = []
    total_files = 0
    csv_name_files = 0
    skipped_csv_samples: list[str] = []

    print(
        f"[ahk_webcontrol_app] report cache scan: opening {folder} "
        f"(match pattern: filename ends with [0-9].CSV)",
        flush=True,
    )

    for path in folder.iterdir():
        try:
            if not path.is_file():
                continue

            total_files += 1
            if path.suffix.lower() == ".csv":
                csv_name_files += 1

            if REPORT_CACHE_FILENAME_RE.fullmatch(path.name):
                csv_files.append((path.stat().st_mtime, path))
            elif path.suffix.lower() == ".csv" and len(skipped_csv_samples) < REPORT_CACHE_SCAN_SAMPLE_LIMIT:
                skipped_csv_samples.append(path.name)
        except OSError as err:
            print(f"[ahk_webcontrol_app] skipping report candidate {path}: {err}", flush=True)

    csv_files.sort(key=lambda item: item[0], reverse=True)
    print(
        f"[ahk_webcontrol_app] report cache scan: inspected {total_files} file(s), "
        f"saw {csv_name_files} .csv file(s), matched {len(csv_files)} file(s)",
        flush=True,
    )
    if skipped_csv_samples:
        print(
            "[ahk_webcontrol_app] report cache scan: sample .csv names skipped by [0-9].CSV rule: "
            + ", ".join(skipped_csv_samples),
            flush=True,
        )

    if limit is not None and limit > 0:
        csv_files = csv_files[:limit]
    return [path for _, path in csv_files]


def cache_report_csv(source: Path) -> Path:
    REPORT_CACHE_DIR.mkdir(exist_ok=True)
    cached_name = safe_cache_filename(source.name)
    cached_path = REPORT_CACHE_DIR / cached_name
    tmp_path = cached_path.with_suffix(cached_path.suffix + ".tmp")

    source_stat = source.stat()
    should_copy = True
    if cached_path.exists():
        try:
            cached_stat = cached_path.stat()
            should_copy = (
                cached_stat.st_size != source_stat.st_size
                or abs(cached_stat.st_mtime - source_stat.st_mtime) > 1
            )
        except OSError:
            should_copy = True

    if should_copy:
        shutil.copy2(source, tmp_path)
        tmp_path.replace(cached_path)

    return cached_path


def ensure_cached_xlsx(cached_csv: Path) -> Path:
    xlsx_path = cached_csv.with_suffix(".xlsx")
    tmp_path = xlsx_path.with_suffix(xlsx_path.suffix + ".tmp")

    should_build = True
    if xlsx_path.exists():
        try:
            should_build = xlsx_path.stat().st_mtime < cached_csv.stat().st_mtime
        except OSError:
            should_build = True

    if should_build:
        tmp_path.write_bytes(csv_file_to_xlsx_bytes(cached_csv))
        tmp_path.replace(xlsx_path)

    return xlsx_path


def fmt_xlsx_cache_name(csv_name: str) -> str:
    return f"{Path(csv_name).stem}.fmt.xlsx"


def pdf_cache_name(csv_name: str) -> str:
    return f"{Path(csv_name).stem}.pdf"


def read_handoff_week_ending() -> datetime | None:
    handoff = APP_ROOT / "WeeklySalesRun1_handoff.txt"
    if not handoff.exists():
        return None
    for raw_line in handoff.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw_line.strip()
        if not line.startswith("week_ending="):
            continue
        text = line.split("=", 1)[1].strip()
        for fmt in ("%m/%d/%Y", "%m-%d-%Y", "%Y-%m-%d"):
            try:
                return datetime.strptime(text, fmt)
            except ValueError:
                continue
    return None


def run_format_xlsx_script(xlsx_in: Path, xlsx_out: Path) -> None:
    tmp_out = xlsx_out.with_suffix(xlsx_out.suffix + ".tmp")
    result = subprocess.run(
        [sys.executable, str(FORMAT_XLSX_SCRIPT), str(xlsx_in), str(tmp_out)],
        capture_output=True,
        text=True,
        cwd=APP_ROOT,
        timeout=300,
        check=False,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "format_report_xlsx.py failed").strip()
        raise RuntimeError(detail)
    tmp_out.replace(xlsx_out)


def ensure_formatted_xlsx(cached_csv: Path, *, force: bool = False) -> Path:
    base_xlsx = ensure_cached_xlsx(cached_csv)
    fmt_path = REPORT_CACHE_DIR / fmt_xlsx_cache_name(cached_csv.name)
    should_build = force
    if not should_build and fmt_path.exists():
        try:
            base_mtime = base_xlsx.stat().st_mtime
            csv_mtime = cached_csv.stat().st_mtime
            fmt_mtime = fmt_path.stat().st_mtime
            should_build = fmt_mtime < base_mtime or fmt_mtime < csv_mtime
        except OSError:
            should_build = True
    elif not fmt_path.exists():
        should_build = True
    if should_build:
        run_format_xlsx_script(base_xlsx, fmt_path)
    return fmt_path


def run_generate_pdf_script(fmt_path: Path, pdf_path: Path, week_ending: str | None = None) -> None:
    tmp_out = pdf_path.with_suffix(pdf_path.suffix + ".tmp")
    command = [sys.executable, str(GENERATE_PDF_SCRIPT), str(fmt_path), str(tmp_out)]
    if week_ending:
        command.append(week_ending)
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        cwd=APP_ROOT,
        timeout=300,
        check=False,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "generate_report_pdf.py failed").strip()
        raise RuntimeError(detail)
    if not tmp_out.exists():
        raise RuntimeError("generate_report_pdf.py did not produce output")
    tmp_out.replace(pdf_path)


def ensure_report_pdf(cached_csv: Path) -> Path:
    fmt_path = ensure_formatted_xlsx(cached_csv)
    pdf_path = REPORT_CACHE_DIR / pdf_cache_name(cached_csv.name)
    should_build = not pdf_path.exists()
    if not should_build:
        try:
            should_build = pdf_path.stat().st_mtime < fmt_path.stat().st_mtime
        except OSError:
            should_build = True

    week_ending = read_handoff_week_ending()
    week_ending_text = week_ending.strftime("%m/%d/%Y") if week_ending else None
    if should_build:
        run_generate_pdf_script(fmt_path, pdf_path, week_ending=week_ending_text)
    return pdf_path


def refresh_recent_report_cache(limit: int | None = None) -> tuple[list[RecentReport], str]:
    effective_limit = limit if limit is not None else REPORTS_PAGE_LIMIT
    started = time.monotonic()
    print(
        f"[ahk_webcontrol_app] report cache refresh: starting; source={TRANDATA_DIR}; "
        f"cache={REPORT_CACHE_DIR}; limit={'all' if not effective_limit else effective_limit}",
        flush=True,
    )
    try:
        sources = list_matching_csv_report_files(TRANDATA_DIR, effective_limit)
    except OSError as err:
        message = f"could not inspect report folder {TRANDATA_DIR}: {err}"
        print(f"[ahk_webcontrol_app] {message}", flush=True)
        return [], message

    if not sources:
        message = (
            f"no matching CSV files found in {TRANDATA_DIR}; expected filenames ending in [0-9].CSV"
        )
        print(f"[ahk_webcontrol_app] report cache refresh: {message}", flush=True)
        return [], message

    preview = ", ".join(source.name for source in sources[:REPORT_CACHE_SCAN_SAMPLE_LIMIT])
    if len(sources) > REPORT_CACHE_SCAN_SAMPLE_LIMIT:
        preview += f", ... ({len(sources)} total)"
    print(f"[ahk_webcontrol_app] report cache refresh: matching files: {preview}", flush=True)

    reports: list[RecentReport] = []
    for index, source in enumerate(sources, start=1):
        print(
            f"[ahk_webcontrol_app] report cache refresh: processing {index}/{len(sources)} {source.name}",
            flush=True,
        )
        try:
            source_stat = source.stat()
            cached_csv = cache_report_csv(source)
            print(
                f"[ahk_webcontrol_app] report cache refresh: cached CSV {source.name} -> {cached_csv.name}",
                flush=True,
            )
        except Exception as err:
            print(f"[ahk_webcontrol_app] could not cache report {source}: {err}", flush=True)
            continue

        cached_xlsx_name: str | None = None
        status = "cached csv"
        try:
            print(f"[ahk_webcontrol_app] report cache refresh: building Excel for {cached_csv.name}", flush=True)
            cached_xlsx = ensure_cached_xlsx(cached_csv)
            cached_xlsx_name = cached_xlsx.name
            status = "cached csv and xlsx"
            print(f"[ahk_webcontrol_app] report cache refresh: Excel ready {cached_xlsx.name}", flush=True)
        except Exception as err:
            status = f"cached csv; xlsx failed: {err}"
            print(f"[ahk_webcontrol_app] could not build xlsx for {cached_csv}: {err}", flush=True)

        fmt_xlsx = REPORT_CACHE_DIR / fmt_xlsx_cache_name(cached_csv.name)
        fmt_xlsx_name = fmt_xlsx.name if fmt_xlsx.exists() else None

        reports.append(
            RecentReport(
                source_path=source,
                source_name=source.name,
                cached_csv_name=cached_csv.name,
                cached_xlsx_name=cached_xlsx_name,
                cached_fmt_xlsx_name=fmt_xlsx_name,
                modified_at=datetime.fromtimestamp(source_stat.st_mtime),
                size_bytes=source_stat.st_size,
                status=status,
            )
        )

    print(
        f"[ahk_webcontrol_app] report cache refresh complete: cached {len(reports)} "
        f"matching CSV file(s) from {TRANDATA_DIR} in {time.monotonic() - started:.1f}s",
        flush=True,
    )
    return reports, ""


def cached_recent_reports(limit: int | None = RECENT_REPORT_LIMIT) -> list[RecentReport]:
    if not REPORT_CACHE_DIR.exists():
        return []

    reports: list[RecentReport] = []
    csv_files: list[tuple[float, Path]] = []
    for path in REPORT_CACHE_DIR.glob("*.csv"):
        try:
            if path.is_file():
                csv_files.append((path.stat().st_mtime, path))
        except OSError:
            continue

    csv_files.sort(key=lambda item: item[0], reverse=True)
    if limit is not None and limit > 0:
        csv_files = csv_files[:limit]

    for _, cached_csv in csv_files:
        try:
            stat = cached_csv.stat()
        except OSError:
            continue

        cached_xlsx = cached_csv.with_suffix(".xlsx")
        fmt_xlsx = REPORT_CACHE_DIR / fmt_xlsx_cache_name(cached_csv.name)
        reports.append(
            RecentReport(
                source_path=cached_csv,
                source_name=cached_csv.name,
                cached_csv_name=cached_csv.name,
                cached_xlsx_name=cached_xlsx.name if cached_xlsx.exists() else None,
                cached_fmt_xlsx_name=fmt_xlsx.name if fmt_xlsx.exists() else None,
                modified_at=datetime.fromtimestamp(stat.st_mtime),
                size_bytes=stat.st_size,
                status="cached locally",
            )
        )

    return reports


def report_cache_status_message() -> str:
    with REPORT_CACHE_LOCK:
        parts: list[str] = []
        if REPORT_CACHE_REFRESHING:
            parts.append("refreshing latest reports in background")
        if REPORT_CACHE_LAST_REFRESH is not None:
            parts.append(f"last refresh {REPORT_CACHE_LAST_REFRESH.isoformat(timespec='seconds')}")
        if REPORT_CACHE_LAST_ERROR:
            parts.append(REPORT_CACHE_LAST_ERROR)
        return "; ".join(parts)


def maybe_start_report_cache_refresh(force: bool = False) -> None:
    global REPORT_CACHE_REFRESHING

    with REPORT_CACHE_LOCK:
        if REPORT_CACHE_REFRESHING:
            print(
                "[ahk_webcontrol_app] report cache refresh request ignored: refresh already running",
                flush=True,
            )
            return
        stale = (
            REPORT_CACHE_LAST_REFRESH is None
            or (datetime.now() - REPORT_CACHE_LAST_REFRESH).total_seconds() >= REPORT_CACHE_AUTO_REFRESH_SECONDS
        )
        if not force and not stale:
            print(
                "[ahk_webcontrol_app] report cache refresh request skipped: cache is still fresh",
                flush=True,
            )
            return
        REPORT_CACHE_REFRESHING = True

    print(
        f"[ahk_webcontrol_app] report cache refresh request accepted: force={force}",
        flush=True,
    )
    threading.Thread(
        target=_report_cache_refresh_worker,
        name="report_cache_refresh",
        daemon=True,
    ).start()


def _report_cache_refresh_worker() -> None:
    global REPORT_CACHE_REFRESHING, REPORT_CACHE_LAST_REFRESH, REPORT_CACHE_LAST_ERROR

    error = ""
    print("[ahk_webcontrol_app] report cache worker: started", flush=True)
    try:
        _, error = refresh_recent_report_cache()
    except Exception as err:
        error = f"report cache refresh failed: {err}"
        print(f"[ahk_webcontrol_app] {error}", flush=True)

    with REPORT_CACHE_LOCK:
        REPORT_CACHE_LAST_REFRESH = datetime.now()
        REPORT_CACHE_LAST_ERROR = error
        REPORT_CACHE_REFRESHING = False
    print(
        f"[ahk_webcontrol_app] report cache worker: finished"
        f"{' with issue: ' + error if error else ' successfully'}",
        flush=True,
    )


def resolve_cached_report_path(filename: str, expected_suffix: str) -> Path | None:
    if Path(filename).name != filename:
        return None
    if Path(filename).suffix.lower() != expected_suffix:
        return None

    cache_root = REPORT_CACHE_DIR.resolve()
    path = (REPORT_CACHE_DIR / filename).resolve()
    if cache_root not in path.parents or not path.exists() or not path.is_file():
        return None
    return path


def build_report_email_section(report_file: Path | None, attachment_note: str) -> str:
    header = (
        "Generated Report File\n"
        "---------------------\n"
        f"{attachment_note}\n\n"
    )

    if report_file is None:
        return header + (
            "Fresh report file: NOT FOUND\n"
            f"Expected source: last '{AHK_LOG_NEWEST_TRANDATA_PREFIX}' line in the web run log "
            f"(same CSV AutoHotkey detected).\n"
            f"Optional folder fallback: {TRANDATA_DIR} "
            f"(enable with EMAIL_FALLBACK_TRANDATA_FOLDER_SCAN=1)\n"
            f"Freshness window (fallback only): {REPORT_FRESHNESS_SECONDS} seconds\n"
        )

    stat = report_file.stat()
    return header + (
        f"Source path (CSV): {report_file}\n"
        f"Modified:           {datetime.fromtimestamp(stat.st_mtime).isoformat(timespec='seconds')}\n"
        f"Size bytes:         {stat.st_size}\n"
    )


def send_fastmail_message(
    settings: EmailSettings,
    recipients: list[str],
    subject: str,
    body: str,
    attachment: EmailAttachment | None = None,
) -> None:
    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = settings.sender
    message["To"] = ", ".join(recipients)
    message.set_content(body)

    if attachment is not None:
        message.add_attachment(
            attachment.data,
            maintype=attachment.maintype,
            subtype=attachment.subtype,
            filename=attachment.filename,
        )
        print(f"[ahk_webcontrol_app] attaching {attachment.filename} ({attachment.maintype}/{attachment.subtype})", flush=True)

    print(
        f"[ahk_webcontrol_app] sending email via {settings.smtp_host}:{settings.smtp_port} "
        f"from={settings.sender} to={', '.join(recipients)}",
        flush=True,
    )
    with smtplib.SMTP_SSL(settings.smtp_host, settings.smtp_port, timeout=EMAIL_SMTP_TIMEOUT_SECONDS) as smtp:
        smtp.login(settings.username, settings.app_password)
        smtp.send_message(message)


def create_app(
    controller: AhkWebController,
    access_token: str | None = None,
    bind_port: int = 42001,
) -> Flask:
    app = Flask(__name__)
    app.config["AHK_ACCESS_TOKEN"] = access_token
    app.config["BIND_PORT"] = bind_port

    @app.before_request
    def require_token() -> None:
        if not access_token:
            return
        if request.endpoint in ("static", "health"):
            return
        token = request_access_token(access_token)
        if token != access_token:
            abort(403)

    @app.after_request
    def persist_token_cookie(response):
        if access_token and request_access_token(access_token) == access_token:
            response.set_cookie(
                "ahk_web_token",
                access_token,
                httponly=True,
                samesite="Lax",
                max_age=60 * 60 * 24 * 30,
            )
        return response

    @app.errorhandler(403)
    def forbidden(_error):
        if request.path.startswith("/api/"):
            return jsonify(
                {
                    "error": "forbidden",
                    "hint": "Pass ?token=…, X-Control-Token header, ahk_web_token cookie, or form token.",
                }
            ), 403
        return (
            render_template(
                "forbidden.html",
                token_required=bool(access_token),
                lan_urls=lan_bind_urls(bind_port, access_token),
                bind_port=bind_port,
            ),
            403,
        )

    @app.get("/health")
    def health():
        return jsonify(
            {
                "ok": True,
                "cwd": str(controller.cwd),
                "scripts": [item.name for item in controller.scripts_info()],
                "session": windows_session_summary(),
            }
        )

    @app.get("/")
    def index():
        token = access_token or ""
        return render_template(
            "index.html",
            scripts=controller.scripts_info(),
            runs=controller.snapshot(),
            ahk_exe=str(controller.ahk_exe),
            cwd=str(controller.cwd),
            token=token,
            token_required=bool(access_token),
            lan_urls=lan_bind_urls(bind_port, access_token),
            bind_port=bind_port,
            refresh_seconds=AUTO_REFRESH_SECONDS,
            launcher_session=windows_session_summary(),
            session_warning=interactive_session_warning(),
        )

    @app.get("/reports")
    def reports_page():
        maybe_start_report_cache_refresh()
        token = access_token or ""
        reports_limit = REPORTS_PAGE_LIMIT if REPORTS_PAGE_LIMIT > 0 else None
        return render_template(
            "reports.html",
            recent_reports=cached_recent_reports(reports_limit),
            reports_limit=reports_limit,
            report_source_dir=str(TRANDATA_DIR),
            report_cache_status=report_cache_status_message(),
            token=token,
            token_required=bool(access_token),
            refresh_seconds=AUTO_REFRESH_SECONDS,
        )

    @app.post("/run/<path:script_name>")
    def run_script(script_name: str):
        session_warning = interactive_session_warning()
        if session_warning:
            print(f"[ahk_webcontrol_app] run requested with risky session: {session_warning}", flush=True)
        try:
            run = controller.start(script_name)
            print(
                f"[ahk_webcontrol_app] started run {run.run_id} script={script_name!r} "
                f"session={windows_session_summary()}",
                flush=True,
            )
        except ValueError:
            print(f"[ahk_webcontrol_app] unknown script requested: {script_name!r}", flush=True)
            abort(404)
        return redirect(url_for("index", token=access_token) if access_token else url_for("index"))

    @app.post("/stop/<int:run_id>")
    def stop_run(run_id: int):
        controller.stop(run_id)
        return redirect(url_for("index", token=access_token) if access_token else url_for("index"))

    @app.post("/email/run/<int:run_id>")
    def email_run(run_id: int):
        if not controller.send_email_for_run(run_id):
            abort(404)
        return redirect(url_for("index", token=access_token) if access_token else url_for("index"))

    @app.post("/reports/refresh")
    def refresh_reports():
        print("[ahk_webcontrol_app] manual report cache refresh requested from /reports", flush=True)
        maybe_start_report_cache_refresh(force=True)
        return redirect(url_for("reports_page", token=access_token) if access_token else url_for("reports_page"))

    @app.get("/api/status")
    def api_status():
        return jsonify(controller.snapshot())

    @app.get("/reports/download/csv/<path:filename>")
    def download_report_csv(filename: str):
        path = resolve_cached_report_path(filename, ".csv")
        if path is None:
            abort(404)
        return send_file(path, mimetype="text/csv", as_attachment=True, download_name=path.name)

    @app.get("/reports/download/xlsx/<path:filename>")
    def download_report_xlsx(filename: str):
        path = resolve_cached_report_path(filename, ".xlsx")
        if path is None:
            abort(404)
        return send_file(
            path,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            as_attachment=True,
            download_name=path.name,
        )

    @app.post("/reports/format/<path:filename>")
    def format_report(filename: str):
        cached_csv = resolve_cached_report_path(filename, ".csv")
        if cached_csv is None:
            abort(404)
        try:
            fmt_path = ensure_formatted_xlsx(cached_csv)
        except Exception as err:
            print(f"[ahk_webcontrol_app] report format failed for {filename}: {err}", flush=True)
            abort(500)
        print(f"[ahk_webcontrol_app] report formatted: {fmt_path.name}", flush=True)
        return send_file(
            fmt_path,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            as_attachment=True,
            download_name=fmt_path.name,
        )

    @app.post("/reports/pdf/<path:filename>")
    def generate_report_pdf_route(filename: str):
        cached_csv = resolve_cached_report_path(filename, ".csv")
        if cached_csv is None:
            abort(404)
        try:
            pdf_path = ensure_report_pdf(cached_csv)
        except Exception as err:
            print(f"[ahk_webcontrol_app] report PDF failed for {filename}: {err}", flush=True)
            abort(500)
        print(f"[ahk_webcontrol_app] report PDF ready: {pdf_path.name}", flush=True)
        return send_file(
            pdf_path,
            mimetype="application/pdf",
            as_attachment=True,
            download_name=pdf_path.name,
        )

    @app.get("/api/logs/<path:log_name>")
    def api_log(log_name: str):
        log_path = resolve_log_path(log_name)
        if log_path is None:
            abort(404)

        stat = log_path.stat()
        return jsonify(
            {
                "log_name": log_path.name,
                "content": log_path.read_text(encoding="utf-8", errors="replace"),
                "size": stat.st_size,
                "updated_at": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
            }
        )

    @app.get("/logs/<path:log_name>")
    def view_log(log_name: str):
        log_path = resolve_log_path(log_name)
        if log_path is None:
            abort(404)
        return render_template(
            "log.html",
            log_name=log_path.name,
            content=log_path.read_text(encoding="utf-8", errors="replace"),
            log_api_url=url_for("api_log", log_name=log_path.name, token=access_token)
            if access_token
            else url_for("api_log", log_name=log_path.name),
            token=access_token or "",
        )

    return app


def resolve_log_path(log_name: str) -> Path | None:
    log_path = (RUN_LOG_DIR / log_name).resolve()
    if RUN_LOG_DIR.resolve() not in log_path.parents or not log_path.exists() or not log_path.is_file():
        return None
    return log_path


def main() -> int:
    parser = argparse.ArgumentParser(description="Remote web controls for local AutoHotkey scripts.")
    parser.add_argument("--host", default="0.0.0.0", help="Bind address. Default: 0.0.0.0 for LAN access.")
    parser.add_argument(
        "--ports",
        default=os.environ.get("AHK_WEB_PORTS", "42000,42001"),
        help="Comma-separated HTTP ports (default: 42000,42001).",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=None,
        help="Bind only this port (overrides --ports).",
    )
    parser.add_argument("--ahk-exe", default=os.environ.get("AHK_EXE"), help="Path to AutoHotkey v2 executable.")
    parser.add_argument("--token", default=os.environ.get("AHK_WEB_TOKEN"), help="Optional access token.")
    args = parser.parse_args()

    try:
        bind_ports = [args.port] if args.port is not None else parse_bind_ports(args.ports)
    except ValueError as err:
        print(f"Invalid port configuration: {err}", flush=True)
        return 2

    primary_port = primary_bind_port(bind_ports)

    ahk_exe = resolve_ahk_exe(args.ahk_exe)
    if ahk_exe is None:
        print(
            "Could not find AutoHotkey v2. Set AHK_EXE or pass --ahk-exe.",
            flush=True,
        )
        return 2

    controller = AhkWebController(ahk_exe=ahk_exe, cwd=APP_ROOT)
    app = create_app(controller, access_token=args.token, bind_port=primary_port)
    maybe_start_report_cache_refresh(force=True)

    print("AHK web control online", flush=True)
    print(f"Scripts dir: {APP_ROOT}", flush=True)
    print(f"Scripts: {', '.join(script.name for script in controller.scripts()) or '(none)'}", flush=True)
    print(f"AutoHotkey: {ahk_exe}", flush=True)
    print(f"Report source: {TRANDATA_DIR}", flush=True)
    print(f"Report cache:  {REPORT_CACHE_DIR}", flush=True)
    print("Report cache startup refresh: scanning filenames that end in [0-9].CSV", flush=True)
    print(f"Launcher session: {windows_session_summary()}", flush=True)
    if os.name == "nt":
        print(f"RDP tip: {rdp_session_keepalive_hint()}", flush=True)
    print(f"Bind ports: {', '.join(str(port) for port in bind_ports)}", flush=True)
    for port in bind_ports:
        print(f"Local:  http://127.0.0.1:{port}/", flush=True)
    if args.token:
        print(f"Token required on remote browsers: ?token={args.token}", flush=True)
    for port in bind_ports:
        for url in lan_bind_urls(port, args.token):
            print(f"LAN:    {url}", flush=True)
    for port in bind_ports:
        print(f"Health: http://127.0.0.1:{port}/health  (no token; use to test firewall)", flush=True)
    if args.host == "0.0.0.0":
        print(
            "Remote access: open a LAN URL above from another PC. "
            "Run web_control.py inside the logged-in RDP desktop (not as a service).",
            flush=True,
        )

    print(
        f"[ahk_webcontrol_app] Dashboard auto-refreshes every {AUTO_REFRESH_SECONDS}s; "
        "Werkzeug may log fewer lines because static 304 hits are filtered (see note when they occur).",
        flush=True,
    )
    logging.getLogger("werkzeug").addFilter(QuietStatic304ReassuranceFilter())

    run_on_bind_ports(app, args.host, bind_ports)
    return 0


def resolve_ahk_exe(configured: str | None) -> Path | None:
    if configured:
        path = Path(configured).expanduser()
        if path.exists():
            return path.resolve()
        found = shutil.which(configured)
        if found:
            return Path(found).resolve()
        return None

    for name in AHK_EXE_NAMES:
        found = shutil.which(name)
        if found:
            return Path(found).resolve()

    if os.name == "nt":
        for candidate in common_windows_ahk_paths():
            if candidate.exists():
                return candidate

    return None


def common_windows_ahk_paths() -> list[Path]:
    roots = [
        os.environ.get("ProgramFiles"),
        os.environ.get("ProgramFiles(x86)"),
        os.environ.get("LOCALAPPDATA"),
    ]
    relative_paths = [
        Path("AutoHotkey") / "v2" / "AutoHotkey64.exe",
        Path("AutoHotkey") / "v2" / "AutoHotkey.exe",
        Path("AutoHotkey") / "AutoHotkey64.exe",
        Path("AutoHotkey") / "AutoHotkey.exe",
    ]

    return [Path(root) / relative for root in roots if root for relative in relative_paths]


if __name__ == "__main__":
    raise SystemExit(main())
