; Shared unattended automation settings for Rockland AHK workflows.
; Include near the top of each script (after #Requires / #SingleInstance):
;   #Include ahk_unattended.ahk
;
; - Disables #Warn MsgBox popups (e.g. VarUnset) that block headless/RDP runs.
; - Routes runtime errors to log files instead of modal AHK error dialogs.

#Warn All, Off

SuppressAhkPopupError(err, mode) {
    modeLabel := (mode = 0) ? "ERROR" : (mode = 1) ? "WARNING" : "mode=" mode
    summary := Format(
        "SUPPRESSED AHK {} message={} what={} line={} file={}",
        modeLabel,
        err.Message,
        err.What,
        err.Line,
        err.File
    )

    if IsFunc("Log") {
        try {
            Log(summary)
        }
    }

    line := FormatTime(, "yyyy-MM-dd HH:mm:ss") " | " A_ScriptName " | " summary "`n"
    try {
        FileAppend line, A_ScriptDir "\ahk_suppressed_errors.log", "UTF-8"
    }

    OutputDebug summary
    return true
}

OnError SuppressAhkPopupError
