# ahk_Rockland

Remote-control dashboard and AutoHotkey v2 scripts for the Bakers13 RDP workflow.

## Windows Setup

Install Python requirements:

```powershell
python -m pip install -r requirements.txt
```

Install AutoHotkey v2, then either let the app auto-detect it or set:

```powershell
$env:AHK_EXE="C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe"
```

## Web Control

Run this from the same Windows desktop/RDP session that should receive the AHK input:

```powershell
python web_control.py
```

Open:

```text
http://127.0.0.1:42001/
```

For remote access from another computer on the LAN:

```powershell
$env:AHK_WEB_TOKEN="change-this"
python web_control.py
```

Then open:

```text
http://<rdp-computer-ip>:42001/?token=change-this
```

## Email Notifications

Fastmail supports programmatic email through SMTP with an **app password**.

In Fastmail, create one here:

```text
Settings -> Password & Security -> App passwords
```

Create an app password with Mail/SMTP permission, then copy `.env.example` to
`.env` and fill in. `web_control.py` also reads `text2.md` from the app root
for the same settings. It accepts `KEY=value` or `KEY: value` lines, so your
current credential file can be used as long as the keys are present.

```powershell
Copy-Item .env.example .env
```

Required values:

```text
FASTMAIL_SMTP_USERNAME=yourname@fastmail.com
FASTMAIL_SMTP_APP_PASSWORD=your-fastmail-app-password
REPORT_EMAIL_FROM=yourname@fastmail.com
REPORT_EMAIL_TO=person1@example.com,person2@example.com
REPORT_TEST_EMAIL_TO=rdwyer@fastmail.com
```

When a web-launched AHK run exits, `web_control.py` sends:

```text
Subject: auto_report

the report has completed. MM/DD/YYYY
```

The email also includes the script name, run id, exit code, and completion time.
The dashboard has a **send test email** button for verifying SMTP before running
an AHK report.

For report emails, `web_control.py` also checks the shared report directory:

```text
\\Rb-rossbd\baker\Bakers13\trandata
```

If the newest file is fresh, the email includes the absolute path and the full
CSV/report contents at the bottom of the message, and also attaches the same
file to the email. Override the folder or freshness window with:

```text
REPORT_TRANDATA_DIR=\\Rb-rossbd\baker\Bakers13\trandata
REPORT_FRESHNESS_SECONDS=1200
EMAIL_SMTP_TIMEOUT_SECONDS=10
```

Email is sent in a background thread after the AHK process exits, so SMTP cannot
block the web controller from recording the final `exit 0` / `exit 1` status.

## Open WebUI report config screenshot (`WeeklySalesRun1`)

After the in-app report config panel opens, `WeeklySalesRun1.ahk` calls
`openwebui_report_screenshot.py` to capture the Bakers window, resize the image
(default `120x80`), and send it to Open WebUI using the vision API.

Add to `.env` on the automation PC (do not commit tokens):

```text
OPENWEBUI_BASE_URL=https://ai.nosox.xyz
OPENWEBUI_API_TOKEN=<JWT from Open WebUI Settings > Account>
OPENWEBUI_MODEL=rocklanduihelper
OPENWEBUI_SCREENSHOT_WIDTH=120
OPENWEBUI_SCREENSHOT_HEIGHT=80
OPENWEBUI_ENABLED=1
```

Install helper dependencies:

```powershell
python -m pip install Pillow requests
```

Saved files (example date `05052026`):

```text
screenshot05052026.jpeg
WeeklySalesRun1_screenshot05052026.jpeg
```

If the API path fails, the helper logs a manual fallback URL:
`https://ai.nosox.xyz/?models=rocklanduihelper`

### Temporary YES/NO test script

`TestOpenWebUIScreenshot.ahk` captures the full screen, resizes, sends to Open WebUI,
and checks the reply for **YES** or **NO**:

```powershell
AutoHotkey64.exe TestOpenWebUIScreenshot.ahk
```

Or from Python only:

```powershell
python openwebui_report_screenshot.py --test-yes-no --full-screen
```

Exit codes: `0` = YES (`Found open window`), `1` = NO, `2` = error. Logs go to
`TestOpenWebUIScreenshot.log`.

Optional prompt override in `.env`:

```text
OPENWEBUI_TEST_PROMPT=Look at this screenshot. Is the report config panel open? Reply YES or NO only.
```

## Firewall (remote PC cannot reach port 42001)

If another machine cannot open `http://<server-ip>:42001/` but `http://localhost:42001/` works,
open **inbound TCP 42001** on the Windows host that runs Flask.

Elevated PowerShell:

```powershell
New-NetFirewallRule -DisplayName "Rockland AHK Web (42001)" -Direction Inbound -LocalPort 42001 -Protocol TCP -Action Allow
```

Also verify you are hitting the server's **LAN IPv4**, and that routers/VLANs permit it.

Important: AutoHotkey drives the interactive desktop. Do not run `web_control.py`
as a Windows service; service/session-0 processes cannot reliably click/type into
the live RDP desktop.