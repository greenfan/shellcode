#!/usr/bin/env python3
"""Format cached sales report xlsx: freeze/bold header, sort by SALES REP, spacer rows."""

from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font
from openpyxl.utils import get_column_letter

SPACER_ROWS = 10
HEADER_FONT = Font(bold=True)
LABEL_FONT = Font(bold=True, size=11, color="1F4F7A")
LABEL_ALIGN = Alignment(horizontal="left", vertical="center")
# Excel column width units (~(px - 5) / 7); targets ~1.9" / ~2.8" (~210px) / ~1.1"
COLUMN_WIDTHS = {
    "ACCOUNT": 19.9,
    "ACCOUNT NAME": 29.3,
    "START DATE": 11.5,
}
DATE_FORMATS = ("%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d")
NEW_FORMULA_COL = 2  # column B, immediately right of "New"
YOY_DIFF_COL = 2  # column B, immediately right of "Yoy" (=E{row}-G{row})
# A=Account, B=Account Name, C=Start Date, D=Name (rep), E/F/G=sales (drop SALES REP if extra).
NEW_START_DATE_COL = 3  # column C
NEW_SALES_CUTOFF = datetime(2025, 11, 15)  # Start Date in column C newer than 11/15/2025
CURRENCY_FORMAT = '"$"#,##0.00'


def find_column_index(headers: list, name: str) -> int:
    target = name.strip().upper()
    for idx, header in enumerate(headers, start=1):
        if header is None:
            continue
        if str(header).strip().upper() == target:
            return idx
    raise ValueError(f"column {name!r} not found in: {headers!r}")


def find_column_index_optional(headers: list, name: str) -> int | None:
    try:
        return find_column_index(headers, name)
    except ValueError:
        return None


def find_rep_column(headers: list) -> int:
    for label in ("NAME", "SALES REP"):
        col = find_column_index_optional(headers, label)
        if col is not None:
            return col
    raise ValueError("NAME or SALES REP column required for grouping")


def rep_sort_key(row: list, rep_col: int) -> str:
    if rep_col <= 0 or rep_col > len(row):
        return ""
    value = row[rep_col - 1]
    return "" if value is None else str(value).strip().upper()


def start_date_sort_key(row: list, date_col: int) -> datetime:
    if date_col <= 0 or date_col > len(row):
        return datetime.max
    value = row[date_col - 1]
    if isinstance(value, datetime):
        return value
    if isinstance(value, (int, float)) and value > 1000:
        from datetime import timedelta

        return datetime(1899, 12, 30) + timedelta(days=float(value))
    if value is None:
        return datetime.max
    text = str(value).strip()
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return datetime.max


def merge_contiguous_rows(row_numbers: list[int]) -> list[tuple[int, int]]:
    if not row_numbers:
        return []
    sorted_rows = sorted(row_numbers)
    ranges: list[tuple[int, int]] = []
    start = end = sorted_rows[0]
    for row in sorted_rows[1:]:
        if row == end + 1:
            end = row
            continue
        ranges.append((start, end))
        start = end = row
    ranges.append((start, end))
    return ranges


def new_sales_sum_formula(
    output: list[list],
    group_start_row: int,
    group_end_row: int,
    *,
    sales_col: int,
    date_col: int,
) -> str:
    sales_letter = get_column_letter(sales_col)
    qualifying_rows: list[int] = []
    for sheet_row in range(group_start_row, group_end_row + 1):
        row = output[sheet_row - 1]
        row_date = start_date_sort_key(row, date_col)
        if row_date != datetime.max and row_date > NEW_SALES_CUTOFF:
            qualifying_rows.append(sheet_row)
    if not qualifying_rows:
        return "=0"

    refs: list[str] = []
    for start, end in merge_contiguous_rows(qualifying_rows):
        if start == end:
            refs.append(f"{sales_letter}{start}")
        else:
            refs.append(f"{sales_letter}{start}:{sales_letter}{end}")
    return f"=SUM({','.join(refs)})"


def rep_column_sum_formula(group_start_row: int, group_end_row: int, data_col: int) -> str:
    col_letter = get_column_letter(data_col)
    if group_start_row == group_end_row:
        return f"=SUM({col_letter}{group_start_row})"
    return f"=SUM({col_letter}{group_start_row}:{col_letter}{group_end_row})"


def yoy_diff_formula(yoy_row: int, col_e: int, col_g: int) -> str:
    e_letter = get_column_letter(col_e)
    g_letter = get_column_letter(col_g)
    return f"={e_letter}{yoy_row}-{g_letter}{yoy_row}"


def coerce_currency(value) -> float | str | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not text:
        return None
    try:
        return float(text.replace("$", "").replace(",", ""))
    except ValueError:
        return value


def normalize_row_for_excel(row: list, money_col_start: int, *, money_cols: int = 1) -> list:
    if not row:
        return row
    label = row[0]
    if label in ("Yoy", "New"):
        return row
    normalized = list(row)
    for offset in range(money_cols):
        idx = money_col_start - 1 + offset
        if idx < len(normalized):
            normalized[idx] = coerce_currency(normalized[idx])
    return normalized


def drop_column(rows: list[list], col_index: int) -> list[list]:
    idx = col_index - 1
    return [row[:idx] + row[idx + 1 :] for row in rows]


def apply_column_widths(ws, headers: list) -> None:
    for idx, header in enumerate(headers, start=1):
        if header is None:
            continue
        width = COLUMN_WIDTHS.get(str(header).strip().upper())
        if width is not None:
            ws.column_dimensions[get_column_letter(idx)].width = width


def format_workbook(in_path: Path, out_path: Path) -> None:
    wb = load_workbook(in_path)
    ws = wb.active

    max_row = ws.max_row or 1
    max_col = ws.max_column or 1
    headers = [ws.cell(1, col).value for col in range(1, max_col + 1)]
    rep_col = find_rep_column(headers)
    sales_rep_col = find_column_index_optional(headers, "SALES REP")
    start_col = find_column_index(headers, "START DATE")

    data: list[list] = []
    for row_idx in range(2, max_row + 1):
        row = [ws.cell(row_idx, col).value for col in range(1, max_col + 1)]
        if any(cell is not None and str(cell).strip() != "" for cell in row):
            data.append(row)

    data.sort(key=lambda row: rep_sort_key(row, rep_col))

    output: list[list] = [headers]
    new_formula_rows: list[tuple[int, int, int]] = []
    yoy_formula_rows: list[tuple[int, int, int]] = []
    idx = 0
    while idx < len(data):
        rep = rep_sort_key(data[idx], rep_col)
        group: list[list] = []
        while idx < len(data) and rep_sort_key(data[idx], rep_col) == rep:
            group.append(data[idx])
            idx += 1
        group.sort(key=lambda row: start_date_sort_key(row, start_col))
        group_start_row = len(output) + 1
        output.extend(group)
        group_end_row = len(output)
        for spacer in range(SPACER_ROWS):
            blank = [None] * len(headers)
            if spacer == 0:
                blank[0] = "Yoy"
            elif spacer == 1:
                blank[0] = "New"
            output.append(blank)
        yoy_formula_rows.append((group_end_row + 1, group_start_row, group_end_row))
        new_formula_rows.append((group_end_row + 2, group_start_row, group_end_row))

    if sales_rep_col is not None:
        if sales_rep_col == rep_col:
            output[0][sales_rep_col - 1] = "NAME"
        else:
            output = drop_column(output, sales_rep_col)

    headers = output[0]
    name_col = find_column_index_optional(headers, "NAME") or rep_col
    # E/F/G sit immediately right of Name (no extra shift after SALES REP drop).
    amount_col = name_col + 1
    yoy_col_e = amount_col
    yoy_col_f = amount_col + 1
    yoy_col_g = amount_col + 2

    ws.delete_rows(1, max_row)
    for row in output:
        label = row[0] if row else None
        money_cols = 1 if label in ("Yoy", "New") else 3
        ws.append(normalize_row_for_excel(row, amount_col, money_cols=money_cols))

    ws.freeze_panes = "A2"
    for col in range(1, len(headers) + 1):
        cell = ws.cell(1, col)
        cell.font = HEADER_FONT

    for row_idx, row in enumerate(output, start=1):
        if row_idx < 2:
            continue
        label = row[0] if row else None
        if label not in ("Yoy", "New"):
            continue
        cell = ws.cell(row_idx, 1)
        cell.font = LABEL_FONT
        cell.alignment = LABEL_ALIGN

    # New row: B = =SUM(E705:E708) etc. — column E, Start Date in C after 11/15/2025.
    for new_row, group_start_row, group_end_row in new_formula_rows:
        amount_cell = ws.cell(new_row, NEW_FORMULA_COL)
        amount_cell.value = new_sales_sum_formula(
            output,
            group_start_row,
            group_end_row,
            sales_col=amount_col,
            date_col=NEW_START_DATE_COL,
        )
        amount_cell.number_format = CURRENCY_FORMAT

    for yoy_row, group_start_row, group_end_row in yoy_formula_rows:
        yoy_cells = (
            (yoy_row, yoy_col_e, rep_column_sum_formula(group_start_row, group_end_row, yoy_col_e)),
            (yoy_row, yoy_col_f, rep_column_sum_formula(group_start_row, group_end_row, yoy_col_f)),
            (yoy_row, yoy_col_g, rep_column_sum_formula(group_start_row, group_end_row, yoy_col_g)),
            (yoy_row, YOY_DIFF_COL, yoy_diff_formula(yoy_row, yoy_col_e, yoy_col_g)),
        )
        for row_num, col_num, formula in yoy_cells:
            cell = ws.cell(row_num, col_num)
            cell.value = formula
            cell.number_format = CURRENCY_FORMAT

    apply_column_widths(ws, headers)

    # Ask Excel to recalculate formulas when the workbook is opened.
    wb.calculation.fullCalcOnLoad = True
    wb.calculation.calcOnSave = True

    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out_path)


def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print(f"usage: {Path(argv[0]).name} <input.xlsx> <output.xlsx>", file=sys.stderr)
        return 2
    format_workbook(Path(argv[1]), Path(argv[2]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
