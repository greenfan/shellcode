#Requires AutoHotkey v2.0
#SingleInstance Force
#Include ahk_unattended.ahk

; Temporary test script: full-screen screenshot -> resize -> Open WebUI -> YES/NO.
; Exit 0 = YES (Found open window), 1 = NO, 2 = API/parse error.
; Logs: TestOpenWebUIScreenshot.log (Python helper) and this script's stdout via RunWait capture optional.

logPath := A_ScriptDir "\TestOpenWebUIScreenshot.log"
helperScript := A_ScriptDir "\openwebui_report_screenshot.py"

Log("START TestOpenWebUIScreenshot")
Log("Screen detected: " A_ScreenWidth "x" A_ScreenHeight)

if !FileExist(helperScript) {
    Log("FAIL openwebui_report_screenshot.py not found: " helperScript)
    ExitApp 2
}

pythonExe := ResolvePythonExe()
if !pythonExe {
    Log("FAIL Python not found. Set PYTHON_EXE or install Python on PATH.")
    ExitApp 2
}

dateStamp := FormatTime(, "MMddyyyy")
command := Format(
    '"{1}" "{2}" --test-yes-no --full-screen --date-stamp {3}',
    pythonExe,
    helperScript,
    dateStamp
)

Log("Waiting 1 second before full-screen capture.")
Sleep 1000
Log("Running: " command)

exitCode := RunWait(command, A_ScriptDir, "Hide")
if exitCode = 0 {
    Log("Found open window")
    Log("COMPLETE TestOpenWebUIScreenshot: YES — can continue.")
} else if exitCode = 1 {
    Log("Open WebUI answered NO — report config panel not detected.")
    Log("COMPLETE TestOpenWebUIScreenshot: NO.")
} else {
    Log("FAIL TestOpenWebUIScreenshot helper exited with code " exitCode ". See TestOpenWebUIScreenshot.log.")
}

ExitApp exitCode

ResolvePythonExe() {
    envPython := EnvGet("PYTHON_EXE")
    if envPython && FileExist(envPython) {
        return envPython
    }

    for candidate in [
        "C:\Python312\python.exe",
        "C:\Python311\python.exe",
        "C:\Program Files\Python312\python.exe",
        "C:\Program Files\Python311\python.exe",
        A_AppData "\..\Local\Programs\Python\Python312\python.exe",
        A_AppData "\..\Local\Programs\Python\Python311\python.exe",
    ] {
        if FileExist(candidate) {
            return candidate
        }
    }

    return "python"
}

Log(message) {
    global logPath

    line := FormatTime(, "yyyy-MM-dd HH:mm:ss") " | " message "`n"
    try {
        FileAppend line, logPath, "UTF-8"
    }

    try {
        FileAppend line, "*", "UTF-8"
    }

    OutputDebug RTrim(line, "`n")
}
