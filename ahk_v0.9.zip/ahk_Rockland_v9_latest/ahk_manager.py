#!/usr/bin/env python3
"""
ahk_manager.py

Interactive CLI for running and monitoring AutoHotkey v2 scripts in the current
directory. Designed for Windows 10, but it can run anywhere an AutoHotkey
executable is available.
"""

from __future__ import annotations

import argparse
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


LOG_DIR_NAME = "ahk_runs"
AHK_EXE_NAMES = ("AutoHotkey64.exe", "AutoHotkey.exe", "AutoHotkey32.exe")


@dataclass
class ManagedRun:
    run_id: int
    script: Path
    process: subprocess.Popen[str]
    log_path: Path
    started_at: datetime
    output_queue: queue.Queue[str] = field(default_factory=queue.Queue)

    def is_running(self) -> bool:
        return self.process.poll() is None

    def return_code(self) -> int | None:
        return self.process.poll()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Select, run, and monitor AutoHotkey v2 scripts from the current directory."
    )
    parser.add_argument(
        "--ahk-exe",
        default=os.environ.get("AHK_EXE"),
        help="Path to AutoHotkey.exe. Defaults to AHK_EXE env var, PATH, or common install locations.",
    )
    parser.add_argument(
        "--cwd",
        default=str(Path.cwd()),
        help="Directory containing .ahk scripts. Default: current directory.",
    )
    args = parser.parse_args()

    cwd = Path(args.cwd).expanduser().resolve()
    if not cwd.exists() or not cwd.is_dir():
        print(f"Not a directory: {cwd}", file=sys.stderr)
        return 2

    ahk_exe = resolve_ahk_exe(args.ahk_exe)
    if ahk_exe is None:
        print(
            "Could not find AutoHotkey v2 executable.\n\n"
            "Install AutoHotkey v2 or run with:\n"
            "  python ahk_manager.py --ahk-exe \"C:\\Program Files\\AutoHotkey\\v2\\AutoHotkey64.exe\"\n\n"
            "You can also set AHK_EXE to the executable path.",
            file=sys.stderr,
        )
        return 2

    manager = AhkManager(cwd=cwd, ahk_exe=ahk_exe)
    manager.loop()
    return 0


class AhkManager:
    def __init__(self, cwd: Path, ahk_exe: Path) -> None:
        self.cwd = cwd
        self.ahk_exe = ahk_exe
        self.log_dir = cwd / LOG_DIR_NAME
        self.log_dir.mkdir(exist_ok=True)
        self.runs: dict[int, ManagedRun] = {}
        self.next_run_id = 1

    def loop(self) -> None:
        print("\nAutoHotkey v2 Manager")
        print("=====================")
        print(f"Working directory: {self.cwd}")
        print(f"AutoHotkey exe:    {self.ahk_exe}")
        print("Type h for help.\n")

        while True:
            self.reap_finished_runs()
            command = input("ahk-manager> ").strip()

            if not command:
                continue

            action, _, rest = command.partition(" ")
            action = action.lower()
            rest = rest.strip()

            if action in {"q", "quit", "exit"}:
                self.confirm_exit()
                return
            if action in {"h", "help", "?"}:
                self.print_help()
            elif action in {"l", "list"}:
                self.print_scripts()
            elif action in {"r", "run"}:
                self.run_selected(rest, background=False)
            elif action in {"b", "bg", "background"}:
                self.run_selected(rest, background=True)
            elif action in {"s", "status"}:
                self.print_status()
            elif action in {"v", "view", "log"}:
                self.view_log(rest)
            elif action in {"w", "watch"}:
                self.watch_run(rest)
            elif action in {"k", "kill", "stop"}:
                self.stop_run(rest)
            elif action in {"refresh", "reload"}:
                self.print_scripts()
            else:
                print(f"Unknown command: {action}. Type h for help.")

    def print_help(self) -> None:
        print(
            "\nCommands:\n"
            "  l, list              List .ahk scripts in the working directory\n"
            "  r N, run N           Run script number N in the foreground\n"
            "  b N, bg N            Start script number N in the background\n"
            "  s, status            Show active and completed runs\n"
            "  v ID, log ID         Print a run log\n"
            "  w ID, watch ID       Watch new output from a background run\n"
            "  k ID, stop ID        Stop a background run\n"
            "  q, quit              Exit the manager\n"
        )

    def scripts(self) -> list[Path]:
        return sorted(path for path in self.cwd.glob("*.ahk") if path.is_file())

    def print_scripts(self) -> None:
        scripts = self.scripts()
        if not scripts:
            print(f"No .ahk files found in {self.cwd}")
            return

        print("\nAvailable .ahk scripts:")
        for index, script in enumerate(scripts, start=1):
            print(f"  {index:>2}. {script.name}")
        print()

    def run_selected(self, selection: str, background: bool) -> None:
        script = self.resolve_script_selection(selection)
        if script is None:
            return

        run = self.start_run(script)
        if background:
            print(f"Started run {run.run_id}: {script.name}")
            print(f"Log: {run.log_path}")
            return

        print(f"Running {script.name}. Press Ctrl+C to stop this script.\n")
        try:
            self.stream_run(run, until_exit=True)
        except KeyboardInterrupt:
            print("\nStopping script...")
            self.terminate_process(run.process)
        finally:
            run.process.wait()
            self.drain_run_output(run)
            print(f"\nRun {run.run_id} exited with code {run.return_code()}.")
            print(f"Log: {run.log_path}")

    def resolve_script_selection(self, selection: str) -> Path | None:
        scripts = self.scripts()
        if not scripts:
            print(f"No .ahk files found in {self.cwd}")
            return None

        if not selection:
            self.print_scripts()
            selection = input("Select script number: ").strip()

        try:
            index = int(selection)
        except ValueError:
            print("Please select by script number.")
            return None

        if index < 1 or index > len(scripts):
            print(f"Selection out of range: {index}")
            return None

        return scripts[index - 1]

    def start_run(self, script: Path) -> ManagedRun:
        run_id = self.next_run_id
        self.next_run_id += 1

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = self.log_dir / f"{script.stem}_{stamp}_run{run_id}.log"
        command = [str(self.ahk_exe), "/ErrorStdOut", str(script)]
        log_path.write_text(
            f"Command: {command}\nStarted: {datetime.now().isoformat(timespec='seconds')}\n\n",
            encoding="utf-8",
        )

        process = subprocess.Popen(
            command,
            cwd=str(self.cwd),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
        )
        run = ManagedRun(
            run_id=run_id,
            script=script,
            process=process,
            log_path=log_path,
            started_at=datetime.now(),
        )
        self.runs[run_id] = run

        if process.stdout is not None:
            threading.Thread(target=self.collect_output, args=(run, process.stdout, "stdout"), daemon=True).start()
        if process.stderr is not None:
            threading.Thread(target=self.collect_output, args=(run, process.stderr, "stderr"), daemon=True).start()

        return run

    def collect_output(self, run: ManagedRun, pipe: object, label: str) -> None:
        with run.log_path.open("a", encoding="utf-8") as log_file:
            for line in pipe:  # type: ignore[operator]
                stamped = f"[{datetime.now().strftime('%H:%M:%S')}] {label}: {line}"
                log_file.write(stamped)
                log_file.flush()
                run.output_queue.put(stamped)

    def stream_run(self, run: ManagedRun, until_exit: bool) -> None:
        while until_exit and run.is_running():
            self.drain_run_output(run)
            time.sleep(0.1)
        self.drain_run_output(run)

    def drain_run_output(self, run: ManagedRun) -> None:
        while True:
            try:
                line = run.output_queue.get_nowait()
            except queue.Empty:
                return
            print(line, end="")

    def print_status(self) -> None:
        if not self.runs:
            print("No runs started yet.")
            return

        print("\nRuns:")
        for run in self.runs.values():
            status = "running" if run.is_running() else f"exited {run.return_code()}"
            elapsed = datetime.now() - run.started_at
            print(f"  {run.run_id:>2}. {status:<12} {run.script.name}  elapsed={str(elapsed).split('.')[0]}")
        print()

    def view_log(self, selection: str) -> None:
        run = self.resolve_run(selection)
        if run is None:
            return
        self.drain_run_output(run)
        print(f"\n--- {run.log_path} ---")
        print(run.log_path.read_text(encoding="utf-8"), end="")
        print("--- end log ---\n")

    def watch_run(self, selection: str) -> None:
        run = self.resolve_run(selection)
        if run is None:
            return

        print(f"Watching run {run.run_id}. Press Ctrl+C to return to the manager.")
        try:
            while run.is_running():
                self.drain_run_output(run)
                time.sleep(0.1)
        except KeyboardInterrupt:
            print("\nStopped watching.")
        finally:
            self.drain_run_output(run)
            if not run.is_running():
                print(f"Run {run.run_id} exited with code {run.return_code()}.")

    def stop_run(self, selection: str) -> None:
        run = self.resolve_run(selection)
        if run is None:
            return
        if not run.is_running():
            print(f"Run {run.run_id} is already finished with code {run.return_code()}.")
            return

        self.terminate_process(run.process)
        run.process.wait(timeout=5)
        self.drain_run_output(run)
        print(f"Stopped run {run.run_id}. Exit code: {run.return_code()}")

    def resolve_run(self, selection: str) -> ManagedRun | None:
        if not selection:
            self.print_status()
            selection = input("Select run id: ").strip()
        try:
            run_id = int(selection)
        except ValueError:
            print("Please select by run id.")
            return None

        run = self.runs.get(run_id)
        if run is None:
            print(f"No run with id {run_id}.")
        return run

    def reap_finished_runs(self) -> None:
        for run in self.runs.values():
            if not run.is_running():
                self.drain_run_output(run)

    def confirm_exit(self) -> None:
        running = [run for run in self.runs.values() if run.is_running()]
        if not running:
            return

        print("The following runs are still active:")
        for run in running:
            print(f"  {run.run_id}. {run.script.name}")

        answer = input("Stop them before exiting? [y/N] ").strip().lower()
        if answer == "y":
            for run in running:
                self.terminate_process(run.process)

    @staticmethod
    def terminate_process(process: subprocess.Popen[str]) -> None:
        if process.poll() is not None:
            return
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()


def resolve_ahk_exe(configured: str | None) -> Path | None:
    if configured:
        path = Path(configured).expanduser()
        if path.exists():
            return path.resolve()
        found = shutil.which(configured)
        if found:
            return Path(found).resolve()
        return None

    for name in AHK_EXE_NAMES:
        found = shutil.which(name)
        if found:
            return Path(found).resolve()

    if os.name == "nt":
        candidates = common_windows_ahk_paths()
        for candidate in candidates:
            if candidate.exists():
                return candidate

    return None


def common_windows_ahk_paths() -> list[Path]:
    roots = [
        os.environ.get("ProgramFiles"),
        os.environ.get("ProgramFiles(x86)"),
        os.environ.get("LOCALAPPDATA"),
    ]
    relative_paths = [
        Path("AutoHotkey") / "v2" / "AutoHotkey64.exe",
        Path("AutoHotkey") / "v2" / "AutoHotkey.exe",
        Path("AutoHotkey") / "AutoHotkey64.exe",
        Path("AutoHotkey") / "AutoHotkey.exe",
    ]

    paths: list[Path] = []
    for root in roots:
        if not root:
            continue
        for relative in relative_paths:
            paths.append(Path(root) / relative)
    return paths


if __name__ == "__main__":
    raise SystemExit(main())
