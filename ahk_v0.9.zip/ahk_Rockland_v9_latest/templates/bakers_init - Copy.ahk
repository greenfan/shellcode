#Requires AutoHotkey v2.0
#SingleInstance Force
#WinActivateForce

SetTitleMatchMode 2
CoordMode "Mouse", "Screen"
SendMode "Input"
SetWinDelay 100
OnError SuppressAhkPopupError

processName := "BAKER32.EXE"
loginPassword := "94dem"
exePath := "C:\Users\rdwyer\AppData\Local\Programs\Rockland Bakers Dozen\BAKER32.EXE"
workingDir := "\\rb-rossbd\Baker\Bakers13"
postLaunchWaitMs := 15000
loginClickX := 420
loginClickY := 420
loginKeyDelayMs := 200
activateRetries := 3
logPath := A_ScriptDir "\bakers_init.log"

Log("START bakers_init")
Log("Screen detected: " A_ScreenWidth "x" A_ScreenHeight)

; --- Launch if needed ---
if !ProcessExist(processName) {
    Log("Launching Bakers.")
    if !LaunchExe(exePath, workingDir) {
        Log("FAIL could not start Bakers.")
        ExitApp 1
    }
    hwnd := WaitForBakersWindow(60000)
    if !hwnd {
        Log("FAIL no Bakers window after launch.")
        ExitApp 2
    }
} else {
    Log(processName " already running.")
    hwnd := FindBakersWindow()
    if !hwnd {
        Log("WARN process running but no window; relaunching.")
        KillBakersProcess()
        if !LaunchExe(exePath, workingDir) {
            ExitApp 1
        }
        hwnd := WaitForBakersWindow(60000)
        if !hwnd {
            ExitApp 2
        }
    }
}

; --- Wait, activate, login ---
Log("Waiting " postLaunchWaitMs " ms before login sequence.")
Sleep postLaunchWaitMs

hwnd := FindBakersWindow()
if !hwnd {
    Log("FAIL no Bakers window for login.")
    ExitApp 2
}

GracefulActivateBakers(hwnd, "pre-login")

Log("Login: click " loginClickX "," loginClickY " -> Tab -> password -> Enter.")
priorSendMode := A_SendMode
try {
    SendMode "Event"
    SolidClickAt(loginClickX, loginClickY)
    Sleep 600
    Send "{Tab}"
    Sleep 300
    TypeTextSlow(loginPassword, loginKeyDelayMs)
    Sleep 300
    Send "{Enter}"
} finally {
    try {
        SendMode priorSendMode
    }
}

Sleep 2000
GracefulActivateBakers(hwnd, "post-login")

Log("COMPLETE bakers_init.")
ExitApp 0

; --- Activation ---

GracefulActivateBakers(hwnd, context := "") {
    global activateRetries

    if !hwnd || !WinExist("ahk_id " hwnd) {
        Log("WARN " context ": Bakers window hwnd=" hwnd " not found.")
        return false
    }

    winTitle := "ahk_id " hwnd
    prefix := context != "" ? context ": " : ""

    Loop activateRetries {
        attempt := A_Index
        try {
            WinShow winTitle
            if WinGetMinMax(winTitle) = -1 {
                WinRestore winTitle
            }
            WinRestore winTitle
            DllCall("ShowWindow", "Ptr", hwnd, "Int", 9)
            DllCall("BringWindowToTop", "Ptr", hwnd)
            DllCall("SetForegroundWindow", "Ptr", hwnd)
            WinActivate winTitle
            WinSetAlwaysOnTop true, winTitle
            Sleep 100
            WinSetAlwaysOnTop false, winTitle

            if WinWaitActive(winTitle, , 5) {
                Log(prefix "Bakers activated hwnd=" hwnd " (attempt " attempt ").")
                return true
            }

            Log("WARN " prefix "WinWaitActive timed out (attempt " attempt ").")
        } catch as err {
            Log("WARN " prefix "activation attempt " attempt " failed: " err.Message)
        }
        Sleep 800
    }

    Log("WARN " prefix "could not confirm active window; continuing anyway.")
    return false
}

; --- Login sequence helpers ---

SolidClickAt(x, y) {
    MouseMove x, y, 0
    Sleep 150
    priorSendMode := A_SendMode
    try {
        SendMode "Event"
        Send "{LButton down}"
        Sleep 90
        Send "{LButton up}"
    } finally {
        try {
            SendMode priorSendMode
        }
    }
    Log("Click at " x "," y ".")
}

TypeTextSlow(value, pauseMs := 200) {
    for _, ch in StrSplit(value) {
        SendText ch
        Sleep Max(pauseMs, 200)
    }
}

; --- Launch / window ---

LaunchExe(exePath, workingDir) {
    global processName

    if !FileExist(exePath) {
        Log("EXE not found: " exePath)
        return false
    }

    if DirExist(workingDir) {
        Run exePath, workingDir
    } else {
        Run exePath
    }

    return WaitForProcess(processName, 20000)
}

FindBakersWindow() {
    global processName
    bestHwnd := 0
    bestArea := 0

    for hwnd in WinGetList("ahk_exe " processName) {
        if !WinExist("ahk_id " hwnd) {
            continue
        }
        try {
            WinGetPos &x, &y, &w, &h, "ahk_id " hwnd
            if w > 0 && h > 0 && (w * h) > bestArea {
                bestArea := w * h
                bestHwnd := hwnd
            }
        }
    }
    return bestHwnd
}

WaitForBakersWindow(timeoutMs) {
    deadline := A_TickCount + timeoutMs
    while A_TickCount < deadline {
        if hwnd := FindBakersWindow() {
            return hwnd
        }
        Sleep 500
    }
    return 0
}

WaitForProcess(imageName, timeoutMs := 15000) {
    deadline := A_TickCount + timeoutMs
    while A_TickCount < deadline {
        if pid := ProcessExist(imageName) {
            return pid
        }
        Sleep 500
    }
    return 0
}

KillBakersProcess() {
    global processName
    Loop 5 {
        if !ProcessExist(processName) {
            return
        }
        try {
            ProcessClose ProcessExist(processName)
        }
        Sleep 1000
    }
}

Log(message) {
    global logPath
    line := FormatTime(, "yyyy-MM-dd HH:mm:ss") " | " message "`n"
    try {
        FileAppend line, logPath, "UTF-8"
    }
    try {
        FileAppend line, "*", "UTF-8"
    }
}

SuppressAhkPopupError(err, mode) {
    return true
}
