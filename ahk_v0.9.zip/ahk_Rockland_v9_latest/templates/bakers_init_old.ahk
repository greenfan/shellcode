#Requires AutoHotkey v2.0
#SingleInstance Force
#WinActivateForce

SetTitleMatchMode 2
CoordMode "Mouse", "Screen"
SendMode "Input"
SetWinDelay 100
OnError SuppressAhkPopupError

processName := "BAKER32.EXE"
loginPassword := "94dem"
exePath := "C:\Users\rdwyer\AppData\Local\Programs\Rockland Bakers Dozen\BAKER32.EXE"
workingDir := "\\rb-rossbd\Baker\Bakers13"
startupWaitMs := 25000
postLoginWaitMs := 22000
logPath := A_ScriptDir "\bakers_init.log"

Log("START bakers_init")
LogCoordinateProfile()
Log("Screen detected: " A_ScreenWidth "x" A_ScreenHeight)
Log("Session context: computer=" A_ComputerName " user=" A_UserName " session=" EnvGet("SESSIONNAME") " client=" EnvGet("CLIENTNAME"))

skipLaunch := false
if ProcessExist(processName) {
    existingHwnd := FindBakersWindow(5000)
    if existingHwnd {
        if LooksLikeLoginWindow(existingHwnd) {
            Log(processName " already running at login; attempting in-place login without relaunch.")
            hwnd := existingHwnd
            skipLaunch := true
        } else if LoginDetectionReliable(existingHwnd) {
            Log(processName " already running and past login; skipping relaunch/login.")
            ExitApp 0
        } else {
            Log("WARN login state uncertain for existing " processName "; attempting in-place login without relaunch.")
            hwnd := existingHwnd
            skipLaunch := true
        }
    } else {
        Log("WARN " processName " process found but no window; closing stale process before relaunch.")
        KillBakersProcess()
    }
}

if !skipLaunch {
    Log("Minimizing all open windows before launch.")
    WinMinimizeAll()
    Sleep 1000

    Log("Launching Bakers via EXE only: " exePath)
    if !LaunchExe(exePath, workingDir) {
        Log("FAIL could not start Bakers from EXE.")
        ExitApp 1
    }

    Log("Waiting " startupWaitMs " ms for Bakers login window to appear.")
    Sleep startupWaitMs

    hwnd := FindBakersWindow(30000)
    if !hwnd {
        Log("FAIL no Bakers window found after startup wait.")
        ExitApp 2
    }
} else {
    Log("Using existing Bakers window hwnd=" hwnd " for in-place login.")
}

winTitle := "ahk_id " hwnd
PrepareLoginWindow(winTitle)

Loop 3 {
    attempt := A_Index
    if !LooksLikeLoginWindow(hwnd) {
        if LoginDetectionReliable(hwnd) {
            Log("Login attempt " attempt ": login screen already cleared.")
            break
        }
        Log("WARN login attempt " attempt ": control detection unreliable; sending login keystrokes anyway.")
    }

    Log("Login attempt " attempt ": clicking 425,358, Tab, password, Enter.")
    SubmitLoginKeystrokes(winTitle)

    Log("Waiting up to " postLoginWaitMs " ms for login screen to clear.")
    if WaitForLoginWindowToClear(winTitle, postLoginWaitMs) {
        Log("Login attempt " attempt ": login controls cleared.")
        break
    }

    Log("WARN login attempt " attempt ": login screen still present.")
    hwnd := FindBakersWindow(15000)
    if !hwnd {
        if ConfirmBakersProcessRunning() {
            Log("WARN Bakers window not found during login retry but process still running; waiting before next attempt.")
            Sleep 3000
            hwnd := FindBakersWindow(15000)
        }
        if !hwnd {
            Log("WARN could not re-locate Bakers window during login retries; continuing anyway if process remains.")
            if !ConfirmBakersProcessRunning() {
                Log("FAIL Bakers process no longer running during login retries.")
                ExitApp 2
            }
            break
        }
    }
    winTitle := "ahk_id " hwnd
    PrepareLoginWindow(winTitle)
    Sleep 1000
}

if LooksLikeLoginWindow(hwnd) {
    Log("WARN login screen may still be present after all attempts; window targeting is often unreliable on remote sessions — continuing because Bakers process is running.")
} else if !LoginDetectionReliable(hwnd) {
    Log("WARN could not reliably verify login screen state; continuing because Bakers process is running.")
}

if !ConfirmBakersProcessRunning() {
    Log("FAIL no running process with 'baker' in the name after login.")
    ExitApp 3
}

Log("COMPLETE bakers_init: logged in and Bakers process confirmed running.")
ExitApp 0

WaitForLoginWindowToClear(winTitle, timeoutMs := 22000) {
    deadline := A_TickCount + timeoutMs

    while A_TickCount < deadline {
        if !WinExist(winTitle) {
            return true
        }

        edits := GetEditControls(winTitle, &enumerationOk)
        if enumerationOk && edits.Length < 2 {
            return true
        }

        Sleep 500
    }

    return false
}

LoginDetectionReliable(hwnd) {
    if !hwnd {
        return false
    }

    GetEditControls("ahk_id " hwnd, &enumerationOk)
    return enumerationOk
}

LooksLikeLoginWindow(hwnd) {
    if !hwnd {
        return false
    }

    edits := GetEditControls("ahk_id " hwnd, &enumerationOk)
    if !enumerationOk {
        Log("WARN login detection unreliable for hwnd=" hwnd "; control enumeration failed.")
        return false
    }

    return edits.Length >= 2
}

GetEditControls(winTitle, &enumerationOk := true) {
    edits := []
    enumerationOk := true
    try {
        for controlName in WinGetControls(winTitle) {
            if RegExMatch(controlName, "^Edit\d+$") {
                edits.Push(controlName)
            }
        }
    } catch as err {
        enumerationOk := false
        Log("WARN could not enumerate controls for " winTitle ": " err.Message)
    }
    return edits
}

LaunchExe(exePath, workingDir) {
    if !FileExist(exePath) {
        Log("EXE not found: " exePath)
        return false
    }

    if DirExist(workingDir) {
        Log("Run EXE with Start In: " workingDir)
        Run exePath, workingDir
    } else {
        Log("WARN Start In not found; running EXE without working directory.")
        Run exePath
    }

    if WaitForProcess(processName, 20000) {
        Log("SUCCESS process detected: " processName)
        return true
    }

    Log("WARN process not detected within 20s after Run.")
    return false
}

FindBakersWindow(timeoutMs := 30000) {
    deadline := A_TickCount + timeoutMs

    while A_TickCount < deadline {
        bestHwnd := 0
        bestArea := 0

        for hwnd in WinGetList("ahk_exe " processName) {
            if !WinExist("ahk_id " hwnd) {
                continue
            }

            try {
                WinGetPos &x, &y, &w, &h, "ahk_id " hwnd
                if w > 0 && h > 0 {
                    edits := GetEditControls("ahk_id " hwnd, &enumerationOk)
                    if enumerationOk && edits.Length >= 2 {
                        Log("Bakers login window found: hwnd=" hwnd " title='" WinGetTitle("ahk_id " hwnd) "' editControls=" edits.Length)
                        return hwnd
                    }

                    area := w * h
                    if area > bestArea {
                        bestArea := area
                        bestHwnd := hwnd
                    }
                }
            }
        }

        if bestHwnd {
            Log("Bakers window fallback selected by largest visible area: hwnd=" bestHwnd " area=" bestArea " title='" WinGetTitle("ahk_id " bestHwnd) "'")
            return bestHwnd
        }

        Sleep 500
    }

    return 0
}

PrepareLoginWindow(winTitle) {
    try {
        WinRestore winTitle
    }

    try {
        WinActivate winTitle
    } catch as err {
        Log("WARN WinActivate failed (continuing): " err.Message)
    }

    if !WinWaitActive(winTitle, , 3) {
        Log("WARN WinWaitActive timed out; sending login keys anyway.")
    }

    Sleep 500

    try {
        WinGetPos &x, &y, &w, &h, winTitle
        if w > 0 && h > 0 {
            cx := x + (w // 2)
            cy := y + (h // 2)
            Log("Solid-clicking Bakers client center at " cx "," cy " to grab focus before login.")
            SolidClickAt(cx, cy)
            Sleep 400
        }
    } catch as err {
        Log("WARN could not focus client center before login: " err.Message)
    }
}

SubmitLoginKeystrokes(winTitle) {
    global loginPassword

    try {
        WinActivate winTitle
    }

    priorSendMode := A_SendMode
    try {
        SendMode "Event"
        point := ResolveAutomationPoint(425, 358)
        Log("Login field click resolved to " point[1] "," point[2] " (" point[3] " from design 425,358).")
        SolidClickAt(point[1], point[2])
        Sleep 600
        Send "{Tab}"
        Sleep 300
        for _, ch in StrSplit(loginPassword) {
            SendText ch
            Sleep 100
        }
        Sleep 300
        Send "{Enter}"
    } finally {
        try {
            SendMode priorSendMode
        }
    }

    Log("Login keystrokes sent (Event send mode).")
}

LogCoordinateProfile() {
    if A_ScreenWidth = 1280 && A_ScreenHeight = 800 {
        Log("Coordinate profile: native 1280x800; using original tuned click points.")
    } else if A_ScreenWidth = 1597 && A_ScreenHeight = 812 {
        Log("Coordinate profile: calibrated 1597x812 tscon console profile; using fixed translated click points.")
    } else {
        scaleX := Round(A_ScreenWidth / 1280, 3)
        scaleY := Round(A_ScreenHeight / 800, 3)
        Log("WARN coordinate profile: uncalibrated screen " A_ScreenWidth "x" A_ScreenHeight
            "; scaling from 1280x800 with scaleX=" scaleX " scaleY=" scaleY ".")
    }
}

ResolveAutomationPoint(designX, designY) {
    if A_ScreenWidth = 1280 && A_ScreenHeight = 800 {
        return [designX, designY, "native"]
    }

    if A_ScreenWidth = 1597 && A_ScreenHeight = 812 {
        if designX = 425 && designY = 358 {
            return [530, 363, "1597x812 calibrated"]
        }
    }

    return [
        Max(0, Round(designX * A_ScreenWidth / 1280)),
        Max(0, Round(designY * A_ScreenHeight / 800)),
        "proportional fallback"
    ]
}

TypeTextSlow(value, pauseMs := 100) {
    for _, ch in StrSplit(value) {
        SendText ch
        Sleep pauseMs
    }
}

SolidClickAt(x, y) {
    MouseMove x, y, 0
    Sleep 120
    priorSendMode := A_SendMode
    try {
        SendMode "Event"
        Send "{LButton down}"
        Sleep 90
        Send "{LButton up}"
    } finally {
        try {
            SendMode priorSendMode
        }
    }
    Log("Solid left click delivered at " x "," y ".")
}

ConfirmBakersProcessRunning() {
    if ProcessExist(processName) {
        Log("Confirmed via ProcessExist: " processName " PID=" ProcessExist(processName))
        return true
    }

    try {
        for item in ComObjGet("winmgmts:").ExecQuery("SELECT Name, ProcessId FROM Win32_Process") {
            name := StrLower(item.Name)
            if InStr(name, "baker") {
                Log("Confirmed via WMI process name: " item.Name " PID=" item.ProcessId)
                return true
            }
        }
    } catch as err {
        Log("WARN WMI process scan failed: " err.Message)
    }

    return false
}

KillBakersProcess() {
    Loop 10 {
        pid := ProcessExist(processName)
        if !pid {
            return
        }

        Log("Closing " processName " PID=" pid)
        try {
            ProcessClose pid
        } catch as err {
            Log("WARN ProcessClose failed: " err.Message)
        }

        Sleep 1000
    }
}

WaitForProcess(imageName, timeoutMs := 15000) {
    deadline := A_TickCount + timeoutMs

    while A_TickCount < deadline {
        pid := ProcessExist(imageName)
        if pid {
            return pid
        }

        Sleep 500
    }

    return 0
}

Log(message) {
    global logPath

    line := FormatTime(, "yyyy-MM-dd HH:mm:ss") " | " message "`n"
    try {
        FileAppend line, logPath, "UTF-8"
    }

    try {
        FileAppend line, "*", "UTF-8"
    }

    OutputDebug RTrim(line, "`n")
}

SuppressAhkPopupError(err, mode) {
    try {
        Log(
            "SUPPRESSED AHK ERROR mode=" mode
            " message=" err.Message
            " what=" err.What
            " line=" err.Line
        )
    }

    return true
}
