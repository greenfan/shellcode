#!/usr/bin/env python3
"""
Capture the Bakers13 in-app report config panel, resize, and send to Open WebUI.

Configure in .env (same folder as this script):
  OPENWEBUI_BASE_URL=https://ai.nosox.xyz
  OPENWEBUI_API_TOKEN=<optional JWT or sk- API key from Settings > Account>
  OPENWEBUI_EMAIL=<optional; used to sign in when OPENWEBUI_API_TOKEN is unset>
  OPENWEBUI_PASSWORD=<optional; paired with OPENWEBUI_EMAIL>
  OPENWEBUI_MODEL=rocklanduihelper
  OPENWEBUI_SCREENSHOT_WIDTH=120
  OPENWEBUI_SCREENSHOT_HEIGHT=80
  OPENWEBUI_ENABLED=1

Resize fallback (when Pillow is missing) copies the full-size capture and logs the
ImageMagick-style command you would run manually:
  convert screenshotMMDDYYYY.jpeg -resize 120x80 WeeklySalesRun1_screenshotMMDDYYYY.jpeg

Optional: upload an existing image instead of capturing:
  python openwebui_report_screenshot.py -ii path/to/image.png
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent
LOG_PATH = APP_ROOT / "WeeklySalesRun1.log"


def read_key_value_file(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}

    values: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line[:2] in ("- ", "* "):
            line = line[2:].strip()
        if "=" in line:
            key, value = line.split("=", 1)
        elif ":" in line:
            key, value = line.split(":", 1)
        else:
            continue
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def load_config() -> dict[str, str]:
    config: dict[str, str] = {}
    for path in (APP_ROOT / ".env", APP_ROOT / "text2.md"):
        config.update(read_key_value_file(path))
    for key, value in os.environ.items():
        if key.startswith("OPENWEBUI_"):
            config[key] = value.strip()
    return config


def log(message: str) -> None:
    line = f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {message}"
    print(line, flush=True)
    try:
        with LOG_PATH.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")
    except OSError:
        pass


def parse_yes_no_answer(text: str) -> str | None:
    """Return YES, NO, or None if the response does not contain a clear verdict."""
    if not text:
        return None

    upper = text.upper()
    yes_match = re.search(r"\bYES\b", upper)
    no_match = re.search(r"\bNO\b", upper)
    if yes_match and not no_match:
        return "YES"
    if no_match and not yes_match:
        return "NO"
    if yes_match and no_match:
        if yes_match.start() > no_match.start():
            return "YES"
        return "NO"
    return None


def parse_bool(value: str, default: bool = True) -> bool:
    if not value:
        return default
    return value.strip().lower() not in ("0", "false", "no", "off")


def window_bbox(hwnd: int) -> tuple[int, int, int, int] | None:
    if os.name != "nt" or hwnd <= 0:
        return None

    try:
        import ctypes

        rect = ctypes.wintypes.RECT()
        if not ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            return None
        left, top, right, bottom = rect.left, rect.top, rect.right, rect.bottom
        if right <= left or bottom <= top:
            return None
        return left, top, right, bottom
    except Exception as err:
        log(f"WARN could not read window bounds for hwnd={hwnd}: {err}")
        return None


def capture_screenshot(output_path: Path, hwnd: int = 0, full_screen: bool = False) -> bool:
    try:
        from PIL import ImageGrab
    except ImportError:
        log("FAIL Pillow is required for screenshot capture. Install: python -m pip install Pillow")
        return False

    bbox = None
    if not full_screen and hwnd > 0:
        bbox = window_bbox(hwnd)
        if bbox:
            log(f"Capturing Bakers window hwnd={hwnd} region {bbox}")
        else:
            log(f"WARN hwnd={hwnd} bounds unavailable; falling back to full screen capture")

    if bbox is None:
        log("Capturing full screen for report config panel screenshot")
        image = ImageGrab.grab()
    else:
        image = ImageGrab.grab(bbox=bbox)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    suffix = output_path.suffix.lower()
    if suffix in (".jpg", ".jpeg"):
        image.save(output_path, format="JPEG", quality=90)
    else:
        image.save(output_path, format="PNG")
    log(f"Saved screenshot: {output_path} ({output_path.stat().st_size} bytes)")
    return True


def resize_screenshot(source: Path, dest: Path, width: int, height: int) -> bool:
    try:
        from PIL import Image
    except ImportError:
        log(
            "WARN Pillow resize unavailable; copying full-size capture without resize. "
            f"Manual equivalent: convert {source.name} -resize {width}x{height} {dest.name}"
        )
        try:
            shutil.copy2(source, dest)
            log(f"Placeholder resized file (copy only): {dest}")
        except OSError as err:
            log(f"WARN could not copy placeholder resized file: {err}")
            return False
        return False

    with Image.open(source) as image:
        resized = image.resize((width, height), Image.Resampling.LANCZOS)
        suffix = dest.suffix.lower()
        if suffix in (".jpg", ".jpeg"):
            resized.save(dest, format="JPEG", quality=90)
        else:
            resized.save(dest, format="PNG")
    log(f"Resized screenshot to {width}x{height}: {dest}")
    return True


def image_mime(path: Path) -> str:
    if path.suffix.lower() in (".jpg", ".jpeg"):
        return "image/jpeg"
    return "image/png"


def encode_image_base64(path: Path) -> str:
    return base64.b64encode(path.read_bytes()).decode("ascii")


def signin_openwebui(base_url: str, email: str, password: str) -> str | None:
    """Obtain a JWT by signing in with email and password."""
    try:
        import requests
    except ImportError:
        log("FAIL requests is required for Open WebUI sign-in. Install: python -m pip install requests")
        return None

    url = f"{base_url.rstrip('/')}/api/v1/auths/signin"
    log(f"Open WebUI sign-in: POST {url} email={email}")
    try:
        response = requests.post(
            url,
            json={"email": email, "password": password},
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=30,
        )
    except requests.RequestException as err:
        log(f"WARN Open WebUI sign-in request failed: {err}")
        return None

    if response.status_code >= 400:
        log(f"WARN Open WebUI sign-in HTTP {response.status_code}: {response.text[:500]}")
        return None

    try:
        payload = response.json()
    except json.JSONDecodeError:
        log("WARN Open WebUI sign-in returned non-JSON body")
        return None

    token = str(payload.get("token") or "").strip()
    if not token:
        log(f"WARN Open WebUI sign-in response missing token: {payload}")
        return None

    log("Open WebUI sign-in succeeded; JWT obtained")
    return token


def resolve_openwebui_token(config: dict[str, str]) -> str:
    """Return a bearer token from config, signing in when credentials are provided."""
    token = config.get("OPENWEBUI_API_TOKEN", "").strip()
    if token:
        return token

    base_url = config.get("OPENWEBUI_BASE_URL", "https://ai.nosox.xyz").strip()
    email = config.get("OPENWEBUI_EMAIL", "").strip()
    password = config.get("OPENWEBUI_PASSWORD", "")
    if email and password:
        signed_in = signin_openwebui(base_url, email, password)
        if signed_in:
            return signed_in

    return ""


def upload_file(base_url: str, token: str, image_path: Path) -> str | None:
    try:
        import requests
    except ImportError:
        log("WARN requests not installed; skipping file upload path")
        return None

    url = f"{base_url.rstrip('/')}/api/v1/files/"
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
    with image_path.open("rb") as handle:
        files = {"file": (image_path.name, handle, image_mime(image_path))}
        response = requests.post(url, headers=headers, files=files, timeout=60)
    if response.status_code >= 400:
        log(f"WARN file upload failed HTTP {response.status_code}: {response.text[:500]}")
        return None

    try:
        payload = response.json()
    except json.JSONDecodeError:
        log("WARN file upload returned non-JSON body")
        return None

    file_id = payload.get("id") or payload.get("file_id")
    if file_id:
        log(f"Open WebUI file uploaded: id={file_id}")
        return str(file_id)
    log(f"WARN file upload response missing id: {payload}")
    return None


def chat_with_image_base64(
    base_url: str,
    token: str,
    model: str,
    prompt: str,
    image_path: Path,
) -> str | None:
    try:
        import requests
    except ImportError:
        log("FAIL requests is required for Open WebUI API. Install: python -m pip install requests")
        return None

    mime = image_mime(image_path)
    b64 = encode_image_base64(image_path)
    payload = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:{mime};base64,{b64}"},
                    },
                ],
            }
        ],
        "stream": False,
    }
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }

    endpoints = ("/api/chat/completions", "/v1/chat/completions")
    for endpoint in endpoints:
        url = f"{base_url.rstrip('/')}{endpoint}"
        log(f"Open WebUI vision request: POST {url} model={model}")
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=120)
        except requests.RequestException as err:
            log(f"WARN Open WebUI request failed for {endpoint}: {err}")
            continue

        if response.status_code >= 400:
            log(f"WARN Open WebUI HTTP {response.status_code} on {endpoint}: {response.text[:500]}")
            continue

        try:
            body = response.json()
            content = body["choices"][0]["message"]["content"]
            if isinstance(content, list):
                text_parts = [
                    part.get("text", "")
                    for part in content
                    if isinstance(part, dict) and part.get("type") == "text"
                ]
                content = "\n".join(text_parts).strip()
            content = str(content).strip()
            preview = content.replace("\n", " ")[:240]
            log(f"Open WebUI response preview: {preview}")
            return content
        except (KeyError, IndexError, json.JSONDecodeError, TypeError):
            log(f"Open WebUI accepted image on {endpoint} (response parse skipped)")
            return ""

    return None


def chat_with_uploaded_file(
    base_url: str,
    token: str,
    model: str,
    prompt: str,
    file_id: str,
) -> bool:
    try:
        import requests
    except ImportError:
        return False

    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "files": [{"type": "file", "id": file_id}],
        "stream": False,
    }
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    url = f"{base_url.rstrip('/')}/api/chat/completions"
    log(f"Open WebUI file-reference request: POST {url}")
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=120)
    except requests.RequestException as err:
        log(f"WARN Open WebUI file-reference request failed: {err}")
        return False

    if response.status_code >= 400:
        log(f"WARN Open WebUI file-reference HTTP {response.status_code}: {response.text[:500]}")
        return False

    log("Open WebUI accepted file-reference chat request")
    return True


def send_to_openwebui(
    image_path: Path,
    config: dict[str, str],
    prompt_override: str | None = None,
) -> str | None:
    base_url = config.get("OPENWEBUI_BASE_URL", "https://ai.nosox.xyz").strip()
    token = resolve_openwebui_token(config)
    model = config.get("OPENWEBUI_MODEL", "rocklanduihelper").strip()
    prompt = (prompt_override or "").strip() or config.get(
        "OPENWEBUI_SCREENSHOT_PROMPT",
        "Weekly Bakers13 report config panel screenshot. Confirm the in-app report "
        "configuration UI is visible and note anything that looks wrong.",
    ).strip()

    if not token:
        log(
            "WARN Open WebUI auth not configured. Set OPENWEBUI_API_TOKEN or "
            "OPENWEBUI_EMAIL + OPENWEBUI_PASSWORD in .env; skipping API upload. "
            f"Manual fallback: {base_url}/?models={model}"
        )
        return None

    content = chat_with_image_base64(base_url, token, model, prompt, image_path)
    if content is not None:
        return content

    file_id = upload_file(base_url, token, image_path)
    if file_id and chat_with_uploaded_file(base_url, token, model, prompt, file_id):
        return ""

    manual_url = f"{base_url.rstrip('/')}/?models={model}"
    log(
        "WARN embedded image API paths failed. Manual fallback: open the URL above and "
        f"upload {image_path.name} in the chat UI."
    )
    log(f"Manual upload URL: {manual_url}")
    return None


def run_test_yes_no_flow(
    image_path: Path,
    config: dict[str, str],
) -> int:
    prompt = config.get(
        "OPENWEBUI_TEST_PROMPT",
        "Look at this screenshot. Is the Bakers13 report configuration panel visibly open "
        "in the application? Reply with only YES or NO.",
    ).strip()

    content = send_to_openwebui(image_path, config, prompt_override=prompt)
    if content is None:
        log("FAIL Open WebUI did not return a usable response for YES/NO test")
        return 2

    log(f"Open WebUI full response: {content}")
    verdict = parse_yes_no_answer(content)
    if verdict == "YES":
        log("Found open window")
        return 0
    if verdict == "NO":
        log("Open WebUI answered NO")
        return 1

    log(f"FAIL response did not contain YES or NO: {content!r}")
    return 2


def resolve_input_image(path_text: str) -> Path | None:
    """Resolve -ii path; try cwd first, then script directory."""
    candidate = Path(path_text.strip()).expanduser()
    if not candidate.is_absolute():
        for base in (Path.cwd(), APP_ROOT):
            resolved = (base / candidate).resolve()
            if resolved.is_file():
                return resolved
        resolved = candidate.resolve()
    else:
        resolved = candidate.resolve()

    if resolved.is_file():
        return resolved

    log(f"FAIL input image not found: {path_text}")
    return None


def main() -> int:
    global LOG_PATH

    parser = argparse.ArgumentParser(description="Capture and send report config screenshot to Open WebUI")
    parser.add_argument("--hwnd", type=int, default=0, help="Capture this window handle (Bakers parent window)")
    parser.add_argument("--full-screen", action="store_true", help="Capture full screen instead of a window")
    parser.add_argument("--date-stamp", default="", help="MMDDYYYY stamp for filenames (default: today)")
    parser.add_argument(
        "--test-yes-no",
        action="store_true",
        help="Test mode: full-screen capture, send to Open WebUI, exit 0=YES, 1=NO, 2=error",
    )
    parser.add_argument(
        "-ii",
        "--ii",
        dest="input_image",
        default="",
        metavar="IMAGE",
        help="Use an existing image file instead of capturing a new screenshot",
    )
    args = parser.parse_args()

    config = load_config()
    input_image_path = resolve_input_image(args.input_image) if args.input_image.strip() else None
    if args.input_image.strip() and not input_image_path:
        return 1
    if args.test_yes_no:
        LOG_PATH = APP_ROOT / "TestOpenWebUIScreenshot.log"
        if not input_image_path:
            args.full_screen = True
    elif not input_image_path and not parse_bool(config.get("OPENWEBUI_ENABLED", "1"), default=True):
        log("Open WebUI screenshot step disabled (OPENWEBUI_ENABLED=0)")
        return 0

    date_stamp = args.date_stamp.strip() or datetime.now().strftime("%m%d%Y")
    width = int(config.get("OPENWEBUI_SCREENSHOT_WIDTH", "120") or "120")
    height = int(config.get("OPENWEBUI_SCREENSHOT_HEIGHT", "80") or "80")

    if args.test_yes_no:
        raw_name = f"test_screenshot{date_stamp}.jpeg"
        resized_name = f"TestOpenWebUIScreenshot_{date_stamp}.jpeg"
        start_label = "START TestOpenWebUIScreenshot (yes/no test)"
        complete_ok = "COMPLETE TestOpenWebUIScreenshot: YES — Found open window"
        complete_warn = "COMPLETE TestOpenWebUIScreenshot: finished with warnings"
    else:
        raw_name = f"screenshot{date_stamp}.jpeg"
        resized_name = f"WeeklySalesRun1_screenshot{date_stamp}.jpeg"
        start_label = "START openwebui_report_screenshot"
        complete_ok = "COMPLETE openwebui_report_screenshot: image sent to Open WebUI"
        complete_warn = (
            "COMPLETE openwebui_report_screenshot with warnings: screenshot files saved locally; "
            "Open WebUI API upload did not succeed"
        )

    raw_path = APP_ROOT / raw_name
    resized_path = APP_ROOT / resized_name

    log(start_label)
    if input_image_path:
        log(f"Using existing input image (-ii): {input_image_path}")
        upload_path = input_image_path
    else:
        if not capture_screenshot(raw_path, hwnd=args.hwnd, full_screen=args.full_screen):
            log("FAIL screenshot capture did not complete")
            return 1

        resize_screenshot(raw_path, resized_path, width, height)
        upload_path = resized_path

    if args.test_yes_no:
        return run_test_yes_no_flow(upload_path, config)

    content = send_to_openwebui(upload_path, config)
    if content is not None:
        log(complete_ok)
        return 0

    log(complete_warn)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
